<!DOCTYPE html>
<html>
<head>
    <title>TODO supply a title</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div>
    <form action="sendPay.php" method="post">
        <label><input type="radio" name="PayMod" value="alipay" />支付宝</label>
        <label><input type="radio" name="PayMod" value="tenpay" />财付通</label>
        <label><input type="radio" name="PayMod" value="yeepay" />易宝</label>
        <label><input type="radio" name="PayMod" value="unionpay" />银联</label>
        <input type="text" name="money" value="200" />
        <input type="submit" value="提交" />
    </form>
</div>
</body>
</html>
