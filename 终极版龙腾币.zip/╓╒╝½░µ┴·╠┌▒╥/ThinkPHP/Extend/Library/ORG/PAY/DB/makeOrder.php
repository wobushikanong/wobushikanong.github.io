<?php
/**
 * Created by PhpStorm.
 * User: Bridge
 * Date: 5/13/14
 * Time: 3:55 PM
 */

class makeOrder{


    /**
     * 生成订单号
     * 可根据自身的业务需求更改
     */



    public  function createOrderNo() {
        $year_code = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J');
        return $year_code[intval(date('Y')) - 2014] .
        strtoupper(dechex(date('m'))) . date('d') .
        substr(time(), -5) . substr(microtime(), 2, 5) . strtoupper(sprintf('d', rand(0, 99)));
    }

    public function saveOrderDo($TaskNo,$Amount,$way,$PayConfig){

        $con = mysql_connect($PayConfig['DB_HOST'],$PayConfig['DB_USER'],$PayConfig['DB_PWD']);
        if (!$con)
        {
            die('Could not connect: ' . mysql_error());
        }

        mysql_select_db($PayConfig['DB_NAME'], $con);

        $sql="INSERT INTO chongzhi (taskNO,Amount,status,way,addTime)
                  VALUES ('$TaskNo','$Amount','1','$way','".time()."')";

       $flag=mysql_query($sql);
       mysql_close($con);
       return $flag;


    }


}