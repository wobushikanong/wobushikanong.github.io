<?php
/**
 * Created by PhpStorm.
 * User: Bridge
 * Date: 5/13/14
 * Time: 3:56 PM
 */

class saveOrder{
    //支付成功
    public function success($taskNo,$Amount,$PayConfig){
        $con = mysql_connect($PayConfig['DB_HOST'],$PayConfig['DB_USER'],$PayConfig['DB_PWD']);
        if (!$con)
        {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db($PayConfig['DB_NAME'], $con);
        $sql="UPDATE chongzhi SET status = 2 WHERE taskNO = '$taskNo' and Amount='$Amount'";

        $flag=mysql_query($sql);
        mysql_close($con);
        return $flag;
    }
    //支付失败
    public function failure($taskNo,$Amount,$PayConfig){
        $con = mysql_connect($PayConfig['DB_HOST'],$PayConfig['DB_USER'],$PayConfig['DB_PWD']);
        if (!$con)
        {
            die('Could not connect: ' . mysql_error());
        }
        mysql_select_db($PayConfig['DB_NAME'], $con);
        $sql="UPDATE chongzhi SET status = 0 WHERE taskNO = '$taskNo' and Amount='$Amount'";

        $flag=mysql_query($sql);
        mysql_close($con);
        return $flag;
    }
}