<?php

include 'payConfig.php';
include 'DB/makeOrder.php';

$makeOrderObj=new makeOrder();
$TaskNo=$makeOrderObj->createOrderNo();
$PayMod=$_POST['PayMod'];
switch($PayMod){
    case 'tenpay':
        include 'sendPay.php';
        break;
    case 'alipay':
        include 'sendPay.php';
        break;
    case 'yeepay':
        include 'sendPay.php';
        break;
    case 'unionpay'://网银
        include './Driver/unionpay/Send.class.php';
        $Amount=$goldnum;
        $backUrl='';
        $ConfigA=array(
            'v_oid' => $TaskNo,
            'v_amount'=>$Amount, //支付金额
            'backUrl' =>$backUrl
        );
        $ConfigA = array_merge($PayConfig['pay']['unionpay'],$ConfigA);
        if($makeOrderObj->saveOrderDo($TaskNo,$Amount,'unionpay',$PayConfig)){
            new Send($ConfigA);
        }else{
            echo 'makeOrder bad!';
        }


        break;
    default:die('暂不支持该类付款!');
}


