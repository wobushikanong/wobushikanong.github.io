﻿<?php
/* *
 * 功能：支付回调文件
 * 版本：1.0
 * 日期：2015-03-26
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码。
 */
 
	require_once("Mobaopay.Config.php");
	require_once("lib/MobaoPay.class.php");

	// 请求数据赋值
	$data = "";
	$data['apiName'] = $_REQUEST["apiName"];
	// 通知时间
	$data['notifyTime'] = $_REQUEST["notifyTime"];
	// 支付金额(单位元，显示用)
	$data['tradeAmt'] = $_REQUEST["tradeAmt"];
	// 商户号
	$data['merchNo'] = $_REQUEST["merchNo"];
	// 商户参数，支付平台返回商户上传的参数，可以为空
	$data['merchParam'] = $_REQUEST["merchParam"];
	// 商户订单号
	$data['orderNo'] = $_REQUEST["orderNo"];
	// 商户订单日期
	$data['tradeDate'] = $_REQUEST["tradeDate"];
	// Mo宝支付订单号
	$data['accNo'] = $_REQUEST["accNo"];
	// Mo宝支付账务日期
	$data['accDate'] = $_REQUEST["accDate"];
	// 订单状态，0-未支付，1-支付成功，2-失败，4-部分退款，5-退款，9-退款处理中
	$data['orderStatus'] = $_REQUEST["orderStatus"];
	// 签名数据
	$data['signMsg'] = $_REQUEST["signMsg"];

	//print_r( $data);
	// 初始化
	$cMbPay = new MbPay($mbp_key, $mobaopay_gateway);
	// 准备准备验签数据
	$str_to_sign = $cMbPay->prepareSign($data);
	// 验证签名
	$resultVerify = $cMbPay->verify($str_to_sign, $data['signMsg']);
	//var_dump($data);
	if ($resultVerify) 
	{
		//
		
		$order_no = $data['orderNo'];
		$order_amount = $data['tradeAmt'];
		$order_amount=number_format($order_amount,2,".","");
		$return="return";
		if ('1' == $_REQUEST["notifyType"]) {
			$return="notify";
		}

		$signstr="order_no=".$order_no."&order_amount=".$order_amount."&return=".$return.$mbp_key;
		$sign=md5($signstr);
		$url="http://www.benpaobi.com/?s=Home/Fill/urlreturn&order_no=$order_no&order_amount=$order_amount&return=$return&sign=$sign";
		if ($data['orderStatus'] == '1'){
			if ('1' == $_REQUEST["notifyType"]) {
				if(function_exists('curl_init')){
					$pageContents=curl_get($url);
				}else{
					$pageContents=httpClient::quickGet($url);
					if($pageContents==""){
						$pageContents=file_get_contents($url);
					}
				}
				echo "SUCCESS";
			}else{
				echo "<script>location.href='".$url."';</script>";
				//echo $url;
			}
		}else{
			echo "失败";
		}
	}
	else
	{
		// 签名验证失败
		echo "验证签名失败";
	}

?>