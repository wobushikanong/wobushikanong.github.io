/**
 * 撤销委托
 * @param entrustId
 */
function cancelEntrustBtc(id){
	var url = "/trade/cancelEntrust.html?random="+Math.round(Math.random()*100);
	var param={id:id};
	jQuery.post(url,param,function(data){
		window.location.reload(true) ;
	});
}

function tradeTurnoverValue(){
	tradeTurnoverValue(0,null);
}
//type :0 默认 type=1 price type=2 amount
function tradeTurnoverValue(type,event){
	var isreturn = ctrlAorTab(event);
	if(isreturn){
		return;
	}
	var tradeType = document.getElementById("tradeType").value;
	var symbol = document.getElementById("symbol").value;
	var coinName = document.getElementById("coinName").value ;
	var tradeAmount = 0;
	var tradeCnyPrice = 0;
	if(type == 2){
		var  amountSelectionStart = getPositionForInput(document.getElementById("tradeAmount"));
		tradeAmount = document.getElementById("tradeAmount").value= checkNumberByName("tradeAmount");
		setCursorPosition(document.getElementById("tradeAmount"),amountSelectionStart);
	}else{
		tradeAmount = document.getElementById("tradeAmount").value;
	}
	if(type == 1){
		var  priceSelectionStart = getPositionForInput(document.getElementById("tradeCnyPrice"));
		tradeCnyPrice =document.getElementById("tradeCnyPrice").value =  checkNumberByName2("tradeCnyPrice",2);
		setCursorPosition(document.getElementById("tradeCnyPrice"),priceSelectionStart);
	}else{
		tradeCnyPrice =document.getElementById("tradeCnyPrice").value;
	}
	var turnover = tradeAmount*tradeCnyPrice;
	if(turnover!= null && turnover.toString().split(".")!=null && turnover.toString().split(".")[1] != null && turnover.toString().split(".")[1].length>4){
		turnover=turnover.toFixed(4);		
	}
	document.getElementById("tradeTurnover").value = turnover;
	if(tradeType ==0){
		var tradeTurnover = tradeAmount*tradeCnyPrice;
		if(document.getElementById("userBalance")!=null && Number(document.getElementById("userBalance").value) < Number(tradeTurnover)){
			alertTipsSpan("您的余额不足，请先充值");
			return;
		}else{
			clearTipsSpan();
		}
	}else{
		if(document.getElementById("userBalance")!=null && Number(document.getElementById("userBalance").value ) < Number(tradeAmount)){
				alertTipsSpan("您的"+coinName+"余额不足");
			return;
		}else{
			clearTipsSpan();
		}
	}
}
var check = 1;
function submitTradeBtcForm(){
	if(check == 2){
		return;
	}
	var tradeAmount =document.getElementById("tradeAmount").value;
	var tradeCnyPrice =document.getElementById("tradeCnyPrice").value;
	
	var tradePwd = "" ;
	if(document.getElementById("tradePwd")!=null){
		tradePwd = trim(document.getElementById("tradePwd").value);
	}
	var tradeType = document.getElementById("tradeType").value;
	var symbol = document.getElementById("symbol").value;
	var coinName = document.getElementById("coinName").value ;
	var isopen = document.getElementById("isopen").value;
	var islimited = document.getElementById("limitedType").checked;
	var limited = 0;
	if(!islimited){
		if(tradeType ==0){
			var tradeTurnover = tradeAmount*tradeCnyPrice;
			if(document.getElementById("userBalance")!=null &&  Number(document.getElementById("userBalance").value) <  Number(tradeTurnover)){
				alertTipsSpan("您的余额不足，请先充值");
				return;
			}else{
				clearTipsSpan();
			}
		}else{
			if(document.getElementById("userBalance")!=null &&  Number(document.getElementById("userBalance").value) <  Number(tradeAmount)){
				if(symbol == 0){
					alertTipsSpan("您的"+coinName+"余额不足");
				}else{
					alertTipsSpan("您的"+coinName+"余额不足");
				}
				return;
			}else{
				clearTipsSpan();
			}
		}
		 var reg = new RegExp("^[0-9]+\.{0,1}[0-9]{0,8}$");
		 if(!reg.test(tradeAmount) ){
			 alertTipsSpan("请输入交易数量");
			return;
		 }else{
				clearTipsSpan();
		}
		if(tradeAmount < 0.001){
			alertTipsSpan("最小交易数量为：0.001"+coinName+"！");
			return;
		}else{
			clearTipsSpan();
		}
		 if(!reg.test(tradeCnyPrice) ){
			 alertTipsSpan("请输入价格");
			return;
		 }else{
				clearTipsSpan();
		}	
	}else{
		limited = 1;
		var limitedMoney = Number(document.getElementById("limitedMoney").value);
		if(tradeType == 0){
			var nowPrice = accMul(0.001,Number(document.getElementById("nowPrice").value));
			if(limitedMoney < nowPrice){
				alertTipsSpan("最小购买0.001"+coinName);
				return;
			}
		}else{
			if(limitedMoney < 0.001){
				alertTipsSpan("最小卖出0.001"+coinName);
				return;
			}
		}
		if(tradeType ==0){
			if(document.getElementById("userBalance")!=null &&  Number(document.getElementById("userBalance").value) <  limitedMoney){
				alertTipsSpan("您的余额不足，请先充值");
				return;
			}else{
				clearTipsSpan();
			}
			tradeCnyPrice = limitedMoney;
		}else{
			if(document.getElementById("userBalance")!=null &&  Number(document.getElementById("userBalance").value) <  limitedMoney){
				if(symbol == 0){
					alertTipsSpan("您的"+coinName+"余额不足");
				}else{
					alertTipsSpan("您的"+coinName+"余额不足");
				}
				return;
			}else{
				clearTipsSpan();
			}
		}
		tradeAmount = limitedMoney;
	}
	if(tradePwd == "" && isopen != 1){
		alertTipsSpan("请输入交易密码");
		return;
	}else{
		document.getElementById("tradeBtcTips").style.display="";
		document.getElementById("tradeBtcTips").innerHTML="&nbsp;";
	}
	var url = "";
	if(tradeType ==0){
		url = "/trade/buyBtcSubmit.html?random="+Math.round(Math.random()*100);
	}else{
		url = "/trade/sellBtcSubmit.html?random="+Math.round(Math.random()*100);
	}
	tradePwd = isopen==1?"":tradePwd;
	var param={tradeAmount:tradeAmount,tradeCnyPrice:tradeCnyPrice,tradePwd:tradePwd,symbol:symbol,limited:limited};
	check = 2;
	jQuery.post(url,param,function(data){
		var result = eval('(' + data + ')');
		if(result!=null){
			if(result.resultCode != 0){
				check = 1;
			}
			if(result.resultCode == -400){
				 alertTipsSpan("现在不是交易时间！");
			}else if(result.resultCode == -301){
				 alertTipsSpan("买入价格必须高于当前买一价："+result.prize+"！");
			}else if(result.resultCode == -1){
				 if(tradeType ==0){
					 alertTipsSpan("最小购买数量为：0.001"+coinName+"！");
				 }else{
					 alertTipsSpan("最小卖出数量为：0.001"+coinName+"！");
				 }
			 }else if(result.resultCode == -2){
				 if(result.errorNum == 0){
					 alertTipsSpan("交易密码错误五次，请2小时后再试！");
				 }else{
					 alertTipsSpan("交易密码不正确！您还有"+result.errorNum+"次机会");
				 }
				 if(document.getElementById("tradePwd") != null){
					 document.getElementById("tradePwd").value = "";
				 }
			 }else if(result.resultCode == -3){
				 alertTipsSpan("出价不能为0！");
			 }else if(result.resultCode == -4){
				 alertTipsSpan("余额不足！");
			 }else if(result.resultCode == -5){
				 alertTipsSpan("您未设置交易密码，请到<font color='red'><a href='/user/security.html'>这里</a></font>设置交易密码。");
			 }else if(result.resultCode == -6){
				 okcoinAlert("您输入的价格与最新成交价相差太大，请检查是否输错",null,null,"");
			 }else if(result.resultCode == -8){
				 alertTipsSpan("请输入交易密码");
			 }else if(result.resultCode == -100){
				 alertTipsSpan("该币种不存在");
			 }else if(result.resultCode == -200){
				 alertTipsSpan("网络超时");
			 }else if(result.resultCode == 0){
				 window.location.href="/trade/coin.html?coinType="+symbol+"&tradeType="+tradeType+"&success=1" ;
			}
		}
	});	
}

function clearTipsSpan(){
	document.getElementById("tradeBtcTips").style.display="";
	document.getElementById("tradeBtcTips").innerHTML="";
}

function alertTipsSpan(tips){
	document.getElementById("tradeBtcTips").style.display="";
	document.getElementById("tradeBtcTips").innerHTML=tips;
}

function summoneyValue(event){
	var isreturn = ctrlAorTab(event);
	if(isreturn){
		return;
	}
	var tradeType = document.getElementById("tradeType").value;
	var symbol = document.getElementById("symbol").value;
	var coinName = document.getElementById("coinName").value ;
	var  turnoverSelectionStart = getPositionForInput(document.getElementById("tradeTurnover"));
	var tradeTurnover = document.getElementById("tradeTurnover").value=checkNumberByName("tradeTurnover");
	setCursorPosition(document.getElementById("tradeTurnover"),turnoverSelectionStart);
	var tradeCnyPrice = document.getElementById("tradeCnyPrice").value;
	var tradeAmount =document.getElementById("tradeAmount").value;
	tradeAmount = tradeTurnover/tradeCnyPrice;
	if(tradeAmount!= null && tradeAmount.toString().split(".")!=null &&tradeAmount.toString().split(".")[1] != null && tradeAmount.toString().split(".")[1].length>4){
		tradeAmount=tradeAmount.toFixed(5);		
		tradeAmount = tradeAmount.substring(0, tradeAmount.length-1);
	}
	document.getElementById("tradeAmount").value=tradeAmount;
	var reg=/^(-?\d*)\.?\d{1,4}$/;
    if(tradeTurnover!=null && tradeTurnover.toString().split(".")!=null && tradeTurnover.toString().split(".")[1]!=null && tradeTurnover.toString().split(".")[1].length>4){
    	if(!reg.test(tradeTurnover)){
        	document.getElementById("tradeTurnover").value = tradeTurnover.substring(0, tradeTurnover.length-1);
            return false;
        }
    }
	if(tradeType ==0){
		if(document.getElementById("userBalance")!=null && Number(document.getElementById("userBalance").value) < Number(tradeTurnover)){
			alertTipsSpan("您的余额不足，请先充值");
			return;
		}else{
			clearTipsSpan();
		}
	}else{
		if(document.getElementById("userBalance")!=null && Number(document.getElementById("userBalance").value ) < Number(tradeAmount)){
			if(symbol == 0){
				alertTipsSpan("您的"+coinName+"余额不足");
			}else{
				alertTipsSpan("您的"+coinName+"余额不足");
			}
			return;
		}else{
			clearTipsSpan();
		}
	}
}

function limitedSummoneyValue(){
	var limitedMoney = document.getElementById("limitedMoney");
	var tradeType = document.getElementById("tradeType").value;
	var length = tradeType==0?2:4;
	var priceSelectionStart = getPositionForInput(limitedMoney);
	var money =limitedMoney.value=(function (a) {return a.length > 1 ? a.shift().replace(/\D/g, '') + '.' + a.join('').replace(/\D/g, '').slice(0, length) : a[0].replace(/\D/g,'');})(limitedMoney.value.split('.'));
	setCursorPosition(limitedMoney,priceSelectionStart);
	var symbol = document.getElementById("symbol").value;
	if(tradeType == 0){
		var userBalance = Number(document.getElementById("userCnyBalance").value);
		if(money > userBalance){
			alertTipsSpan("您的余额不足，请先充值 ");
			return;
		}
	}else{
		var coinBalance = Number(document.getElementById("userCoinBalance").value);
		if(money > coinBalance){
			if(symbol == 0){
				alertTipsSpan("您的"+coinName+"余额不足");
			}else{
				alertTipsSpan("您的"+coinName+"余额不足");
			}
			return;
		}
	}
	clearTipsSpan();
}

function getEntrust(status){
	window.location.href = "/trade/entrust.html?status="+status;
}

function autoTrade(index,type,coinName){
	var priceNum = 0;
	var amountNum = 0;
	var tradeType = document.getElementById("tradeType").value;
	if(tradeType == type){
		type = type==0?1:0;
		if(type == 0){
			document.getElementById("buyDiv").style.display = "";
			document.getElementById("sellDiv").style.display = "none";
			document.getElementById("buyLi").className = "cur";
			document.getElementById("sellLi").className = "";
			document.getElementById("tradeType").value = 0;
			document.getElementById("priceSpan").innerHTML = "出价￥/"+coinName+":";
			document.getElementById("numSpan").innerHTML = "<span class=\"lightgreen5 fontsize-16\">购买数量</span>";
			document.getElementById("summoneySpan").innerHTML = "总金额";
			document.getElementById("btnA").innerHTML = "立即买入";
			document.getElementById("btnA").className = "buttonGreen";
			document.getElementById("userBalance").value = document.getElementById("userCnyBalance").value;
			tradeType = 0;
		}else{
			document.getElementById("sellDiv").style.display = "";
			document.getElementById("buyDiv").style.display = "none";
			document.getElementById("sellLi").className = "cur";
			document.getElementById("buyLi").className = "";
			document.getElementById("tradeType").value = 1;
			document.getElementById("priceSpan").innerHTML = "售价￥/"+coinName+":";
			document.getElementById("numSpan").innerHTML = "<span class=\"red fontsize-16\">卖出数量</span>";
			document.getElementById("summoneySpan").innerHTML = "兑换额CNY";
			document.getElementById("btnA").innerHTML = "立即售出";
			document.getElementById("btnA").className = "buttonRed";
			document.getElementById("userBalance").value = document.getElementById("userCoinBalance").value;
			tradeType = 1;
		}
	}
	var name = "sell";
	if(tradeType == 1){
		name = "buy";
	}
	var priceName = name+"Price"+index;
	var amountName = name+"Amount"+index;
	priceNum =	Number(document.getElementById(priceName).value);
	amountNum = Number(document.getElementById(amountName).value) ;

	var money = Number(document.getElementById("userBalance").value);
	var moneyNum = amountNum * priceNum;
	if(tradeType == 0){
		var reg=/^(-?\d*)\.?\d{1,2}$/;
		if(money!=null && money.toString().split(".")!=null && money.toString().split(".")[1]!=null && money.toString().split(".")[1].length>2){
			if(!reg.test(money)){
				var end =  money.toString().split(".")[1];
				if(end.length>2){
					end = end.substring(0, 2);
				}
				money = money.toString().split(".")[0]+"."+end;
			}
		}
		if(money < moneyNum){
			document.getElementById("tradeCnyPrice").value = priceNum;
			document.getElementById("tradeTurnover").value = money;
			summoneyValue(null);
		}else{
			document.getElementById("tradeCnyPrice").value = priceNum;
			document.getElementById("tradeAmount").value = amountNum;
			tradeTurnoverValue();
		}
	}else{
		var reg=/^(-?\d*)\.?\d{1,4}$/;
		if(money!=null && money.toString().split(".")!=null && money.toString().split(".")[1]!=null && money.toString().split(".")[1].length>4){
			if(!reg.test(money)){
				var end =  money.toString().split(".")[1];
				if(end.length>4){
					end = end.substring(0, 4);
				}
				money = money.toString().split(".")[0]+"."+end;
			}
		}
		if(money < amountNum){
			document.getElementById("tradeAmount").value = money;
			document.getElementById("tradeCnyPrice").value = priceNum;
			tradeTurnoverValue();
		}else{
			document.getElementById("tradeCnyPrice").value = priceNum;
			document.getElementById("tradeAmount").value = amountNum;
			tradeTurnoverValue();
		}
	}
}
function antoTurnover(money){
	var reg=/^(-?\d*)\.?\d{1,2}$/;
	if(money!=null && money.toString().split(".")!=null && money.toString().split(".")[1]!=null && money.toString().split(".")[1].length>2){
    	if(!reg.test(money)){
    		var end =  money.toString().split(".")[1];
    		if(end.length>2){
    			end = end.substring(0, 2);
    		}
    		money = money.toString().split(".")[0]+"."+end;
        }
    }
	document.getElementById("tradeTurnover").value = money;
	document.getElementById("limitedMoney").value = money;
	summoneyValue(null);
}
function antoAmount(money){
	var reg=/^(-?\d*)\.?\d{1,4}$/;
	if(money!=null && money.toString().split(".")!=null && money.toString().split(".")[1]!=null && money.toString().split(".")[1].length>4){
    	if(!reg.test(money)){
    		var end =  money.toString().split(".")[1];
    		if(end.length>4){
    			end = end.substring(0, 4);
    		}
    		money = money.toString().split(".")[0]+"."+end;
        }
    }
	document.getElementById("tradeAmount").value = money;
	document.getElementById("limitedMoney").value = money;
	tradeTurnoverValue();
}
function updateSecond(){
	var second = document.getElementById("updateSecond").value;
	var secondCookie = new CookieClass();
	secondCookie.setCookie("REFRESH_HANDLEENTRUST_TIME", second);
	if(entrustTime != null){
		clearTimeout(entrustTime);
	}
	if(updateTime != null){
		clearInterval(updateTime);
	}
	updateNumber = second/1000-1;
	updateTime = setInterval(updateNumberFun, 1000);
	entrustTime = setTimeout("handleEntrust("+second+")", second);
}
function autoSecond(time){
	var updateSecond = document.getElementById("updateSecond");
	for(var i=0;i<updateSecond.options.length;i++){
	if(updateSecond.options[i].value == time){
		updateSecond.options[i].selected = true;
		break;
		}
	}
	entrustTime = setTimeout("handleEntrust("+time+")", time);
	updateNumber = time/1000-1;
	if(updateTime != null){
		clearInterval(updateTime);
	}
	updateTime = setInterval(updateNumberFun, 1000);
}
function limitedTypeChange(){
	if(document.getElementById("limitedType").checked){
		document.getElementById("treadContTextDiv").style.display = "none";
		document.getElementById("treadContDiv").style.display = "none";
		document.getElementById("limitedDiv").style.display = "";
	}else{
		document.getElementById("treadContTextDiv").style.display = "";
		document.getElementById("treadContDiv").style.display = "";
		document.getElementById("limitedDiv").style.display = "none";
	}
}
function onPortion(portion){
	var tradeType = document.getElementById("tradeType").value;
	if(tradeType == 0){
		var money = Number(document.getElementById("userCnyBalance").value);
		var portionMoney = accMul(money,portion);
		antoTurnover(portionMoney);
	}else{
		var money = Number(document.getElementById("userCoinBalance").value);
		var portionMoney = accMul(money,portion);
		antoAmount(portionMoney);
	}
}

function planBuyLimitedTypeChange(obj,type){
	var value = obj.value;
	if(value ==1){
		document.getElementById("planBuyPrice").style.display = "none";
		document.getElementById("planBuyPriceTwo").style.display = "";
		document.getElementById("planBuyInputCny").style.display = "none";
		document.getElementById("planBuyInputCnyTwo").style.display = "";
		document.getElementById("planBuyAmount").style.display = "none";
		document.getElementById("planBuyAmountTwo").style.display = "";
		document.getElementById("planBuyCny").innerHTML = " ";
		document.getElementById("planBuyChen").style.display = "none";
		document.getElementById("planBuyEqual").style.display = "none";
	}else{
		document.getElementById("planBuyPrice").style.display = "";
		document.getElementById("planBuyPriceTwo").style.display = "none";
		document.getElementById("planBuyInputCny").style.display = "";
		document.getElementById("planBuyInputCnyTwo").style.display = "none";
		document.getElementById("planBuyAmount").style.display = "";
		document.getElementById("planBuyAmountTwo").style.display = "none";
		document.getElementById("planBuyCny").innerHTML = "总金额";
		document.getElementById("planBuyChen").style.display = "";
		document.getElementById("planBuyEqual").style.display = "";
	}
}

function planSellLimitedTypeChange(obj,type){
	var value = obj.value;
	if(value ==1){
		document.getElementById("planSellPrice").style.display = "none";
		document.getElementById("planSellPriceTwo").style.display = "";
		document.getElementById("planSellInputCny").style.display = "none";
		document.getElementById("planSellInputCnyTwo").style.display = "";
		document.getElementById("planSellCny").innerHTML = " ";
		document.getElementById("planSellChen").style.display = "none";
		document.getElementById("planSellEqual").style.display = "none";
	}else{
		document.getElementById("planSellPrice").style.display = "";
		document.getElementById("planSellPriceTwo").style.display = "none";
		document.getElementById("planSellInputCny").style.display = "";
		document.getElementById("planSellInputCnyTwo").style.display = "none";
		document.getElementById("planSellCny").innerHTML = "总金额";
		document.getElementById("planSellChen").style.display = "";
		document.getElementById("planSellEqual").style.display = "";
	}
}
//type =0 :最近10笔委托 type=1 历史成交
function entrustInfo(type,symbol,tradeType){
	var url  ="/trade/entrustInfo.html?type="+type+"&symbol="+symbol+"&tradeType="+tradeType+"&random="+Math.round(Math.random()*100);
	jQuery("#entrustInfo").load(url,null,function (data){
	});
}

function changeTradeTab(type,coinName){
		var nowPrice = document.getElementById("nowPrice") ;
		var recommendPrizebuy = document.getElementById("recommendPrizebuy") ;
		var recommendPrizesell = document.getElementById("recommendPrizesell") ;
		var tradeCnyPrice = document.getElementById("tradeCnyPrice") ;
		if(type == 0){
			nowPrice.value = recommendPrizebuy.value ;
			tradeCnyPrice.value = nowPrice.value ;
			document.getElementById("buyDiv").style.display = "";
			document.getElementById("sellDiv").style.display = "none";
			document.getElementById("buyLi").className = "cur";
			document.getElementById("sellLi").className = "";
			document.getElementById("tradeType").value = 0;
			document.getElementById("priceSpan").innerHTML = "出价￥/"+coinName+":";
			document.getElementById("numSpan").innerHTML = "<span class=\"lightgreen5 fontsize-16\">购买数量</span>";
			document.getElementById("summoneySpan").innerHTML = "总金额";
			document.getElementById("btnA").innerHTML = "立即买入";
			document.getElementById("btnA").className = "buttonGreen";
			document.getElementById("userBalance").value = document.getElementById("userCnyBalance").value;
			document.getElementById("limitpriceTitleName").innerHTML = "金额";
		}else{
			nowPrice.value = recommendPrizesell.value ;
			tradeCnyPrice.value = nowPrice.value ;
			document.getElementById("sellDiv").style.display = "";
			document.getElementById("buyDiv").style.display = "none";
			document.getElementById("sellLi").className = "cur";
			document.getElementById("buyLi").className = "";
			document.getElementById("tradeType").value = 1;
			document.getElementById("priceSpan").innerHTML = "售价￥/"+coinName+":";
			document.getElementById("numSpan").innerHTML = "<span class=\"red fontsize-16\">卖出数量</span>";
			document.getElementById("summoneySpan").innerHTML = "兑换额CNY";
			document.getElementById("btnA").innerHTML = "立即售出";
			document.getElementById("btnA").className = "buttonRed";
			document.getElementById("userBalance").value = document.getElementById("userCoinBalance").value;
			document.getElementById("limitpriceTitleName").innerHTML = "数量";
		}
		
		document.getElementById("tradeAmount").value = 0;
		tradeTurnoverValue();
}

function entrustLog(id){
	var $dialog = jQuery("#dialog") ;
//	$dialog.dialog( "close" );
	var url = "/trade/entrustLog.html?random="+Math.round(Math.random()*100);
	var param={id:id};
	jQuery.post(url,param,function(data){
		if(data!=null && data.result==true){
			$dialog.html(data.content) ;
			$dialog.dialog({ height: 260, width: 830, resizable: false,title:data.title,draggable: false});
		}
	},"json");
}