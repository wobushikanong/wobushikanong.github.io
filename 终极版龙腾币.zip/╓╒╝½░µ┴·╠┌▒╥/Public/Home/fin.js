﻿function submitFinForm2(){
		var sbank = document.getElementById("sbank").value ;
		var type = document.getElementById("finType").value;
		var random = document.getElementById("random").value;
		
		var minMoney = document.getElementById("minRecharge").value ;
		
		var money = 0;    
	   	var finMoneyRadio=document.getElementsByName("finMoney");
	    if(finMoneyRadio!=null){
	        var i;
	        for(i=0;i<finMoneyRadio.length;i++){
	            if(finMoneyRadio[i].checked){
	            	money =  finMoneyRadio[i].value;
	            	if(document.getElementById("number6").checked){
	            		money = document.getElementById("diyMoney").value;
	            	}
	            }
	        }
	    }
	    if(money.toString().indexOf(".")!=-1){
	    	money = money.toString().split(".")[0];
	    	money = money+(random.substring(1));
	    }else{
	    	money = money+(random.substring(1));
	    }
	    if(Number(money)<Number(minMoney) || isNaN(money)){
	    	okcoinAlert("最小充值金额为"+minMoney+"元","",null);
	    	return;
	    }
	    var bankID = -1;
	    var typeParam="";
	    if(type == 1){//支付宝网银
	    	var url = "/account/alipayManual.html?random="+Math.round(Math.random()*100);
	    	var param={money:money,type:type,sbank:sbank};
	    	jQuery.post(url,param,function(data){
	    		var result = data ;
	    		if(result!=null){
	    			if(result == -1){
	    				okcoinAlert("最小充值金额为"+minMoney+"元","",null);
	    			}else if(result == -2){
	    				okcoinAlert("充值金额不合法","",null);
	    			}
					
	    			document.getElementById("tips1").innerHTML="1. 登录您的银行网银，选择转账汇款，或者去银行柜台，要求转账汇款。";
    				document.getElementById("tips2").innerHTML="2. 按照下表填写银行汇款信息表单：";
    				document.getElementById("tips3").innerHTML="3. 然后根据要求和提示完成汇款。";
    				document.getElementById("tips2ul").style.display="none";
    				document.getElementById("alipayhandDiv").style.display="";
//	    				document.getElementById("tipsTenpay").style.display="none";
//	    		    	document.getElementById("tipsAlipay").style.display="none";
//	    		    	document.getElementById("tips6ul").style.display="none";
    				document.getElementById("specificStepBackground").className = "specificStepBackground2";
    				
    		    	
    		    	document.getElementById("bankMoney").innerHTML = result.money;
    		    	document.getElementById("subMoney").innerHTML = result.money;
    		    	document.getElementById("bankInfo").innerHTML = result.tradeId;
    		    	document.getElementById("desc").innerHTML = result.tradeId;
    		    	
    		    	document.getElementById("alipayhandDiv").style.display="";
    		    	document.getElementById("finButton").style.display="none";
    		    	document.getElementById("moneyDiv").style.display="none";
    		    	
    		    	refTenbody();

	    		}
	    		
	    		
	    		document.getElementById("fownerName").innerHTML = result.fownerName;
				document.getElementById("fbankNumber").innerHTML = result.fbankNumber;
				document.getElementById("fbankAddress").innerHTML = result.fbankAddress;
				
				document.getElementById("rfownerName").innerHTML = result.fownerName;
				document.getElementById("rfbankNumber").innerHTML = result.fbankNumber;
				document.getElementById("rfbankAddress").innerHTML = result.fbankAddress;
				
	    	});
	    	
	    	return;
	    }

	    document.getElementById("finTipsDiv").style.display="";
		dialogBoxShadow();
		
		var finButton = document.getElementById("finButton");
		finButton.target="_blank" ;
		finButton.href = "/account/pay/jump.html?type="+type+"&money=" + money+typeParam;  
	}
	
	

function submitFinForm(){
		var sbank = document.getElementById("sbank").value ;
		var type = document.getElementById("finType").value;
		var random = document.getElementById("random").value;
		var money = 0;    
	   	var finMoneyRadio=document.getElementsByName("finMoney");
	    if(finMoneyRadio!=null){
	        var i;
	        for(i=0;i<finMoneyRadio.length;i++){
	            if(finMoneyRadio[i].checked){
	            	money =  finMoneyRadio[i].value;
	            	if(document.getElementById("number6").checked){
	            		money = document.getElementById("diyMoney").value;
	            	}
	            }
	        }
	    }
	    if(money.toString().indexOf(".")!=-1){
	    	money = money.toString().split(".")[0];
	    	money = money+(random.substring(1));
	    }else{
	    	money = money+(random.substring(1));
	    }
	    if(money<100 || isNaN(money)){
	    	okcoinAlert("最小充值金额为"+100+"元","",null);
	    	return;
	    }
	    var bankID = -1;
	    var typeParam="";
	    
	    if(type == 2 || type == 3 || type == 4 || type==6){//支付宝手动
	    	var url = "/account/alipayManual.html?random="+Math.round(Math.random()*100);
	    	var param={money:money,type:type,sbank:sbank};
	    	jQuery.post(url,param,function(data){
	    		var result = data ;
	    		if(result!=null){
	    			if(result == -1){
	    				okcoinAlert("最小充值金额为1000元","",null);
	    			}else if(result == -2){
	    				okcoinAlert("充值金额不合法","",null);
	    			}else{
	    				window.location.href = "http://www.airtechnology.cn/account/PaySubmit?id="+result ;
		    		  	//refTenbody();
	    			}
	    			
	    		}
	    		
	    		
	    		/*document.getElementById("fownerName").innerHTML = result.fownerName;
				document.getElementById("fbankNumber").innerHTML = result.fbankNumber;
				document.getElementById("fbankAddress").innerHTML = result.fbankAddress;
				
				document.getElementById("rfownerName").innerHTML = result.fownerName;
				document.getElementById("rfbankNumber").innerHTML = result.fbankNumber;
				document.getElementById("rfbankAddress").innerHTML = result.fbankAddress;*/
				
	    	});
	    	
	    	return;
	    }

	    document.getElementById("finTipsDiv").style.display="";
		dialogBoxShadow();
		
		var finButton = document.getElementById("finButton");
		finButton.target="_blank" ;
		finButton.href = "/account/pay/jump.html?type="+type+"&money=" + money+typeParam;  
	}

function closeFinTipsDiv(){
	dialogBoxHidden();
	document.getElementById("finTipsDiv").style.display="none";
}

function showDiyMoney(type){
	if(type ==6){
		document.getElementById("diyMoney").style.display="";
		document.getElementById("randomSpan").style.display="";
	}else{
		document.getElementById("diyMoney").style.display="none";
		document.getElementById("randomSpan").style.display="none";
	}
}
function clearDiyMoney(){
	var diyMoney = document.getElementById("diyMoney").value;
	if("请输入金额" == diyMoney){
		document.getElementById("diyMoney").value = "";
	}
}

function changebank(id){
	jQuery("#banks").find("label").each(function() {
		jQuery(this).removeClass(" current");
	});
		jQuery("#label_" + id).addClass(" current");
}
var bankId = document.getElementsByName("bankID");
for(var i = 0;i < bankId.length;i++){
	bankId[i].onclick=function(){
	changebank(this.id);
	};
}

function moreBanks(){
	
	document.getElementById("li_Bank12").style.display="";
	//document.getElementById("li_Bank13").style.display="";
	document.getElementById("li_Bank14").style.display="";
	document.getElementById("li_Bank15").style.display="";
	document.getElementById("li_Bank16").style.display="";
	//document.getElementById("li_Bank17").style.display="";
	//document.getElementById("li_Bank18").style.display="";
	document.getElementById("li_Bank19").style.display="";
	//document.getElementById("li_Bank20").style.display="";
	document.getElementById("moreBanks").style.display="none";
}
/**
 * 支付宝人工操作 返回修改金额
 */
function backModifyMoney(){
	document.getElementById("alipayhandDiv").style.display="none";
	document.getElementById("finButton").style.display="";
	document.getElementById("moneyDiv").style.display="";
	document.getElementById("specificStepBackground").className = "specificStepBackground1";
}

function submitPaymentInformation(){
	if(confirm("您确定已经登陆网银给我们汇款了么？")){
		document.getElementById("alipayhandDiv").style.display="none";
		document.getElementById("blankRemittance").style.display="";
		document.getElementById("specificStepBackground").className = "specificStepBackground3";
	}
}

function submitTransferAccounts(){
	
	var bank = document.getElementById("fromBank").value;
	var account = document.getElementById("fromAccount").value;
	var payee = document.getElementById("fromPayee").value;
	var phone = document.getElementById("fromPhone").value;
	
	var obj =document.getElementsByName("fromType");
	var type = "";
	for(var i=0;i<obj.length;i++){
	    if(obj.item(i).checked){
	    	type=obj.item(i).getAttribute("value");  
	        break;
	     }else{
	    	 continue;
	  }
	}
	var desc = document.getElementById("desc").innerHTML;
	if(bank == "" || account == "" || payee == "" || phone== "" || type == "" || desc ==""){
		okcoinAlert("请填写完整信息！","",null);
    	return;
	}
	var url = "/account/rechargeCnySubmit.html?random="+Math.round(Math.random()*100);
	var param={bank:bank,account:account,payee:payee,phone:phone,type:type,desc:desc};
	jQuery.post(url,param,function(data){
		var result = eval('(' + data + ')');
		if(result!=null){
			if(result == -2){
				okcoinAlert("请填写完整信息！","",null);
			}else if(result == 0){
				document.getElementById("blankRemittance").style.display = "none";
				document.getElementById("TransferAccountsComplete").style.display = "block";
				document.getElementById("riskArea4").style.display = "";
				refTenbody();
				document.getElementById("specificStepBackground").className = "specificStepBackground4";
			}else if(result == -3){
				okcoinAlert("这个备注已经被使用！","",null);
			}
		}
	});
}

function updateFinTransactionReceive(fid,money,bank,bankNo,receiveName){
	document.getElementById("rfownerName").innerHTML = bank;
	document.getElementById("rfbankNumber").innerHTML = bankNo;
	document.getElementById("rfbankAddress").innerHTML = receiveName;
	
	document.getElementById("subMoney").innerHTML = money;
	document.getElementById("desc").innerHTML = fid;
	document.getElementById("finButton").style.display="none";
	document.getElementById("moneyDiv").style.display="none";
	document.getElementById("alipayhandDiv").style.display="none";
	document.getElementById("blankRemittance").style.display="";
	document.getElementById("TransferAccountsComplete").style.display="none";
	document.getElementById("specificStepBackground").className = "specificStepBackground3";
}

function cancelRechargeCNY(id){
	var f = confirm("确定取消本次充值吗？") ;
	if(f){
		var url = "/account/cancelRechargeCnySubmit.html?random="+Math.round(Math.random()*100);
		var param={id:id};
		jQuery.post(url,param,function(data){
			var result = eval('(' + data + ')');
			if(result!=null){
				window.location.reload(true) ;
			}
		}) ;
	}
}

function refTenbody(){
	var currentPage = document.getElementById("currentPage").value;
	var url = "/account/refTenbody.html?currentPage="+currentPage+"&random="+Math.round(Math.random()*100);
	jQuery("#Tenbody").load(url,null,function (data){
	});
}