// JavaScript Document
	var rmb = $("#RMB_total_assets")
	$(".rmb-all").html(rmb);
	var hu = $("#user-hover em").width();
	$("#user-hover").width(hu);
	var usersafety = $(".user-safety-r .cur").size();
	if (usersafety>4)
	  {
	  $('.user-safety-l dl span,.user-safety-l dl strong').addClass("safety160-2");
      $(".user-safety-l dl strong").text("高");
	  }
	else if (usersafety>2)
	  {
	  $('.user-safety-l dl span,.user-safety-l dl strong').addClass("safety160-1");
      $(".user-safety-l dl strong").text("中");
	  }
	else
	  {
	  $('.user-safety-l dl span,.user-safety-l dl strong').addClass("safety160-0");
      $(".user-safety-l dl strong").text("低");
	  };
	jQuery("#slide-show").slide();
	jQuery("#slide-topLoop").slide({mainCell:"ul",effect:"topLoop",autoPlay:true,pnLoop:false});
	jQuery("#slide-fade").slide({ titCell:".hd ul", mainCell:".bd ul",  autoPlay:true, autoPage:true,delayTime:700, trigger:"click",
		startFun:function(i){
			var curLi = jQuery("#slide-fade .bd li").eq(i); /* 当前大图的li */
			if( !!curLi.attr("_src") ){
				curLi.css("background-image",curLi.attr("_src")).removeAttr("_src") /* 将_src地址赋予li背景，然后删除_src */
			}
		}
	});
	// window.onload = function(){ 
	// document.getElementById('loginbar-bg').style.height=document.getElementById("loginbar").offseHeight-14+"px";
	// } 	;
	$(".icon_wen_msg").mouseleave(function(){
	  $(".dangqianyue-msg-box").hide();
	});
	$(".icon_wen_msg").mouseenter(function(){
	  $(".dangqianyue-msg-box").show();
	});
	$(".control-group select").wrap('<div  class="select_border"><div></div></div>');
	$("#form_add_buy_btc #btn-buy-entrust").toggle(function(){
	  $("#form_add_buy_btc .dangqianyue-msg").slideDown();
	  $(this).addClass("cur");
	  $("#form_add_buy_btc .trade-btnbg button").html("条件委托");
	  },
	  function(){
	  $("#form_add_buy_btc .dangqianyue-msg").slideUp();
	  $(this).removeClass("cur");
	  $("#form_add_buy_btc .trade-btnbg button").html("买入");
	  }
	);
	$("#form_add_sell_btc #btn-sell-entrust").toggle(function(){
	  $("#form_add_sell_btc .dangqianyue-msg").slideDown();
	  $(this).addClass("cur");
	  $("#form_add_sell_btc .trade-btnbg button").html("条件委托");
	  },
	  function(){
	  $("#form_add_sell_btc .dangqianyue-msg").slideUp();
	  $("this").removeClass("cur");
	  $("#form_add_sell_btc .trade-btnbg button").html("卖出");
	  }
	);
  $(".form-actions button,.loginbar button,.form-actions2 button,.trade-btnbg button").removeAttr("class");
  $(".subnav li i:last").remove();
  $(".trade-btn,.form-actions,.btn_button240,.icon_wen_msg2,.form-actions2,.part-account-msg,.part-business .md tr").hover(function(){ $(this).addClass("cur") },function(){ $(this).removeClass("cur") });
  $(".contall-part-l-box:first,#user-ners1 tr:first,#user-ners2 tr:first").addClass("first");
  $(".user-msg-all").hover(function(){ 
       $(this).addClass("cur");
  },
  function(){ $(this).removeClass("cur");
  $(".user-msg-all input").show();
  $(".user-msg-all .f-ff9900").hide();
  });
  $(".user-msg-all input").click(function(){
  $(".user-msg-all input").hide();
  $(".user-msg-all .f-ff9900").show();
  });
  $(".trade-all-form .hd").find("span").bind("click",function(){
	$(this).addClass("active ").siblings("span").removeClass("active "); 
	  var activeindex = $(".trade-all-form .hd").find("span").index(this);
	  $(".form_add_btc").children().eq(activeindex).show().siblings().hide();
	  return false;
  });
  $(".silde-market").toggle(function(){ $(this).addClass("cur").next().slideUp("slow");},function(){$(this).removeClass("cur").next().slideDown("slow");});
  $.jqchange = function(jqchange) {
	$(jqchange).change(function(){
		var price = parseInt($(".form_add_btc #price").val() * 100) /100;
		var amount = parseInt($(".form_add_btc #number").val() * 10000) /10000;
		var RMB_balance = parseInt($('#RMB_pure_balance').text() * 1000) /1000;
		 user_available = price * amount ;
		if (user_available > RMB_balance)
		  {
		number = parseInt((RMB_balance / price) * 10000) / 10000;
		$('.form_add_btc #number').val(number);
		$('.form_add_btc #sumprice').text( Math.round((number * price) * 100) / 100);
		 }
		 return false;
	  });	
  };
  $.jqchange(".form_add_btc #price");
  $.jqchange(".form_add_btc #number");
  $('.form_add_btc #numberSell').change(function(){
	  var amount = parseInt($('.form_add_btc #numberSell').val()* 10000) /10000;
	  var BTC_balance = parseInt($('#BTC_pure_balance').text()* 1000) /1000;
	  if ( BTC_balance < amount)
	     {
 		  $('.form_add_btc #numberSell').val(BTC_balance);
	     };
	});	

   //自动填入金额和数量



 function  autofill(){
 	
  $("#form_add_buy_btc #nice").css('cursor', 'pointer')
  $("#maxbuy").css("cursor", "pointer")
  $("#form_add_sell_btc #nice").css("cursor", "pointer")
  $("#maxsell").css("cursor", "pointer")


    $("#form_add_buy_btc #nice").bind('click', function() {
      $(" #price").val($(this).html())
    });
    $("#maxbuy").bind('click', function() {
      $(" #number").val($(this).html())
    });
    $("#form_add_sell_btc #nice").bind('click', function() {
      $("#priceSell").val($(this).html())
    });
    $("#maxsell").bind('click', function() {
      $("#numberSell").val($(this).html())
    });
  }
  autofill()


function change_sell_form(e) {
	  var price = $(e).find('.sub_price').html();
	  var amount = $(e).find('.sub_amount').html();
	  var BTC_balance = $('#BTC_pure_balance').text();
      $('.form_add_btc #priceSell').val(price);
	  if (BTC_balance>=amount)
	    {
           user_available = price * amount ;
         $('.form_add_btc #numberSell').val(amount);
         $('.form_add_btc #sumpriceSell').text( Math.round(user_available * 100) / 100 );		
		 
	   }
	    else
	     {
 		  $('.form_add_btc #numberSell').val(BTC_balance);
		   user_available2 = BTC_balance * price;
         $('.form_add_btc #sumpriceSell').text( Math.round(user_available2 * 100) / 100 );		
	     };
      
	  $(".trade-all-form .hd").children().eq(1).addClass("active").siblings().removeClass("active ");
	  $(".form_add_btc").children().eq(1).show().siblings().hide();
}
function change_buy_form(e) {
	  var price = parseInt($(e).find('.sub_price').text() * 100) /100;
	  var amount = parseInt($(e).find('.sub_amount').html() * 10000) /10000;
	  var RMB_balance = parseInt($('#RMB_pure_balance').text() * 100) /100;
	  user_available = price * amount ;
	  if (user_available < RMB_balance)
	    {
         $('.form_add_btc #number').val(amount);
		 $('.form_add_btc #sumprice').text(  Math.round((amount * price) * 100) / 100);
	   }
	    else
	     {
		  $('.form_add_btc #number').val( parseInt((RMB_balance / price) * 10000) / 10000);
		  $('.form_add_btc #sumprice').text( Math.round((parseInt((RMB_balance / price) * 1000) / 1000 * price) * 100) / 100);
	     };
      $('.form_add_btc #price').val(price);
	  $(".trade-all-form .hd").children().eq(0).addClass("active").siblings().removeClass("active ");
	  $(".form_add_btc").children().eq(0).show().siblings().hide();
}



