﻿function GetDataStr(StrUrl) {
     var oHttpReq = null;
    if (window.XMLHttpRequest) {
        oHttpReq = new XMLHttpRequest();
    }
    else {
        oHttpReq = new ActiveXObject("MSXML2.XMLHTTP");
    }
    oHttpReq.open("POST", StrUrl, false);
    oHttpReq.send("");
    result = oHttpReq.responseText;
 
    return result;
}
document.write(GetDataStr("/PubLic/IsLogin.html"));
