//图片轮播
var Sliderlen;
var curIndex;
function slideImg()
{
    var oldIndex=curIndex;
    curIndex=curIndex+1;
    if(curIndex > Sliderlen)
        curIndex=1;
    $(".bd ul li").removeClass().hide();
    $("#slider"+curIndex).addClass('GdCur').fadeIn(1000);
    $(".hd ul li").css('background','#fff');
    $("#slidertag"+(curIndex)).css('background','red');
}


$(document).ready(function () {
    Sliderlen=$('.bd ul li').length;
    curIndex=1;
    setInterval("slideImg()",3000);
    $('.hd ul li').click(function(){
        $(".bd ul li").hide();
        $("#slider"+$(this).html()).show();

        $(".hd ul li").css('background','#fff');
        $("#slidertag"+$(this).html()).css('background','red');
    });
});

//图片轮播
//跳转
function jumpLogin(){
    if(1==loginFlag){
        return true;
    }else{
        login();
        return false;
    }
}


function login(){
    //登陆注册部分
    var loginhtml;
    var page = {};
    layer.login = function(options){
        options = options || {};
        $.layer({
            type: 1,
            title: '用户登录',
            offset: [($(window).height() - 290)/2+'px', ''],
            border : [5, 0.5, '#666'],
            area: ['455px','275px'],
            shadeClose: true,
            page: page
        });
    };

    //如果已经请求过，则直接读取缓存节点
    if(loginhtml){
        page.html = loginhtml;
    } else {
        page.url = '/tpl/Home/userlogin.html'
        page.ok = function(datas){
            loginhtml = datas; //保存登录节点
        }
    }
    layer.login();
}

function loginDo(){
    var name=$('#loginname').val();
    var pwd=$('#loginpwd').val();
    var code=$('#logincode').val();
    if(name ==''){
        layer.tips('用户名不能为空', $('#loginname'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(pwd ==''){
        layer.tips('密码不能为空', $('#loginpwd'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(code ==''){
        layer.tips('验证码不能为空', $('#logincode'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }
    var loginload = layer.load(5,0); //需关闭加载层时，执行即可
    $.post("/?s=Home/Login/go", {
            Action: "post",
            username:name,
            password:pwd,
            code:code
        },
        function (data, textStatus){
            layer.close(loginload);
            if(1==data.flag){
                layer.load('登陆成功跳转中...…');
                window.location.href=data.url;
            }else{
                layer.msg(data.msg);
            }
        }, "json");
}
function loginDo2(){
    var name=$('#loginname2').val();
    var pwd=$('#loginpwd2').val();
    var code=$('#logincode2').val();
    if(name ==''){
        layer.tips('用户名不能为空', $('#loginname2'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(pwd ==''){
        layer.tips('密码不能为空', $('#loginpwd2'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(code ==''){
        layer.tips('验证码不能为空', $('#logincode2'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }
    var loginload = layer.load(5,0); //需关闭加载层时，执行即可
    $.post("/?s=Home/Login/go", {
            Action: "post",
            username:name,
            password:pwd,
            code:code
        },
        function (data, textStatus){
            layer.close(loginload);
            if(1==data.flag){
                layer.load('登陆成功跳转中...…');
                window.location.href=data.url;
            }else{
                layer.msg(data.msg);
            }
        }, "json");
}

//注册部分

function regDo(){

    var name=$('#reg_username').val();
    var pwd=$('#reg_password').val();
    var repwd=$('#reg_repassword').val();
    var email=$('#reg_email').val();
    var code=$('#reg_code').val();
    if(name ==''){
        layer.tips('用户名不能为空', $('#reg_username'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(pwd ==''){
        layer.tips('密码不能为空', $('#reg_password'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }
    if(pwd.length < 6 ||pwd.length>16){
        layer.tips('密码必须在6-16位之间!', $('#reg_password'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }
    if(pwd != repwd){
        layer.tips('两次密码不一致', $('#reg_repassword'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(email==''){
        layer.tips('邮箱不能为空!', $('#reg_email'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }

    if(code ==''){
        layer.tips('验证码不能为空', $('#reg_code'), {
            style: ['background-color:#0FA6D8; color:#fff', '#0FA6D8'],
            maxWidth:150
        });
        return;
    }


    var loginload = layer.load(5,0); //需关闭加载层时，执行即可
    $.post("/?s=Home/Login/insert", {
            Action: "post",
            username:name,
            password:pwd,
            email:email,
            code:code,
        },
        function (data, textStatus){
            layer.close(loginload);
            if(1==data.flag){
                layer.load('注册成功跳转中...…');
                window.location.href=data.url;
            }else{
                layer.msg(data.msg);
            }
        }, "json");
}



//充值部分
function getczdata(page){
    var loadi = layer.load('加载中…');
    $.ajax({
        type : "get",
        url : "/?s=Home/User/getchongzhidata/page/"+page,
        async : false,
        success : function(data){
            layer.close(loadi);
            var dataObj=eval("("+data+")");//转换为json对象
            var datalen=dataObj.data.length;
            var pagelen=dataObj.page.length;
            var i;
            var str='';
            var pagebody='';
            for(i=0;i<datalen;i++){
                str+='<tr id="del'+dataObj.data[i]['id']+'"><td class="chkTit">'+dataObj.data[i]['orderno']+'</td><td>'+
                    dataObj.data[i]['goldnum']+'</td><td>'+dataObj.data[i]['addtime']+'</td><td id="status'+dataObj.data[i]['id']+'">';

                if(dataObj.data[i]['status']=='0'){
                    str+='转账成功后超过3分钟没到的联系财务(<a href="javascript:void(0)"  onclick="czstatus('+dataObj.data[i]['id']+')"></a>)';
                }else if(dataObj.data[i]['status']=='-1'){
                    str+='<font color="red">等待网站管理员审核</font>';
                }else if(dataObj.data[i]['status']=='1'){
                    str+='<font color="green"><strong>充值成功</strong></font>';
                }
                str+='</td><td>'
                if(dataObj.data[i]['status']=='1')
                    str+='无';
                else
                    str+='<a href="javascript:void(0)" onclick="czapplyback('+dataObj.data[i]['id']+')">取消</a>';
                str+='</td></tr>';

            }

            //翻页部分
            pagebody+='<div class="pagination"><ul id="yw0" class="yiiPager">' +
                '<li class="first disabled"><a href="javascript:void(0)" onclick="getczdata(\'1\')">&lt;&lt; 首页</a></li>';

            for(i=0;i<pagelen;i++){
                pagebody+='<li class="previous"><a href="javascript:void(0)" onclick="getczdata(\''+(i+1)+'\')">'+dataObj.page[i]+'</a></li>';
            }

            pagebody+='<li class="last"><a href="javascript:void(0)" onclick="getczdata(\''+i+'\')">末页 &gt;&gt;</a></li>'+
                '</ul></div>';
            $('#page').html(pagebody);
            $('#czbody').html(str);

        }
    });
}


