﻿function STrim(str) {
    return str.replace(/^\s+/, '').replace(/\s+$/, '');
}
function $$(a) {
    return document.getElementById(a);
}
function GetData(StrUrl) {
     var oHttpReq = null;
    if (window.XMLHttpRequest) {
        oHttpReq = new XMLHttpRequest();
    }
    else {
        oHttpReq = new ActiveXObject("MSXML2.XMLHTTP");
    }
    oHttpReq.open("POST", StrUrl, false);
    oHttpReq.send("");
    result = oHttpReq.responseText;
 
    return result;
}

function ChangeStatus(str){
    var arrItem,l;
    var VPane=$$("NavHead")
    if(VPane!=null)
    {
        arrItem = VPane.getElementsByTagName("a");
		l= arrItem.length;
		for(var i=0;i<l;i++){
			if(arrItem[i].innerHTML.indexOf(str)>-1){
				arrItem[i].className = "curbtn";
				break;
			}
		}
    }
}

function copyToClipboard(txt) {
            if (window.clipboardData) {
                window.clipboardData.clearData();
                clipboardData.setData("Text", txt);
                alert("复制成功！");

            } else if (navigator.userAgent.indexOf("Opera") != -1) {
                window.location = txt;
            } else if (window.netscape) {
                try {
                    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
                } catch (e) {
                    alert("被浏览器拒绝！\n请在浏览器地址栏输入'about:config'并回车\n然后将 'signed.applets.codebase_principal_support'设置为'true'");
                }
                var clip = Components.classes['@mozilla.org/widget/clipboard;1'].createInstance(Components.interfaces.nsIClipboard);
                if (!clip)
                    return;
                var trans = Components.classes['@mozilla.org/widget/transferable;1'].createInstance(Components.interfaces.nsITransferable);
                if (!trans)
                    return;
                trans.addDataFlavor("text/unicode");
                var str = new Object();
                var len = new Object();
                var str = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);
                var copytext = txt;
                str.data = copytext;
                trans.setTransferData("text/unicode", str, copytext.length * 2);
                var clipid = Components.interfaces.nsIClipboard;
                if (!clip)
                    return false;
                clip.setData(trans, null, clipid.kGlobalClipboard);
                alert("复制成功！");
            }
        }
        
  function LoginJs()
  {
    if($$("TUserName").value=="")
    {
        alert("请输入用户名");
        return;
    }
    if($$("TUserPwd").value=="")
    {
        alert("请输入密码");
        return;
    }
   if($$("TUserSign").value=="")
    {
        alert("请输入验证码");
        return;
    }
    form1.submit();
  }