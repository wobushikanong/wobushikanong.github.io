﻿function ChangeStatus(str){
    var arrItem,l;
    var VPane=document.getElementById("NavLeft")
    if(VPane!=null)
    {
        arrItem = VPane.getElementsByTagName("dl");
		l= arrItem.length;
		for(var i=0;i<l;i++){
		if(arrItem[i].getElementsByTagName("dt")[0].innerHTML.indexOf(str)>-1){
				arrItem[i].className = "menu_dl2";
				break;
			}
		}
    }
}


function ClickLeftCol(Cid)
{
    var NHtml=Cid.innerHTML;
    var VPane=document.getElementById("NavLeft")
    var arrItem = VPane.getElementsByTagName("dd");
	var l= arrItem.length;
	for(var i=0;i<l;i++){
	if(arrItem[i].innerHTML.indexOf(Cid)!=-1)
	     arrItem[i].className = "current";
	}
}