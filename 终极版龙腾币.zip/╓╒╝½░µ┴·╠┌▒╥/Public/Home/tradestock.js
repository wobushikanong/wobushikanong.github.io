var resizeTimer, chart;
var coinName = document.getElementById("symbolName").value ;
jQuery(document).ready(function(){
	var datas = trade_global.time_line, rates = [], vols = [];
	for(i = 0; i < datas.length; i++){
		rates.push([datas[i][0], datas[i][2], datas[i][3], datas[i][4], datas[i][5]]);
		vols.push([datas[i][0], datas[i][1]]);
	}

	Highcharts.setOptions({
		colors: ['#DD1111', '#FF0000', '#DDDF0D', '#7798BF', '#55BF3B', '#DF5353', '#aaeeee', '#ff0066', '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
		lang: {
			loading: 'Loading...',
			months: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
			shortMonths: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
			weekdays: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
			decimalPoint: '.',
			numericSymbols: ['k', 'M', 'G', 'T', 'P', 'E'],
			resetZoom: 'Reset zoom',
			resetZoomTitle: 'Reset zoom level 1:1',
			thousandsSep: ','
		},
		credits: {enabled: false}
	});

	trade_global.main_chart = new Highcharts.StockChart({
		chart: { renderTo: 'graphbox', width: 775},
		xAxis: { type: 'datetime' },
		legend: { enabled: false },
		plotOptions: { candlestick: {color: '#f01717', upColor: '#0ab92b'} },
		tooltip: { xDateFormat: '%Y-%m-%d %H:%M %A', color: '#f0f', changeDecimals: 4, borderColor: '#058dc7' },
		scrollbar: {enabled: false},
		navigator: {enabled: false},
		rangeSelector: {
			buttons: [
				{type: 'minute', count: 60, text: '1h'},
				{type: 'minute', count: 120,text: '2h'},
				{type: 'minute', count: 360,text: '6h'},
				{type: 'minute', count: 720,text: '12h'},
				{type: 'day',    count: 1,  text: '1d'},
				{type: 'all', text: '所有'}
			],
			selected: 5,
			inputEnabled: false
		},
		yAxis: [
			{ labels: { style: { color: '#CC3300' } }, title: { text: '价格 [rmb]', style: { color: '#CC3300' } } },
			{ labels: { style: { color: '#4572A7' } }, title: { text: '成交量 ['+jQuery("#symbolName").val()+']', style: { color: '#4572A7' } }, opposite: true }
		],
		series: [
			{ animation: false, name: '成交量 ['+coinName+']', type: 'column', color: '#4572A7', marker: { enabled: false }, yAxis: 1, data: vols },
			{ animation: false, name: '价格 [RMB]', type: 'candlestick', marker: { enabled: false }, data: rates }
		]
	});
});