	jQuery("#indexLoginName").autocomplete({
		source: availableTags,
		autoFocus:false,
		matchContains:true
	});
	function showLoginError(){
		okcoinAlert("账户出现安全隐患已被冻结，请尽快联系客服。", null, null, "");
	}
	