function checkform(pid){
	var rs=1;
	$('#'+pid+' input').each(function(){
		if($(this).attr('name') == 'username'){
			filter=/^[a-zA-Z0-9_]{2,20}/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('用户名格式错误！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		}else if($(this).attr('name') == 'password'){
			filter=/^\S{6,20}/;
			filternum = /^[0-9]+$/;
			filterabc = /^[a-zA-Z]+$/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('密码格式错误！');
				rs=0;
				return false;
			}else  if(filterabc.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('不能是纯字母！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		
		}else if($(this).attr('name') == 'repassword'){
			filter=/^\S{2,20}/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('密码格式错误！');
				rs=0;
				return false;
			}else if($(this).val()!=$('#'+pid+' input[name="password"]').val()){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('两次输入的密码不同！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		}else if($(this).attr('name') == 'paypwd'){
			filter=/^\S{6,20}/;
			filternum = /^[0-9]+$/;
			filterabc = /^[a-zA-Z]+$/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('支付密码格式错误！');
				rs=0;
				return false;
			}else if(filternum.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('不能是纯数字！');
				rs=0;
				return false;
			}else if(filterabc.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('不能是纯字母！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		
		}else if($(this).attr('name') == 'repaypwd'){
			filter=/^\S{2,20}/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('支付密码格式错误！');
				rs=0;
				return false;
			}else if($(this).val()!=$('#'+pid+' input[name="paypwd"]').val()){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('两次输入的支付密码不同！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		}else if($(this).attr('name') == 'checkcode'){
			filter=/^[a-zA-Z0-9]{4}/;
			if(!filter.test($(this).val())){
				$('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('请输入验证码！');
				rs=0;
				return false;
			}else{
			    $('#'+pid+' [data-warn="'+$(this).attr('name')+'"]').text('√');
			}
		}
	});
	return rs;
}