function showMsg(str){
    document.getElementById('alertWin').style.display = 'block';
	document.getElementById('alertBg').style.display = 'block';
	document.getElementById('alert_text').innerText = str;

	var x = ($(window).width()-$('#alertWin').width())/2;
	var y = ($(window).height()-$('#alertWin').height())/2;
	$('#alertWin').css("top",y).css("left",x); 
}