function checkusername(obj){
    var myreg = /^[a-zA-Z]{1}[0-9a-zA-Z_]{1,}$/;
	if(obj.val()==''){
		return false;
	}else if(!myreg.test(obj.val())){
		return false;
	}
	return true;
}
function checkemail(obj){
    var myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(obj.val()==''){
		return false;
	}else if(!myreg.test(obj.val())){
		return false;
	}
	return true;
}
function checkpwd(obj){
    var numreg = /^\d+$/;
	var abcreg = /^[a-zA-Z]+$/;
	var myreg = /[a-zA-Z0-9_]{6,16}/;
	if(obj.val()==''||!myreg.test(obj.val())){
		return false;
	}else if(numreg.test(obj.val())){
		return false;
	}else if(abcreg.test(obj.val())){
		return false;
	}
	return true;
}
function checkcode(obj){
	if(obj.val()==''){
		return false;
	}
	return true;
}
function checkstr(obj){
	if(obj.val()==''||obj.val()==null){
		return false;
	}
	return true;
}
function checknum(obj){
    if(obj.val() == "" || isNaN(obj.val())||obj.val()<=0){
		return false;
	}
	return true;
}

