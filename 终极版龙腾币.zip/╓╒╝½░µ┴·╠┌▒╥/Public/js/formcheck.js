function checkusername(obj,warnobj){
    var myreg = /^\w+$/;
	if(!myreg.test(obj.val())){
		warn(warnobj,'请输入正确格式的用户名');
		setcss(obj,0);
		return false;
	}
	return true;
}
function checkemail(obj,warnobj){
    var myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	if(obj.val()==''){
		warn(warnobj,'邮箱不能为空');
		setcss(obj,0);
		return false;
	}else if(!myreg.test(obj.val())){
		warn(warnobj,'邮箱格式不正确');
		setcss(obj,0);
		return false;
	}
	return true;
}
function checkpwd(obj,warnobj){
    var numreg = /^\d+$/;
	var abcreg = /^[a-zA-Z]+$/;
	if(obj.val()==''||obj.val().length<6||obj.val().length>20){
		warn(warnobj,'长度必须6-20个字符!');
		setcss(obj,0);
		return false;
	}else if(abcreg.test(obj.val())){
		warn(warnobj,'不能是纯字母!');
		setcss(obj,0);
		return false;
	}
	return true;
}
function checkcode(obj,warnobj){
	if(obj.val()==''){
		warn(warnobj,'验证码不能为空!');
		setcss(obj,0);
		return false;
	}
	return true;
}
function chkStr(obj,warnobj,msg){
	if(obj.val()==''){
		warn(warnobj,msg);
		setcss(obj,0);
		return false;
	}
	return true;
}
function chknum(obj,warnobj,msg){
    if(obj.val() == "" || isNaN(obj.val())||obj.val()<=0){
		warn(warnobj,msg);
		setcss(obj,0);
		return false;
	}
	return true;
}
function chkgt(v1,v2,warnobj,msg){
    if(parseFloat(v1)>parseFloat(v2)){
		warn(warnobj,msg);
		setcss(obj,0);
		return false;
	}
	return true;
}
function recover(obj,warnobj){
    warnobj.html('');
	setcss(obj,1);
}
function warn(obj,text){
    obj.html('<font color=red>'+text+'</font>');
}
function setcss(obj,type){
	if(type==0){
		obj.css('border','1px solid #ff0000');
	}else{
		obj.css('border','1px solid #ddd');
	}
}

