<?php
return array(
	'DB_TYPE'=>'mysql',
	'DB_HOST'=>'localhost',
	'DB_PORT'=>'3306',
	'DB_NAME'=>'btc',
	'DB_USER'=>'root',
	'DB_PWD'=>'3396815',
	'DB_PREFIX'=>'t_',
	'APP_GROUP_LIST'=>'Admin,Home',
	'URL_MODEL'=>2,
	'DEFAULT_TIMEZONE'=>'Asia/Singapore',
	'SESSION_OPTIONS'   => array('name'=>'sid','expire'=>3600),
	'TMPL_ACTION_ERROR'=>'./Tpl/jump.html',
	'TMPL_ACTION_SUCCESS'=>'./Tpl/jump.html',
	'TMPL_CACHE_ON'=>false,
	'URL_DIR'=>'/?s=Home',
	'PUB_DIR'=>'/Public/Home/',
	'SMTP'=>'smtp.163.com',
    //交易最低价
    'low_price'=>1,
    //交易最高价
    'heigh_price'=>2,
    
    'qq_k'=>'', //QQ应用APP ID
    'qq_s'=>'',//QQ应用APP KEY
    'callback_url'=>'http://yoururl/callback.php', //授权回调网址
    'scope'=>'get_user_info,add_share', //权限列表，具体权限请查看官方的api文档
    
    
);
?>