<?php
class HallAction extends CommonAction {
	private $Type;
	private $TypeBox;
	private $User;
	private $GuaDan;
	private $TransLog;
	private $ChongZhi;
	private $MO;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
		$this->renzheng();
		$this->TypeBox = D('TypeBox');
		$this->Type = D('Type');
		$this->User = D('User');
		$this->GuaDan = D('GuaDan');
		$this->TransLog = D('TransLog');
		$this->ChongZhi = D('ChongZhi');
		$this->MO = new Model();
	}

    public function index(){
    	$m=M(Sys);
    	$r=$m->where("id=1")->find();

    	$this->assign('min_price',$r['min_price']);
    	$this->assign('max_price',$r['max_price']);
    	$this->assign('shouxufei',$r['shouxufei']);
    	
        $id=isset($_GET['id'])?(AlFilter($_GET['id'],'D')?$_GET['id']:die('Access error!')):1;//获取过滤id
        $this->assign('id',$id);
        //用户资金部分
        $UserMoney=$this->getUserMoney();
		$this->assign('UserMoney',$UserMoney[0]);
        //用户资金部分

        //币种选择部分
		$tb = $this->MO->table('t_type_box tb')->join(array('t_type t1 on t1.id=tb.name1','t_type t2 on t2.id=tb.name2'))->field('t1.nickname as goods,t2.nickname as coin,tb.*')->order('tb.id asc')->select();
        foreach($tb as $k => $v){
		    $ch = $this->TransLog->where('typeboxid='.$v['id'])->order('id desc')->limit(4)->select();
			$tb[$k]['ch']=$ch[0]['price']>$ch[2]['price']?'↑':'↓';
			$tb[$k]['price']=$ch[0]['price'];
		}
		$this->assign('tb',$tb);
       //币种选择部分


        //选中的币种
        $typeboxid = $id;
		if(chkNum($typeboxid)){
		    $value = $this->MO->table('t_type_box tb')->join(array('t_type t1 on t1.id=tb.name1','t_type t2 on t2.id=tb.name2'))->field('t1.nickname as goods,t1.sellmin,t1.sellmax,t2.nickname as coin,tb.*')->where('tb.id='.$typeboxid)->find();
		}else{
			$value = $this->MO->table('t_type_box tb')->join(array('t_type t1 on t1.id=tb.name1','t_type t2 on t2.id=tb.name2'))->field('t1.nickname as goods,t1.sellmin,t1.sellmax,t2.nickname as coin,tb.*')->order('tb.id asc')->find();
        }
        //结构:Array ( [goods] => 2HA [sellmin] => 1.00 [sellmax] => 50000.00 [coin] => RMB [id] => 1 [name1] => 7 [name2] => 5 [info] => [sort] => 0 )
		//$this->assign($value);

        $this->assign('goods',$value['goods']);



		//我的委托
		$myent = $this->GuaDan->where('userid='.$_SESSION['USER_KEY_ID'].' and typeboxid='.$value['id'])->order('id desc')->limit(20)->select();
		$this->assign('myent',$myent);
		$this->assign('ent_emp','<tr><td colspan=6>没有找到数据</td></tr>');

		//我的交易
		$mytrans = $this->TransLog->where('userid='.$_SESSION['USER_KEY_ID'].' and typeboxid='.$value['id'])->order('id desc')->limit(20)->select();
		$this->assign('mytrans',$mytrans);
		$this->assign('trans_emp','<tr><td colspan=5>没有找到数据</td></tr>');

		$translogs = $this->TransLog->where('zhu=1 and typeboxid='.$value['id'])->order('id desc')->limit(20)->select();
		$this->assign('translogs',$translogs);
		$this->assign('translog_emp','<tr><td colspan=5>没有找到数据</td></tr>');

        //卖
        $sell = $this->GuaDan->where('typeboxid='.$value['id'].' and flag=0')->field('*,SUM(num) as nums')->group('price')->order('price asc')->limit(7)->select();
		foreach($sell as $key => $val){
		    $sell[$key]['total'] = coin($sell[$key]['price'] * $sell[$key]['nums']);
		}
        $this->assign('sells',$sell);
        //买
		$buy = $this->GuaDan->where('typeboxid='.$value['id'].' and flag=1')->field('*,SUM(num) as nums')->group('price')->order('price desc')->limit(7)->select();
		foreach($buy as $key => $val){
		    $buy[$key]['total'] = coin($buy[$key]['price'] * $buy[$key]['nums']);
		}
        $this->assign('buys',$buy);
		$this->assign('empty','<tr><td colspan="3">没有找到数据！</td></tr>');

        $best_sell = $this->GuaDan->where('typeboxid='.$value['id'].' and flag=1')->max('price');
        $this->assign('maxin',$best_sell);

		$cz = $this->ChongZhi->where('typeid='.$value['name1'].' and userid='.$_SESSION['USER_KEY_ID'])->field('goldnum,gdgold')->find();

        $this->assign('sell_remain',$cz['goldnum']);
		$this->assign('sell_gdgold',$cz['gdgold']);
		$this->assign('ablenum',$cz['goldnum'] * $best_sell['maxprice']);

		$best_buy = $this->GuaDan->where('typeboxid='.$value['id'].' and flag=0')->min('price');
        $this->assign('minout',$best_buy);

		$cz = $this->ChongZhi->where('typeid='.$value['name2'].' and userid='.$_SESSION['USER_KEY_ID'])->field('goldnum,gdgold')->find();

        $this->assign('buy_remain',$cz['goldnum']);
		$this->assign('buy_gdgold',$cz['gdgold']);
		$this->assign('ablenumout',$best_buy>0 ? coin($cz['goldnum'] / $best_buy):0);



        //币总量
        $typeid =  $this->TypeBox->field('name1')->where('id='.$id)->find();

        //活币
        $Issue1=$this->ChongZhi->where('typeid='.$typeid['name1'])->sum('goldnum');
        //冻结币
        $Issue2=$this->ChongZhi->where('typeid='.$typeid['name1'])->sum('gdgold');
        //存币
        $Issue3=D('Bank')->where('typeid='.$typeid['name1'])->sum('coin');

        $this->assign('Issue',$Issue1+$Issue2+ $Issue3);

        //当前数据
        $gd = $this->TransLog->where('typeboxid='.$id)->order('id desc')->limit(4)->select();
        $now['now'] = $gd[0]['price'];
        $now['addtime'] = date('Y-m-d H:i:s',time());
        if($gd[0]['price'] > $gd[2]['price']){
            $now['flag'] = 1;
        }else{
            $now['flag'] = 0;
        }

        //最低成交价
        $gd = $this->TransLog->where('typeboxid='.$id)->order('price asc')->find();
        $now['low'] = $gd['price'];

        //最高成交价
        $gd = $this->TransLog->where('typeboxid='.$id)->order('price desc')->find();
        $now['high'] = $gd['price'];

        //成交量
        $now['volume'] = $this->TransLog->where('typeboxid='.$id)->sum('num');
        $this->assign('market',$now);

		$this->display('./Tpl/Home/hall.html');
    }

	function ent(){
		$per_num = 20;
        $page = is_numeric($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->GuaDan->where('userid='.$_SESSION['USER_KEY_ID'])->count();
        $page_num = ceil($count/$per_num);
		if($page < 1){
		    $page = 1;
		}elseif($page > $page_num){
		    $page = $page_num;
		}

	    $list = $this->GuaDan->where('userid='.$_SESSION['USER_KEY_ID'])->limit(($page-1)*$per_num.','.$per_num)->select();

		$this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=6>没有找到数据</td></tr>');
		$this->display('./Tpl/Home/order.html');
	}

	function trans(){
		$per_num = 20;
        $page = is_numeric($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->TransLog->where('userid='.$_SESSION['USER_KEY_ID'])->count();
        $page_num = ceil($count/$per_num);
		if($page < 1){
		    $page = 1;
		}elseif($page > $page_num){
		    $page = $page_num;
		}

	    $list = $this->TransLog->where('userid='.$_SESSION['USER_KEY_ID'])->limit(($page-1)*$per_num.','.$per_num)->select();

		$this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=5>没有找到数据</td></tr>');
		$this->display('./Tpl/Home/trans.html');
	}

	function alltrans(){
		$per_num = 20;
        $page = is_numeric($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->TransLog->where('zhu=1')->count();//总数
        $pagesize=ceil($count/$per_num);//总页数
        if($pagesize > 10){
            for($i=0;$i<5;$i++){
                $pagebody[$i]=$i+1;//12345
            }
            $pagebody['5']='......';
            for($i=0;$i<5;$i++){
                $pagebody[$i+6]=$pagesize-5+$i;//16 17 18 19 20
            }
            $morepage=1;
        }else{
            for($i=0;$i<$pagesize;$i++){
                $pagebody[$i]=$i+1;//12345
            }
            $morepage=0;
        }

        $this->assign('morepage',$morepage);
        $this->assign('pagebody',$pagebody);



        $page_num = ceil($count/$per_num);
		if($page < 1){
		    $page = 1;
		}elseif($page > $page_num){
		    $page = $page_num;
		}

	    $list = $this->TransLog->where('zhu=1')->limit(($page-1)*$per_num.','.$per_num)->order('id desc')->select();

		$this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=5>没有找到数据</td></tr>');
		$this->display('./Tpl/Home/all_trans.html');
	}

	function chart(){
        //生成K线json数据
         $arrId=$this->TypeBox->field('id')->select();
         foreach($arrId as $idarr){
             $id=$idarr['id'];
        $jumplimttime=5*60;//间隔时间
        $nearUpdateTime= getJsontime($id);
        $where = 'typeboxid='.$id.' and addtime > "'.date('Y-m-d H:i:s',$nearUpdateTime).'" and zhu=0';
        $arr = $this->TransLog->where($where)->field('addtime')->order('id asc')->select();
        $arrB=array();
        $mintime=$nearUpdateTime;
        if(!is_array($arr))
            return;
        //获取开始结束时间区间
        foreach($arr as $val){
           $vartime=strtotime($val['addtime']);
            if($vartime <= $mintime)
                continue;
            $mintime=$vartime-($vartime-$mintime)%$jumplimttime+$jumplimttime;
            $arrB[]=array('begin'=>$mintime-$jumplimttime,'end'=>$mintime);

        }
        $putstr='';
        $volmax=0;
        foreach($arrB as $val){
            $where = 'typeboxid='.$id.' and addtime BETWEEN "'.date('Y-m-d H:i:s',$val['begin']).'" AND "'.date('Y-m-d H:i:s',$val['end']).'" and zhu=0';
            $open = $this->TransLog->where($where)->order('id asc')->find();
            $close = $this->TransLog->where($where)->order('id desc')->find();
            $high = $this->TransLog->where($where)->max('price');
            $low = $this->TransLog->where($where)->min('price');
            $volume = $this->TransLog->where($where)->sum('num');
            $vartime=$val['begin']*1000;

            if(!$volume)$volume=0;
            if($volume)
                $putstr.=',['.$vartime.','.$volume.',"'. floatval($open['price']) .'",'.floatval($open['price']).
                    ','.floatval($low).','.floatval($high).','.floatval($close['price'])."]\n";
            if($volume > $volmax) $volmax = $volume;
        }
        addJson($id,$putstr);
      }
	}

    private function getUserMoney(){
        $chongzhi = $this->ChongZhi->join('t_type as t on t.id=t_chong_zhi.typeid')->field('t.nickname,t_chong_zhi.*')->where('userid=' . $_SESSION['USER_KEY_ID'])->select();
        foreach ($chongzhi as $key => $val) {
            $chongzhi[$key]['total'] = $val['goldnum'] + $val['gdgold'];
            $chongzhi[$key]['total'] = round($chongzhi[$key]['total'], 8);
        }
        $UserMoney[0]=$chongzhi[0]['total'];//总人民币余额
        $UserMoney[1]=$chongzhi[0]['total'];//总虚拟币余额
        return $UserMoney;
    }
}