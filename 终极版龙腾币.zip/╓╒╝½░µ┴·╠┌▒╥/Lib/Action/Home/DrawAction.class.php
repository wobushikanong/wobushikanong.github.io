<?php
class DrawAction extends CommonAction {
    private $Draw;
	private $User;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
		$this->checkReal();
	    $this->Draw = D('Draw');
		$this->User = D('User');
	}

	public function all(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Draw->where('uid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num);
        if($page > $page_num) $page = $page_num;

        $list=$this->Draw->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('mod','list');
		$this->assign('empty','<tr><td colspan="5" style="text-align:center">没有找到数据！</td></tr>');

		$this->display('./Tpl/Home/Draw_list.html');
    }

    public function index(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Draw->where('uid='.$this->auth['id'])->lock('true')->count();
        $page_num = ceil($count/$per_num);
        if($page > $page_num) $page = $page_num;

        $list=$this->Draw->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->lock('true')->select();

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('mod','list');
		$this->assign('empty','<tr><td colspan="5" style="text-align:center">没有找到数据！</td></tr>');

		$this->display('./Tpl/Home/Draw.html');
    }

	public function add(){
	    $this->display('./Tpl/Home/Draw.html');
	}

	public function insert(){
        $rmb = trim($_POST['num']);
		$paypwd = trim($_POST['paypwd']);
		$phonecode = trim($_POST['phonecode']);

        if(!chkNum($rmb)||!chkStr($paypwd)||!chkStr($phonecode)||$phonecode!=$_SESSION['chkphonecode']){echo 1;exit;}

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_draw write');
		$rs = array();
		$u = $mo->table('t_user')->where('id='.$this->auth['id'])->find();
		if($u['paypwd']!=$paypwd){echo 2;exit;}
		if($u['rmb']<$rmb){echo 3;exit;}

		$rs[] = $mo->table('t_draw')->add(array(
			'uid'=>$u['id'],
			'num'=>$rmb,
			'fee'=>$rmb*$this->sys['drawfee']/100,
			'rnum'=>$rmb-$rmb*$this->sys['drawfee']/100,
			'ctime'=>time()
		));

		$rs[] = $mo->table('t_user')->save(array(
		    'id'=>$u['id'],
			'rmb'=>array('exp','rmb-'.$rmb)
		));
		
		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			$this->assign('jumpUrl',C('URL_DIR').'/Draw');
		    //$this->success('提现申请已提交，请等待审核！');
			echo 0;
		}else{
			$mo->query('rollback');
		    //$this->error('提交失败!');
			echo 1;
		}
    }
}