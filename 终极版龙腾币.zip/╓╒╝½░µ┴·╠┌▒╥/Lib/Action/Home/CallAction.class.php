<?php
class CallAction extends CommonAction {
	public function __construct(){
		parent::__construct();
	}
    public function tixian(){
        $Arr =   D('User')->where('id=' . $_SESSION['USER_KEY_ID'])->field('moble')->find();
        if(isset($Arr['moble'])&&$Arr['moble']!=''){
           $pin=$this->getverifyCode();
            $content='您申请正在申请提现,验证码:'.$pin.'(请确保是你本人操作,请勿随意泄露本验证码!!)';
            $this->sendDo($Arr['moble'],$content,$pin);
        }
        else
           $this->ajaxShow('您还没有手机认证,请先去安全中心认证吧!');
    }

    public function run(){
        $phone=AlFilter($_REQUEST['phone'],'D');
        $pin=$this->getverifyCode();
        $content='您申请手机认证,验证码:'.$pin.'(请尽快填写认证,本消息免费,请勿回复!)';
        $this->sendDo($phone,$content,$pin);
	}

    private function sendDo($phone,$content,$pin){
        if(!$phone) $this->ajaxShow('手机号码不正确!');
        if(!preg_match("/^1[0-9]{2}[0-9]{8}/",$phone)) $this->ajaxShow('手机号码格式不正确!');
        $url='http://utf8.sms.webchinese.cn/?Uid=ouyuan1991&Key=4b8c96f4219d16ac04b9&smsMob='.$phone.'&smsText='.$content;
        $flag=$this->sedverifyCode($url);
        if($flag < 0 ){//发送不成功
            $this->ajaxShow('发送不成功,状态码:'.$flag.',请联系管理员!');
        }
        $_SESSION['pin'] = $pin;
        $_SESSION['phone'] = $phone;
        echo 1;
    }

    private function sedverifyCode($url)
    {
        if(function_exists('file_get_contents'))
        {
            $file_contents = file_get_contents($url);
        }
        else
        {
            $ch = curl_init();
            $timeout = 5;
            curl_setopt ($ch, CURLOPT_URL, $url);
            curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $file_contents = curl_exec($ch);
            curl_close($ch);
        }
        return trim($file_contents);
    }

    private function getverifyCode(){
        //随机生成一个4位数的数字验证码
        $num="";
        for($i=0;$i<6;$i++){
            $num .= rand(0,9);
        }
        return $num;
    }

    private function ajaxShow($content,$flag=null){
        if(!$flag){
            echo $content;
        }else{
            echo 1;
        }
        die;
    }
}