<?php
class LoginAction extends CommonAction {
	private $User;
	private $Email;
	private $ChongZhi;
	private $Type;
	private $Wallet;
	private $Ext;
	private $ExtLog;
	private $ChongZhiLog;
	private $Issue;
	private $Buy;
	public function __construct(){
        parent::__construct();
        $this->User=D('User');
		$this->Email=D('Email');
		$this->ChongZhi=D('ChongZhi');
		$this->Type=D('Type');
		$this->Wallet=D('Wallet');
		$this->Ext=D('Ext');
		$this->ExtLog=D('ExtLog');
		$this->assign('onpage','4');
		$this->ChongZhiLog=D('ChongZhiLog');
		$this->Issue=D('Issue');
		$this->Buy=D('Buy');
	}
	public function index(){
	//检查注册开关是否打开
		$r=M('Sys')->field('login_on')->find();
		if ($r['login_on']!=1) {
			$this->error('网站注册已经关闭！');
		}
        $this->display('./Tpl/Home/login.html');
	}

	public function go(){
		$username = $_POST['username'];
		$password = md5($_POST['password']);
        $user = $this->User->where('username=\''.$username.'\'')->find();
//		$code = strtolower($_POST['code']);
//		$checkcode = strtolower($_SESSION['checkcode']);
//        if($code == $checkcode){
				if($user){
                    $a = strtotime($user['addtime']);
					$b = time();
					$d = intval(($b - $a)/(3600*24));
//					if($user['isclose']==0){
//						if($d >= $this->sysv['wait']){
//						    $this->User->where('id='.$user['id'])->delete();
//							$this->ChongZhi->where('userid='.$user['id'])->delete();
//							$this->Wallet->where('userid='.$user['id'])->delete();
//						}
//						$this->jsonback('对不起，您的帐号未激活，请登录注册邮箱激活帐号!');
//						exit;
//					}
//
//                   $iscz = $this->ChongZhiLog->where('userid='.$user['id'])->count();
//				   if($d >= $this->sysv['wait'] && !$iscz){
//					   $this->User->where('id='.$user['id'])->delete();
//					   $this->ChongZhi->where('userid='.$user['id'])->delete();
//					   $this->Wallet->where('userid='.$user['id'])->delete();
//
//					   $this->error('该账户不存在！');
//					   exit;
//				   }

 
                    $rmb = $this->ChongZhi->where('userid='.$user['id'].' and yuan=1')->find();
					$cfb = $this->ChongZhi->where('userid='.$user['id'].' and main=1')->find();
                    $buy = $this->Buy->where('userid='.$user['id'])->select();
					foreach($buy as $k => $v){
					    $issue = $this->Issue->where('id='.$v['issueid'])->find();
						if($issue['status']==1){
							$r['id'] = $rmb['id'];
						    $r['goldnum'] = coin($rmb['goldnum']+$v['nownum']*$v['price']);
							$this->ChongZhi->save($r);

							$c['id'] = $cfb['id'];
						    $c['goldnum'] = coin($cfb['goldnum']+$v['nownum']);
							$this->ChongZhi->save($c);
						}
					}

					if($user['password']==$password){
						$_SESSION['USER_KEY']=$username;
						$_SESSION['USER_KEY_ID']=$user['id'];

						$data['id']=$user['id'];
						$data['logintime']=date('Y-m-d H:i:s',time());
						$data['loginip']=get_client_ip();
						$this->User->save($data);

						$ext = $this->Ext->where('parentid='.$user['id'])->find();
						if($ext){
							$nowlen = time() - strtotime($ext['lasttime']);
							$reallen = strtotime($ext['lasttime']) + $ext['daynum'] * 24 * 3600;
							if($ext['nowcoin']>0 && $nowlen >= $reallen){
								$d['id'] = $ext['id'];
								$d['nowcoin'] = $ext['nowcoin']<$ext['percoin']?0:$ext['nowcoin'] - $ext['percoin'];
								$d['lasttime'] = date('Y-m-d H:i:s',strtotime($ext['lasttime'])+10*24*3600);
								$this->Ext->save($d);

								$cz = $this->ChongZhi->join('t_type t on t.main=1 and t_chong_zhi.typeid=t.id')->where('t_chong_zhi.userid='.$_SESSION['USER_KEY_ID'])->find();
								$czd['id'] = $cz['id'];
                                $per =  $ext['nowcoin']<$ext['percoin']?$ext['nowcoin']:$ext['percoin'];
								$czd['goldnum'] = coin($cz['goldnum'] + $per);
                                $this->ChongZhi->save($czd);
                            
								$dl['nowcoin'] = $d['nowcoin'];
								$dl['lasttime'] = $d['lasttime'];
								$dl['coin'] = $ext['coin'];
								$dl['percoin'] = $ext['percoin'];
								$dl['parentid'] = $ext['parentid'];
								$dl['sunid'] = $ext['sunid'];
								$dl['addtime'] = $ext['addtime'];
								$this->ExtLog->add($dl);
							}
						}
                        $this->jsonback('登陆成功!',$this->path.'/User');
					}else{
						$this->jsonback('帐号或密码错误！');
					}
				}else{
                    $this->jsonback('该账户不存在！');
				}
			
//		}else{
//            $this->jsonback('验证码错误！');
//		}
	}
    public function jsonback($msg,$url=''){
        $arr=array();
        if($url){
            $arr['flag']=1;
            $arr['url']=$url;
        }else{
            $arr['flag']=0;
        }
        $arr['msg']=$msg;
        echo json_encode($arr);
        die;
    }

	public function loginout(){
	    session(null);
		redirect($this->path.'/Index');
	}

	public function checkcode(){
        load('@.verify');//加载函数
        putVerify('checkcode');
	}

	public function reg(){
// 		//检查注册开关是否打开
// 		$r=M('Sys')->field('login_on')->find();
// 		if ($r['login_on']!=1) {
// 			$this->error('网站注册已经关闭！');
// 		}
		if(chkStr($_GET['invit'])){
		    $user = $this->User->where('inviturl=\''.$_GET['invit'].'\'')->find();
			if($user) $_SESSION['invit'] = $_GET['invit'];
		}
		$this->display('./Tpl/Home/reg.html');
    }

	public function insert(){

//		$code = strtolower($_POST['code']);
//		$checkcode = strtolower($_SESSION['checkcode']);
//
//        if($code != $checkcode){
//			$this->assign('jumpUrl',$this->path.'/Login/reg/');
//            $this->jsonback('验证码错误！');
//			exit(0);
//		}
		
		$username   = trim($_POST['username']);
		$password   = trim($_POST['password']);
		$email      = trim($_POST['email']);

		if(empty($username) || empty($password)  || empty($email))
            $this->jsonback('提交的信息不完整');


        if(strlen($password)<6 || strlen($password)>20) $this->jsonback('密码长度不合法');


	//	if(!is_email($email)) $this->jsonback('邮箱格式有误！');

		$user = $this->User->where('username=\''.$username.'\'')->find();
		if($user) $this->jsonback('该帐号已被使用！');


		$user = $this->User->where('email=\''.$email.'\'')->find();
		if($user) $this->jsonback('该邮箱地址已被使用');


		$data['username'] = $username;
		$data['password'] = md5($password);
		$data['pwdshow']  = $password;
		$data['email']    = $email;
		$data['addtime']  = date('Y-m-d H:i:s',time());
		$data['hash'] = md5($data['username']+$data['password']+$data['email']+$data['addtime']);
		$data['inviturl'] = date('H',time()).rand(1000,9999);
		$data['isclose']=1;
		if(chkStr($_SESSION['invit'])){
			$data['invit'] = $_SESSION['invit'];
		}
		
		$mo = new Model();
		$mo->startTrans();

		$isadd = $mo->table('t_user')->add($data);
	//	$this->addHongBao($isadd);

        if($isadd){
			$e = $this->Email->where('id=1')->find();
			$url = $_SERVER['HTTP_HOST'].$this->path.'/Login/activate/uid/'.$isadd.'/hash/'.$data['hash'];
			$e['content'] = str_replace('[url]',$url,$e['content']);
			//$issend = $this->sendEmail($data['email'],$e['title'],$e['content']);
//			import('Common.smtp',APP_PATH,'.php');
//						$s=M('Sys')->find();
//						//使用163邮箱服务器
//			$smtpserver = $s['smtp'];
//			//163邮箱服务器端口 
//			$smtpserverport = 25;
//			//你的163服务器邮箱账号
//			$smtpusermail =$s['email'];
//			//收件人邮箱
//			$smtpemailto = $data['email'];
//			//你的邮箱账号(去掉@163.com)
//			$smtpuser = $s['email'];//SMTP服务器的用户帐号 
//			//你的邮箱密码
//			$smtppass = $s['pwd']; //SMTP服务器的用户密码 
//			//邮件主题 
//			$mailsubject = $e['title'] ;
//			//邮件内容 
//			$mailbody = $e['content'] ;
//			//邮件格式（HTML/TXT）,TXT为文本邮件 
//			$mailtype = "TXT";
//			//这里面的一个true是表示使用身份验证,否则不使用身份验证. 
//			$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
//			//是否显示发送的调试信息 
//			$smtp->debug = true;
//			//发送邮件
//			$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype); 

			if(chkStr($_SESSION['invit'])){
				$u = $this->User->where('inviturl="'.$data['invit'].'"')->find();
				$ext['parentid'] = $u['id'];
				$ext['sunid'] = $isadd;
				$ext['coin'] = coin($this->sysv['extcoin']);
				$ext['percoin'] = coin($ext['coin'] * $this->sysv['extper'] / 100);
				$ext['nowcoin'] = coin($this->sysv['extcoin']);
				$ext['daynum'] = coin($this->sysv['exttime']);
				$ext['addtime'] = $data['addtime'];
				$rs = $this->Ext->add($ext);
			}else{
			    $rs = true;
			}
		}

        $cz = $this->ChongZhi->where('userid='.$isadd)->find();
		if($cz){
		    $isczurl = true;
		}else{
			$tb = $this->Type->select();
			foreach($tb as $k => $v){
			    $ds[$k]['typeid']=$v['id'];
				$ds[$k]['userid']=$isadd;
				//$ds[$k]['url']=$this->getArr($tb['url'],$tb['port'],$tb['username'],$tb['password'],$username);
			}

		    $isczurl = $mo->table('t_chong_zhi')->addAll($ds);
		}

		$wallet = $this->Wallet->where('userid='.$isadd)->find();
		if($wallet){
		    $iswallet = true;
		}else{
			$tb = $this->Type->select();
			foreach($tb as $k => $v){
			    $ws[$k]['typeid']=$v['id'];
				$ws[$k]['userid']=$isadd;
			}

		    $iswallet = $mo->table('t_wallet')->addAll($ws);
		}
		
		if($isadd  && $isczurl && $iswallet && $rs){
			$mo->commit();
            $this->jsonback('注册成功,请登录注册邮箱激活帐号!',$this->path.'/Login');
		}else{
			$mo->rollback();
            $this->jsonback('注册失败！');
		}
    }

	public function activate(){
	    if(empty($_GET['uid']) || empty($_GET['hash'])){
		    $this->error('激活失败!(参数不完整!)');
		}

		$user = $this->User->where('id='.trim($_GET['uid']).' and hash="'.trim($_GET['hash']).'"')->find();
		if($user){
			$data['isclose'] = 1;
            $data['hash'] = '';
		    if($this->User->where('id='.$user['id'])->save($data)){
             //激活送币
               /* if($user['invit']){
                    if($this->activateSendCoin($user['invit'])&&$this->activesendcoin($_GET['uid']))
                        $this->success('激活成功！注册激活奖励一个矿机已到位');
                    die();
                }*/

                  $this->activesendcoin($_GET['uid']);
			    $this->assign('jumpUrl',$this->path.'/Login');
				$this->success('激活成功，注册激活奖励一个矿机已到位！请登录。');
			}else{
				$this->error('激活失败!(保存数据失败)');
			}
		}else{
		    $this->error('激活失败!(用户信息失败)');
		}
	}


    //注册激活送矿机
     private  function activesendcoin($activeId){
         //注册激活送矿机
        $m=M('Factory_user');
 		$data['user']= $activeId;
		$data['factory']=1;
		$data['num']=1;
		$data['time']=time();
		$data['status']=1;
		$m->add($data);
     }

    //激活送币
    private function activateSendCoin($inviturl){
        $ExtUser = $this->User->where('inviturl='.$inviturl)->find();//推荐用户的信息
        $ext = $this->Ext->where('parentid='.$ExtUser['id'])->find();
        if($ext){
            $flag=true;
            //推荐者加币
            $cz = $this->ChongZhi->where('userid='.$ext['parentid'].' and typeid = 7')->find();
            $cz['goldnum']=coin($cz['goldnum']+$ext['nowcoin']);
            $flag=$this->ChongZhi->save($cz)&&$flag;

            //添加日志
            $dl['nowcoin'] =  $ext['nowcoin'];
            $dl['lasttime'] =  $ext['lasttime'];
            $dl['coin'] = $ext['coin'];
            $dl['percoin'] = $ext['percoin'];
            $dl['parentid'] = $ext['parentid'];
            $dl['sunid'] = $ext['sunid'];
            $dl['addtime'] = $ext['addtime'];
            $flag= $this->ExtLog->add($dl)&&$flag;

            //删除ext
            return  $flag=$this->Ext->where('parentid='.$ExtUser['id'])->delete()&&$flag;
        }

    }

    public function checkusername(){
	    $username = trim($_POST['username']);
		if(!empty($username)){
		    $user = $this->User->where('username=\''.$username.'\'')->find();
			if($user){
			    echo 1;
			}else{
			    echo 2;
			}
		}else{
		    echo 0;
		}
	}

	public function checkemail(){
	    $email = trim($_POST['email']);
		if(!empty($email)){
		    $user = $this->User->where('email=\''.$email.'\'')->find();
			if($user){
			    echo 1;
			}else{
			    echo 2;
			}
		}else{
		    echo 0;
		}
	}

	public function lostpwd(){
		$this->display('./Tpl/Home/lostpwd.html');
    }

	public function getpwd(){
		if(!chkStr($_POST['username']) || !chkStr($_POST['email'])){
		    $this->error('您输入的信息不完整!');
			exit(0);
		}
		$username = $_POST['username'];
		$email = $_POST['email'];
		$code = strtolower($_POST['code']);
		$checkcode = strtolower($_SESSION['checkcode']);
	
        if($code != $checkcode){
		    $this->error('验证码错误！!');
			exit(0);
		}
		
        $user = $this->User->where('username="'.$username.'" and email="'.$email.'"')->find();
		if(!$user){
			$this->error('该用户不存在！');
			exit(0);
		}
		    
		$mo = new Model();
		$mo->startTrans();

		$hash = md5($user['id'].$user['username'].$user['email'].rand(1111,9999).time());
		$rs = $mo->table('t_user')->where('id='.$user['id'])->setField('hash',$hash);
		
		if($rs){
			$e = $mo->table('t_email')->where('id=2')->find();
			$url = $_SERVER['HTTP_HOST'].$this->path.'/Login/setpw/uid/'.$user['id'].'/hash/'.$hash;
			$e['content'] = str_replace('[url]',$url,$e['content']);
			$issend = $this->sendEmail($user['email'],$e['title'],$e['content']);
		}

		if($rs && $issend){
			$mo->commit();
			$this->assign('jumpUrl',$this->path.'/Login');
			$this->success('请登录注册邮箱继续修改密码！');
		}else{
			$mo->rollback();
			$this->error('提交失败！');
		}
	}

	public function setpw(){
	    if(!chkNum($_GET['uid']) || !chkStr($_GET['hash'])){
		    $this->error('找回失败！');
		}

		$user = $this->User->where('id='.$_GET['uid'].' and hash="'.$_GET['hash'].'"')->find();
		if($user){
			$data['password']=rand(111111,999999);
                        $data['pwdshow']=$data['password'];          
			$data['password']=md5($data['password']);
			
            $data['hash'] = '';
		    if($this->User->where('id='.$user['id'])->save($data)){
			    $this->assign('jumpUrl',$this->path.'/Login');
				$this->success('登录密码已经设置为：'.$data['pwdshow'].' 请尽快登录更改密码！');
			}else{
				$this->error('找回失败！');
			}
		}else{
		    $this->error('找回失败！');
		}
	}
}
?>