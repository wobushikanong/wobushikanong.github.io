<?php
class InviteAction extends CommonAction {
    private $User;
    private $Invite;
    private $Invitesys;


    public function __construct(){
        parent::__construct();
        $this->User = D('User');
        $this->Invite = D('Invite');
        $this->Invitesys=D('Invitsys');
         $this->renzheng();
    }

    public function index(){
        $InvitSys=$this->Invitesys->where('status = \'1\'')->find();

        if($InvitSys){//如果还有比赛运行在 那么就显示比赛的情况
            $pageSize=$InvitSys['shownum'];
            $Invite=$this->Invite->order('nums desc')->limit(0,$pageSize)->select();
            foreach($Invite as $key=>&$val){
                $val['mc']=$key+1;
                $val['moble']=substr($val['moble'],0,3).'******'.substr($val['moble'],7);
                $val['allsubuser']=unserialize($val['allsubuser']);
            }
            $this->assign('list',$Invite);
            $this->assign('taskno',$InvitSys['taskno']);
            $this->assign('content',$InvitSys['content']);
            $this->assign('time',strtotime($InvitSys['endtime'])-time());

            $this->showhistorylink();
            $this->display('./Tpl/Home/showinvit.html');
        }else{
            $InvitSys=$this->Invitesys->order('id desc')->find();
            $this->showPriceRes($InvitSys['taskno']);
        }

    }

    private function showhistorylink(){
        $showlink=$this->Invitesys->where('status = \'\'')->field('taskno')->select();
        $this->assign('showlink',$showlink);
    }

    public function showResult(){
        $taskno=isset($_GET['taskno'])?AlFilter($_GET['taskno'],'D'):die('非法!');
        $this->showPriceRes($taskno);
    }

    private function showPriceRes($taskno){
        $this->showhistorylink();
        $this->assign('taskno',$taskno);

        $res=D('inviteres')->where("taskno = '$taskno'")->select();
        $this->assign('list',$res);

        $this->display('./Tpl/Home/showinvitres.html');

    }




    public function findSame(){
//        $findUser=$this->User->where('moble <> \'\' and invit<> \'\' and card <> \'\' and xm <>')->select();
    }

//    public function init(){
//        set_time_limit(120);//多增加一段时间
//        $AllInvite=$this->User->where('moble <> \'\' and invit<> \'\' and card <> \'\' and xm <> \'\'')->select();
//
//        $Arr=array();
//        foreach($AllInvite as $val){
//
//            if(isset($Arr[$val['invit']])){
//                $Arr[$val['invit']]['nums']++;
//                $Arr[$val['invit']]['allsubuser'][]=array(
//                    'username'=>$val['username'],
//                    'name'=>$val['xm'],
//                    'time'=>$val['addtime'],
//                    'moble'=>substr($val['moble'],0,3).'******'.substr($val['moble'],7)
//                );
//            }else{
//                $Arr[$val['invit']]['nums']=1;
//                $Arr[$val['invit']]['allsubuser'][]=array(
//                    'username'=>$val['username'],
//                    'name'=>$val['xm'],
//                    'time'=>$val['addtime'],
//                    'moble'=>substr($val['moble'],0,3).'******'.substr($val['moble'],7)
//                );
//            }
//
//        }
//        echo '<pre>';
//        echo '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">';
////        print_r($AllInvite);
//        // print_r($Arr);
//
//
//        foreach($Arr as $key=>$val){
//
//            $UserA=$this->User->where("inviturl = $key")->field('id as user_id,xm as name,email,moble,username')->select()['0'];
//            $UserA['nums']=$val['nums'];
//            $UserA['allsubuser']=serialize($val['allsubuser']);
//            if($UserA['name'] ==''||$UserA['moble']==''){
//                echo '推广者信息不全!<br>';
//                continue;
//            }else if($A=$this->Invite->where("user_id =". $UserA['user_id'] ." and nums =". $UserA['nums'])->find()){
//                echo '本条已经添加过了!<br>';
//                continue;
//            }
//            $this->Invite->add($UserA);
////            print_r($UserA);
//        }
//
//    }




}