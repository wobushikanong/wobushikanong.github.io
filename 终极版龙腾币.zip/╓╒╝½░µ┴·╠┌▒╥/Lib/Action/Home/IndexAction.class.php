<?php
class IndexAction extends CommonAction {

	private $Ad;
	private $User;

	public function __construct(){
		parent::__construct();
		$this->Ad = D('Ad');
		$this->User = D('User');
	}

    public function index(){

        if(chkStr($_GET['invit'])){
		    $user = $this->User->where('invit=\''.$_GET['invit'].'\'')->find();
			if($user) $_SESSION['invit'] = $_GET['invit'];
		}
		//算力排行
    	$sql='SELECT SUM(allsuanli) AS allsuanli,a.user as id,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1) as a GROUP BY USER ORDER BY allsuanli DESC';
    	$list=M()->query($sql);
		//print_r($list);
        $this->assign('buy',$list);
        $sql='SELECT sum(j.money) as jiangli,j.upuser,u.id,u.username as username  FROM `t_factory_jiangli` as j JOIN t_user as u ON j.upuser=u.id  GROUP BY j.upuser order by jiangli desc';
        $jiangli=M()->query($sql);
        foreach($jiangli as $k=> $v){
            $r=M('User')->where("id={$v['username']}")->find();
            $jiangli[$k]['username']=substr($v['username'],0,1).'****'.substr($v['username'],-1,1);
        }
        $this->assign('jiangli',$jiangli);
        //推广人数
        $sql="SELECT COUNT(*) as num,invitup FROM `t_user` WHERE invitup!='' GROUP BY invitup order by num desc";
        $list=M()->query($sql);
        foreach ($list as $k =>$v){
            $user=M('User')->where("invit={$v['invitup']}")->find();
            $list[$k]['id']=$user['invit'];
        }
        $this->assign('tuiguang',$list);
        
		$coin = chkStr($_GET['coin']) ? $_GET['coin'] : 'kg';
		$this->assign('coin',$coin);

		$ad = M('Ad')->order('id asc')->select();
		$this->assign('ad',$ad);
		$_SESSION['back_url'] = __SELF__=='/'?$this->path.__ACTION__:__SELF__;
        $this->assign('notlogin',$_SESSION['notlogin']);

		$_SESSION['notlogin']=0;
		$this->assign('back_url',$_SESSION['back_url']);

		$this->display('./Tpl/Home/Index.html');
    }
}