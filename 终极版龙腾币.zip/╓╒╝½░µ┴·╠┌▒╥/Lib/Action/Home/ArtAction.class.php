<?php
class ArtAction extends CommonAction {
    private $Art;

	public function __construct(){
		parent::__construct();
	    $this->Art = D('Art');
	}

    public function index(){
        $id = $_GET['id'];
		$cate = $_GET['cate'];

		if(chkNum($id))
            $where = 'id='.$id;
		elseif(chkStr($cate))
            $where = 'cate="'.$cate.'"';

		$rs = $this->Art->where($where)->order('id asc')->find();
        $this->assign($rs);

		$list = $this->Art->where('cate="'.$rs['cate'].'"')->order('id asc')->select();
		$this->assign('list',$list);
		

		$about = $this->Art->where('cate="about"')->order('id asc')->select();
		$this->assign('about1',$about);

		$help = $this->Art->where('cate="help"')->order('id asc')->select();
		$this->assign('help1',$help);

		$news = $this->Art->where('cate="news"')->order('id asc')->select();
		$this->assign('news1',$news);

		$serv = $this->Art->where('cate="serv"')->order('id asc')->select();
		$this->assign('serv1',$serv);
        
		if($cate=='news')
 		    $this->display('./Tpl/Home/Art.html');
		else
			$this->display('./Tpl/Home/Art_view.html');
    }

}