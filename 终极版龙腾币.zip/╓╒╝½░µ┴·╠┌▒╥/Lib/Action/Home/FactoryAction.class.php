﻿<?php 
	class FactoryAction extends CommonAction{
	 public function __construct()
	    {	
	        parent::__construct();
	    }
	    //加载配置
	private  function getFactoryConfig(){
			$m=M('factory_config');
	        $factory_config=$m->find();
	        return $factory_config;
	}
	 public function  index(){
	 	$m=M('factory');
		$factory=$m
		->where("status=1 and id>1")
		->select();
		foreach ($factory as $k=>$v){
			$m=M('Type');
			$r=$m->where("id={$v['buytype']}")->find();
			switch ($v['buytype']){
			    case 1:$factory[$k]['buytypename']='TMC'; break;
			    case 2:$factory[$k]['buytypename']='TG'; break;
			    case 3:$factory[$k]['buytypename']='RMB'; break;
			}
			
		}
	
		//统计数据
		$m=M('Factory_log');
		$l=$m->sum('num');
		$this->assign('sum',$l);		
		$l2=$m->where("date(createtime) = curdate()")->sum('num');
		$this->assign('daynum',$l2);
	
		
		//购买记录
		$m=M('Factory_user');
		$user=session('USER_KEY_ID');
		$r=$m
		->field('t_factory.name as name,t_factory_user.id as id,t_factory_user.shouming,t_factory_user.shiyongshouming,t_factory_user.time as time,t_factory_user.num as num')
		->join('t_factory on t_factory_user.factory=t_factory.id')
		->where("user='$user'")
		->order('id desc')
		->limit(10)
		->select();
		$m=M('Factory_config');
		$config=$m->find();
		
	
		$this->assign('jianjie',$config['jianjie']);
		$this->assign('factoryBuy',$r);
		$this->assign('factory',$factory);
		$this->display('./Tpl/Home/factory_index.html');
	}
	//挖矿页面
	public function  wakuang(){
		$m=M('Factory_log');
		$user=session('USER_KEY_ID');
		$r=$m->where("user='$user'")->order("id desc")->limit(20)->select();
		$this->assign('shouhuo',$r);
		$id=session('USER_KEY_ID');
		
		$this->checshouming();
       //个人算力
		$m=new Model();
		$sql="SELECT SUM(allsuanli) AS allsuanli,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 AND t_factory_user.`user`={$id}) as a GROUP BY USER ORDER BY allsuanli DESC";
		$mysuanli=$m->query($sql);
		
			//总算力
		$m=M("Factory_allsuanli");
		$start=strtotime(date("Y-m-d",time()));
		$end=time();
		$where['createtime']=array('between',array($start,$end));
		$allsuanli=$m->where($where)->find();

	
		
		
		$m=M('Factory_config');
		$c=$m->find();
		$this->assign('config',$c);
		
			//统计数据
		$m=M('Factory_log');
		$l=$m->sum('num');
		$this->assign('sum',$l);
		
		$l2=$m->where("date(createtime) = curdate()")->sum('num');
		$this->assign('daynum',$l2);
		
		//预期个人收益
		$yuqishouyi=$c['oneDayNum']*$mysuanli[0]['allsuanli']/$allsuanli['allsuanli'];
		$this->assign("yuqishouyi",round($yuqishouyi,4));
		$this->assign('allsuanli',$allsuanli['allsuanli']?$allsuanli['allsuanli']:0);
		$this->assign("suanli",$mysuanli[0]['allsuanli']?$mysuanli[0]['allsuanli']:0);
		$this->display('./Tpl/Home/factory_wakuang.html');
	}
	//挖矿
	public function dowakuang(){
		$factory_config=$this->getFactoryConfig();
		$timecheck=$this->checkTime($factory_config);
	//	$iswakuang=$this->getiswakuang(session('USER_KEY_ID'));
		if ($factory_config['iswakuang']==0) {
			$data['id']=107;
			$data['info']="挖矿已关闭";
			$this->ajaxReturn($data);
			return ;
		}
		$myFactory=M('Factory_user')->where("status=1")->select();
		if (empty($myFactory)) {
			$data['id']=103;
			$data['info']='您还未购买矿机！';
			$this->ajaxReturn($data);
			return ;
		}
		if (M('Factory_line')->where("user='{$_SESSION["USER_KEY_ID"]}'")->find() ){
			$data['id']=104;
			$data['info']='您已经再挖矿！';
			$this->ajaxReturn($data);
			return ;
		}
		if (!$timecheck) {
			$data['id']=101;
			$data['info']='还未到开始挖矿时间！';
			$this->ajaxReturn($data);
			return ;
		}
		//矿机上线
		$data['user']=session('USER_KEY_ID');
		$data['time']=time();
		$data['suanli']=$this->getFactoryUser($_SESSION['USER_KEY_ID']);
		$m=M('Factory_line');
		$r=$m->add($data);
		//更新总算力
		$r2=$this->saveallsuanli();
		$map['user']=session('USER_KEY_ID');
		$map['status']=1;
		$u=M('Factory_user');
		//增加已经使用的寿命
	//	$u->where($map)->setInc('shiyongshouming',1);
		if ($r) {
			$data['id']=$r2;
			$data['info'].="开始挖矿";
		}else{
			$data['id']=$r2;
			$data['info']="挖矿出错，请稍后重试";
		}
		$this->ajaxReturn($data);
	}
	//本人算力
	public  function getFactoryUser($id){	    
	    $m=new Model();
	    $id=session('USER_KEY_ID');
	    $sql="SELECT SUM(allsuanli) AS allsuanli,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 AND t_factory_user.`user`={$id}) as a GROUP BY USER ORDER BY allsuanli DESC";
	    $r=$m->query($sql);
	    $suanli=$r[0]['allsuanli'];
	    return $suanli;
	}
	//收货
	public function shouhuo(){
		$config=$this->getFactoryConfig();
		$m=M('Factory_log');	
		if (!M('Factory_line')->where("user='{$_SESSION["USER_KEY_ID"]}'")->find()) {
			$data['id']=111;
			$data['info']="您没有矿机再工作";
			$this->ajaxReturn($data);
			return ;
		}
		if (!$this->shouhuotimecheck($config)) {
			$data['id']=101;
			$data['info']='还未到收获时间！';
			$this->ajaxReturn($data);
			return ;
		}
		
		$shouyi=$this->getcommonshouhuo();
		//挖矿日志
		$data['user']=session('USER_KEY_ID');
		$data['num']=$shouyi;
		$data['createtime']=time();
		$data['time']=1;
		$r=$m->add($data);		
		$data=array();
		if ($r) {
		    //删除在线矿机
		$this->deletLineFactory();
		  //增加挖矿收益
		  switch ($config['bizhong']){
		      case 1:$bizhong='xnb'; break;
		      case 2:$bizhong='ks';break;
		      case 3:$bizhong='rmb'; break;
		  }
		$r=M('User')->where("id={$_SESSION['USER_KEY_ID']}")->setInc($bizhong,$shouyi);
			$data['id']=110;
			$data['info']="本次挖矿收获{$shouyi}";
		}else {
			$data['id']=109;
			$data['info']="出错稍后再试";	
		}
		$this->ajaxReturn($data);
		
		
	}
	//矿机使用寿命到期
	function checshouming(){
		$user=session('USER_KEY_ID');
		$m=M('Factory_user');
		$id=session('USER_KEY_ID');
		$r=$m->where("user={$user}")->select();
		foreach ($r as $v){
			if ($v['shiyongshouming']>=$v['shouming']){
				//寿命到期删除
				$result[]=$m->where("id={$v['id']}")->setField('status',0);
			}else {
				$result[]=0;
			}
		}
			return $result;
		
	}
	//获取正常状况下收货
	function getcommonshouhuo(){
        $config=$this->getFactoryConfig();
		//本人算力
// 		$m=new Model();
// 		$sql="SELECT SUM(allsuanli) AS allsuanli,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 AND t_factory_user.`user`={$_SESSION['USER_KEY_ID']}) as a GROUP BY USER ORDER BY allsuanli DESC";
// 		$r=$m->query($sql);
// 		$suanli=$r[0]['allsuanli'];
        //获取本人当天算力
        $where=array('time',array(strtotime(date('y-m-d',time())),time()));
        $where['user']=$_SESSION['USER_KEY_ID'];
        $usersuanli=M('Factory_line')->where($where)->find();
        $suanli=$usersuanli['suanli'];
		//获取总算力
		$m=M("Factory_allsuanli");
		$t1=strtotime(date("Y-m-d",time()));
		$t2=time();
		$map['createtime']=array('between',array($t1,$t2));
		$r=$m->where($map)->find();
		$alllinesuanli=$r['allsuanli'];
		//收益=本人算力/在线总算力*一天收益总量
		$shouyi=$suanli/$alllinesuanli*$config['oneDayNum'];
		$shouyi=round($shouyi,4);
		return $shouyi;
	}
	//矿机上线的时候更新总算力
	function saveallsuanli(){
			//本人算力
		$m=new Model();
		$id=session('USER_KEY_ID');
		$sql="SELECT SUM(allsuanli) AS allsuanli,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 AND t_factory_user.`user`={$id}) as a GROUP BY USER ORDER BY allsuanli DESC";
		$r=$m->query($sql);
		$suanli=$r[0]['allsuanli'];
		
		$m=M("Factory_allsuanli");
		$start=strtotime(date("Y-m-d",time()));
		$end=time();
		$map['createtime']=array('between',array($start,$end));
		$r=$m->where($map)->find();
		if (!empty($r)) {
			$r2=$m->where("id={$r['id']}")->setInc('allsuanli',$suanli);
		}else {
			$data['allsuanli']=$suanli;
			$data['createtime']=time();
			$r2=$m->add($data);
		}
		if ($r2) {
			return true;
		}else {
			return FALSE;
		}

	}
	//删除在线矿机
	 function  deletLineFactory(){
		$m=M('Factory_line');
		$user=session('USER_KEY_ID');
		$r=$m->where("user='$user'")->delete();
		if ($r) {
			return 1;
		}else {
			return 0;
		}
	}
	//判断是否是在挖矿允许时间内
	public function checkTime($factory_config){
		$start=strtotime("today")+$factory_config['start'];
		$end=strtotime("today")+$factory_config['end'];
		if (time()>$start&&time()<$end) {
			return true;
		}else{
			return false;
		}
	}
	//检测是否在收获运行时间内
	private function shouhuotimecheck($factory_config){
	$start=strtotime("today")+$factory_config['shouhuostart'];
		$end=strtotime("today")+$factory_config['shouhuoend'];
		if (time()>$start&&time()<$end) {
			return true;
		}else{
			return false;
		}
	}
	
	//购买矿机
	public  function  buyFactory(){
		$buyFactoryId=$_POST['id'];
		$buyFactoryNum=$_POST['num'];
		$BuyMoneyType=$_POST['moneytype'];
		$factory=$this->getFactory($buyFactoryId);
		
		$config=$this->getFactoryConfig();
	     if ($buyFactoryId==1) {
	       $r= M('Factory_user')->where("user={$_SESSION['USER_KEY_ID']} and factory=1")->find();
	         if($r){
	             $data['id']=109;
	             $data['info']='不能重复领取';
	             $this->ajaxReturn($data);
	             exit();
	         }
	         
	     }
		if(intval($buyFactoryNum)<=0){
			$data['id']=105;
			$data['info']='您输入的购买个数有误';
			$this->ajaxReturn($data);
			exit();
		}
		$map['userid']=session('USER_KEY_ID');
		switch ($BuyMoneyType){
		    case 1:$field='xnb'; break;
		    case 2:$field='ks';break;
		    case 3:$field='rmb';break;
		}	
		switch ($factory['zengsong']){
		    case 1:$zfield='xnb'; break;
		    case 2:$zfield='ks';break;
		    case 3:$zfield='rmb';break;
		}
		if ($this->auth[$field]<$buyFactoryNum*$factory['price']) {
			$data['id']=102;
			$data['info']='余额不足';
			$this->ajaxReturn($data);
			exit();
		}
    	//增加购买记录
    		$m=M('factory_user');
    		$data=array(
    		    'factory'=>$buyFactoryId,
    		    'user'=>session('USER_KEY_ID'),
    		    'num'=>$buyFactoryNum,
    		    'shouming'=>1,
    		    'time'=>time(),
    		    'status'=>1
    		);
		     $r=$m->add($data);
			//减去user金额
    		$goldnum=$buyFactoryNum*$factory['price'];
    		$r=M('User')->where("id={$_SESSION['USER_KEY_ID']}")->setDec($field,$goldnum);
    		//增加赠送金额
    		$r=M('User')->where("id={$_SESSION['USER_KEY_ID']}")->setInc($zfield,$goldnum);
    		$this->jiangli($goldnum);
			$data['id']=101;
			$data['info']='购买成功';
			$this->ajaxReturn($data);
	}
	//奖励上线10%
function jiangli($goldnum){
		$id=session('USER_KEY_ID');
		//获取上线
		$m=M('User');
		$j=M('Factory_jiangli');
		$r=$m->field('invitup')->where("id={$id}")->find();
		if (!empty($r)) {
			$upid=$m->where("invit='{$r['invitup']}'")->find();
			$n=M('User')->where("id={$upid['id']}")->setInc("rmb",$goldnum*0.1);
			$data['user']=$id;
			$data['upuser']=$upid['id'];
			$data['money']=$goldnum*0.1;
			$data['status']=1;
			$data['time']=time();
			$j->add($data);
			return $n;
		}else {
			return FALSE;//$m->getLastSql();
		}
		
	}

	//增加factory_user num数量
	private function incFactoryUserNum($buyfactory){
		$m=M('Factory_user');
		$r=$m->where("id={$buyfactory['id']}")->setInc('num',$buyfactory['bum']);
		return $r;
	}
	//根据fatory id 返回factory信息
	private  function  getFactory($id){
		$m=M('factory');
		$factory=$m
		->where("id=$id")
		->find();
		return $factory;
	}
	
	//排行
	public function paihangbang(){
		$m=new Model();
		$sql='SELECT SUM(allsuanli) AS allsuanli,a.user as username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 ) as a GROUP BY USER ORDER BY allsuanli DESC LIMIT 20;';
		$r=$m->query($sql);
		$this->assign('suanli',$r);
		$this->display("./Tpl/Home/factory_paihangbang.html");
	}
	//邀请记录
	public function yaoqing(){
		import('ORG.Util.Page');// 导入分页类
		$m=M('Factory_jiangli');
		$u=M('User');
		$id=session('USER_KEY_ID');
		$count= $m->where("upuser=$id")->count();// 查询满足要求的总记录数
		$Page       = new Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数
		$show       = $Page->show();// 分页显示输出
		$show=str_replace('Factory', '?s=Factory',$show);

		$r=$m->where("upuser=$id")->limit($Page->firstRow.','.$Page->listRows)->select();
		foreach ($r as $k=> $v){
			$user=$u->where("id={$v['user']}")->find();
			$r[$k]['user']=$user['username'];
		}
		$this->assign('jiangli',$r);
		$this->assign('page',$show);// 赋值分页输出
		$this->display("./Tpl/Home/factory_yaoqing.html");
	}
		
}

	
?>