<?php
class PhoneAction extends CommonAction {

	public function __construct(){
		parent::__construct();
	}

    public function send(){
		$phone = chkStr($_POST['phone'])?$_POST['phone']:$this->auth['phone'];
		$_SESSION['chkphone'] = $phone;
		$_SESSION['chkphonecode'] = rand(111111,999999);
		$content="【奔跑币交易所】".$_SESSION['chkphonecode'].'一分钟内有效,请勿将此验证码告知他人';
        phone($phone,$content);
    }
}