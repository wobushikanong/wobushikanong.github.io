<?php
class InvitAction extends CommonAction {
    private $Invit;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
	    $this->Invit = D('Invit');
	}

    public function index(){

        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Invit->where('pid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num)>0?ceil($count/$per_num):1;
		if($page > $page_num) $page = $page_num;

        $list=M('Factory_jiangli')
			->join('t_user on t_user.id=t_factory_jiangli.user')
			->where("upuser={$_SESSION['USER_KEY_ID']}")
			->field('t_factory_jiangli.*,t_user.username,t_user.ctime as uctime')
			->limit(($page-1)*$per_num.','.$per_num)
			->select();
        $user=M('User')->where("id={$_SESSION['USER_KEY_ID']}")->find();
        $list1=M('User')
        ->where("invitup={$user['invit']}")
        ->limit(($page-1)*$per_num.','.$per_num)
        ->select();

        $this->assign('list',$list);
        $this->assign('list1',$list1);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="4" style="text-align:center">没有找到数据！</td></tr>');
        //$this->assign('url','http://'.$_SERVER['HTTP_HOST'].C('URL_DIR').'/Account/reg/invit/'.$this->auth['invit']);
		$this->assign('url','http://'.$_SERVER['HTTP_HOST'].'/?invit='.$this->auth['invit']);
		$this->display('./Tpl/Home/Invit.html');
    }

}