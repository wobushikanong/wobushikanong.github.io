<?php
class DuihuanAction extends CommonAction {

   public function __construct()
    {
        parent::__construct();
        $this->checkAuth();
    }
    public function index(){
        $User = M('Goods'); // 实例化User对象
        import('ORG.Util.Page');// 导入分页类
        $count      = $User->where("status=1")->count();// 查询满足要求的总记录数
        $Page       = new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->order('create_time')->where("status=1")->limit($Page->firstRow.','.$Page->listRows)->select();
      
        foreach ($list as $k=>$v ){
            $xnprice=$this->xnprice($v['price']);
            $list[$k]['xnpirce']=$xnprice['xnpirce'];
            $list[$k]['huilv']=$xnprice['huilv'];
        }

        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display('./Tpl/Home/Duihuan_index.html');
    }
    
    public function addorder(){
        $Order=D('Order');
        $Goods=M('Goods');
        $id=session('USER_KEY_ID');
        $user=M("Chong_zhi")->where("userid=$id and typeid={$_POST['type']}")->find();
        $goodid=$_POST['goodid'];
        $good=$Goods->where("id=$goodid")->find();
        $xnprice=$this->xnprice($good['price']);
        if ($_POST['type']==5){
            $price=$good['price'];
        }else {
            $price=$xnprice['xnpirce'];
        }
        if ($user['goldnum']<$price) {
            $this->error('您的余额不足');
        }
        
        if ($Order->create()) {
            $Order->userid=session('USER_KEY_ID');
            $Order->status=0;
            $Order->time=time();
            $Order->price=$price;
            $r=$Order->add();
            //减钱
            $r1=M("Chong_zhi")->where("userid=$id and typeid={$_POST['type']}")->setDec('goldnum',$price);
            if ($r) {
                $this->success('下单成功');
            }else {
                $this->error('下单失败');
            }
        }else {
            $this->error($Order->getError());
        }
    }
    public function order(){
        $User = M('Goods'); // 实例化User对象
        import('ORG.Util.Page');// 导入分页类
        $count      = M('Order')->where("t_order.userid={$_SESSION['USER_KEY_ID']}")->count();// 查询满足要求的总记录数
        $Page       = new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        $list=M('Order')->field("t_order.*,t_type.name,t_user.username,t_goods.title")
        ->join("t_type on t_type.id=t_order.type")
        ->join("t_user ON t_order.userid=t_user.id")
        ->join("t_goods on t_goods.id=t_order.goodid")
        ->where("t_order.userid={$_SESSION['USER_KEY_ID']}")
        ->order("id desc")
        ->limit($Page->firstRow.','.$Page->listRows)
        ->select();
        foreach ($list as $k=>$v){
            switch ($v['status']){
                case 0:$status='已提交';break;
                case 1:$status='已发货';break;
                case 2:$status='已完成';break;
            }
            $list[$k]['status']=$status;
        }
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->display("./Tpl/Home/Duihuan_order.html");
    }
    //获取虚拟币价格
    private function xnprice($price){
        $guadan=M('Gua_dan')->where("flag=1")->order("price desc")->find();
        $xnpirce=$price/$guadan['price'];
        $data['xnpirce']=ceil($xnpirce);
        $data['huilv']=$guadan['price'];
        return $data;
    }
}