<?php
class BuyAction extends CommonAction {
    private $Buy;
	private $Issue;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
		$this->checkReal();
	    $this->Buy = D('Buy');
		$this->Issue = D('Issue');

	}

	public function index(){
		
        $issue = $this->Issue->where('status=0')->find();
		$issue['cur'] = $issue['num']-$issue['deal'];
		$this->assign('issue',$issue);
		$sum = $this->Buy->where('iid='.$issue['id'].' and uid='.$this->auth['id'])->sum('num');
		$this->assign('sum',$sum);

	    $this->display('./Tpl/Home/Buy.html');
	}

	public function all(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Buy->where('uid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num) > 0 ? ceil($count/$per_num) : 1;
        if($page > $page_num) $page = $page_num;

        $list=$this->Buy->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

        foreach($list as $k => $v){
		    $list[$k]['num'] = floatval($v['num']);
			$list[$k]['ksper'] = floatval($this->sys['ksper']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="3" class="gray">没有记录！</td>');

		$this->display('./Tpl/Home/Buy_list.html');
    }

	public function insert(){
        $num = $_POST['num'];
		$paypwd = $_POST['paypwd'];
		if(!chkNum($num)) {$this->ajaxReturn('','请输入购买数量！',5);exit;}
		if($paypwd != $this->auth['paypwd']) {$this->ajaxReturn('','支付密码错误！',6);exit;}

		$mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_buy write,t_issue write,t_user write,t_invit write');
        $rs=array();

		$u = $mo->table('t_user')->where('id='.$this->auth['id'])->find();
		$buysum = $mo->table('t_buy')->where('uid='.$this->auth['id'])->sum('num');
		$issue = $mo->table('t_issue')->where('id='.$_POST['iid'].' and status=0')->find();

		if(!$issue) {$mo->query('rollback');$this->ajaxReturn('','认购活动已经结束！',2);exit;}
		if($issue['limit'] < $buysum+$num) {$mo->query('rollback');$this->ajaxReturn('','购买数量超过限制！',3);exit;}
		if($u['rmb'] < $issue['price']*$num) {$mo->query('rollback');$this->ajaxReturn('','余额不足！',4);exit;}

		$rs[] = $mo->table('t_buy')->add(array(
		    'uid'=>$this->auth['id'],
			'iid'=>$issue['id'],
			'price'=>$issue['price'],
			'num'=>$num,
			'ctime'=>time()
		));

		$rs[] = $mo->table('t_issue')->save(array(
		    'id'=>$issue['id'],
			'deal'=>array('exp','deal+'.$num)
		));

		$rs[] = $mo->table('t_issue')->where('num<=deal')->save(array(
		    'id'=>$issue['id'],
			'status'=>1
		));
 
        $rs[] = $mo->table('t_user')->save(array(
		    'id'=>$this->auth['id'],
			'xnb'=>array('exp','xnb+'.$num),
			'rmb'=>array('exp','rmb-'.($issue['price']*$num))
		));

		//奖励
		if(chkStr($u['invitup'])){
		    $upu = $mo->table('t_user')->where('invit="'.$u['invitup'].'"')->find();
			if($upu){
				$rs[] = $mo->table('t_user')->save(array(
					'id'=>$upu['id'],
					'ks'=>array('exp','ks+'.($this->sys['invitfen']*$num))
				));
				$rs[] = $mo->table('t_invit')->add(array(
					'pid'=>$upu['id'],
					'sid'=>$this->auth['id'],
					'num'=>$this->sys['invitfen']*$num,
					'ctime'=>time()
				));
			}
		}

		if(chkArr($rs)){
			$mo->query('commit');
			$this->ajaxReturn('','操作成功！',0);
		}else{
			$mo->query('rollback');
			$this->ajaxReturn('','操作失败！',1);
		}
	}
}