<?php
class GuaDanAction extends CommonAction {
    private $GuaDan;
    private $TypeBox;
    private $ChongZhi;
    private $User;
    private $Type;

    public function __construct(){
        parent::__construct();
        $this->checkAuth();
        $this->GuaDan = D('GuaDan');
        $this->TypeBox = D('TypeBox');
        $this->ChongZhi = D('ChongZhi');
        $this->User = D('User');
        $this->Type = D('Type');
        $this->renzheng();
    }

    public function index(){
        $per_num = 10;
        $page = is_numeric($_GET['page']) ? $_GET['page'] : 1;
        $count = $this->GuaDan->where('userid='.$_SESSION['USER_KEY_ID'])->count();
        $page_num = ceil($count/$per_num);
        if($page < 1){
            $page = 1;
        }elseif($page > $page_num){
            $page = $page_num;
        }

        $list=$this->GuaDan->join('t_type_box t on (t.id=t_gua_dan.typeboxid)')->join('t_type t1 on t1.id=t.name1')->join('t_type t2 on t2.id=t.name2')->where('t_gua_dan.userid='.$_SESSION['USER_KEY_ID'])->field('t_gua_dan.*,t.name1,t.name2,t1.nickname as names1,t2.nickname as names2')->limit(($page-1)*$per_num.','.$per_num)->select();

        $this->assign('list',$list);
        $this->assign('page',$page);
        $this->assign('page_num',$page_num);
        $this->display('./Tpl/Home/user_guadan.html');
    }

    public function work(){
        if(!$this->sysv['buyflag']){
            $this->error('购买开关未打开！');
        }
        if(!chkNum($_POST['typeboxid']) || !chkNum($_POST['price']) || !chkNum($_POST['num']) || !chkStr($_POST['transpw'])){
            $this->error("提交失败！");
            exit;
        }
     
        $m=M('Sys');
        $sys=$m->where("id=1")->find();
        $min_price=(float)$sys['min_price'];
        $max_price=(float)$sys['max_price'];
        $shouxufei=$sys['shouxufei'];
	
        if ((float)$_POST['price']<$min_price) {
        	$this->error("提交交易价格低于限制价格");
            exit;
        }
     	if ((float)$_POST['price']>$max_price) {
        	$this->error("提交交易价格超出限制价格");
            exit;
        }
        $u = $this->User->where('id='.$_SESSION['USER_KEY_ID'])->find();
        if(md5($_POST['transpw']) != $u['transpw']){
            $this->error('交易密码错误！');
            exit;
        }

        $price = coin($_POST['price']);//要么取整要么只留六位
        $num = $n = coin($_POST['num']);
        if($price==0||$num==0){
            $this->error('交易价格或者数量不能为空！');
        }

        if(!AlFilter($num,'D')){
            $this->error("数量必须为整数！");
            exit;
        }

        $tbid =  AlFilter($_POST['typeboxid'],'D')?$_POST['typeboxid']:5;
        $flag = AlFilter($_POST['flag'],'D')? $_POST['flag'] : 0;
        $userid = $_SESSION['USER_KEY_ID'];




        $mo = new Model();
        $mo->startTrans();

        $tb = $this->TypeBox->where('id='.$tbid)->find();

        $this->JQDCheck();//检测精度问题

        $t1_cz = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC
        $t2_cz = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name2'])->find();//RMB

        if($t1_cz['goldnum']<0||$t1_cz['gdgold']<0||$t2_cz['goldnum']<0||$t2_cz['gdgold']<0){
            $this->error('操作失败！（余额不够）');
        }

        if($flag==0){//sale
            if($num > $t1_cz['goldnum']) {
                $this->error('余额不够！');
            }
            
            $orders = $this->GuaDan->where('flag=1 and typeboxid='.$tbid.' and price>='.$price)->
                order('price desc,addtime asc,num desc')->select();

            if($orders){
                foreach($orders as $v){
                    $v['num']=coinInt($v['num']);
                    $v['price']=coin($v['price']);
                    if($n<=0||$v['num']<=0) break;
                    $trans = $n < $v['num'] ? $n : $v['num'];//成交量为       卖家要求的和买家有的之间的小者
                    $sum = coin($trans *  $v['price']);
                    if($n >= $trans){
                        $n = $n - $trans;
                    }else{
                        break;
                    }

                    //如果被自己买
                    if($v['userid'] == $userid ){
                        $cz_self = $this->ChongZhi->where('userid='.$v['userid'].' and typeid='.$tb['name2'])->find();//RMB
                        $rs['a'] = $mo->table('t_chong_zhi')->save(array(
                            'id' => $cz_self['id'],
                            'goldnum' => coin($cz_self['goldnum'] + $trans*$v['price']),
                            'gdgold' => coin($cz_self['gdgold'] - $trans*$v['price']),
                        ));
                        //挂单部分改变了
                        if($v['num'] > $trans){
                            $rs['b'] = $mo->table('t_gua_dan')->save(array(
                                'id'=>$v['id'],
                                'num'=>coin($v['num']-$trans)
                            ));
                        }else{
                            $rs['c'] = $mo->table('t_gua_dan')->where('id='.$v['id'])->delete();
                        }


                        $rs['d'] = $mo->table('t_trans_log')->add(array(
                            'sum' => $sum,
                            'price' => $v['price'],
                            'num' => $trans,
                            'flag' => 0,
                            'typeboxid' => $tbid,
                            'userid' => $userid,
                        	'fee'=>$sum*$shouxufei,
                        	 'realnum'=>$sum*(1-$shouxufei),
                            'addtime' => date('Y-m-d H:i:s',time())
                        ));

                        $rs['e'] = $mo->table('t_trans_log')->add(array(
                            'sum' => $sum,
                            'price' => $v['price'],
                            'num' => $trans,
                            'flag' => 1,
                            'zhu' => 1,
                            'typeboxid' => $tbid,
                            'userid' => $userid,
                	       'fee'=>$sum*$shouxufei,
                         'realnum'=>$sum*(1-$shouxufei),
                            'addtime' => date('Y-m-d H:i:s',time())
                        ));
					if ($sys['shouxufei_on']) {
                         
                        $shouxufei=$sum*$sys['shouxufei'];
                      
                        $this->ChongZhi->where("typeid=5 and userid={$userid} ")->setDec('goldnum',$shouxufei);//卖
                        $rs[] = $mo->table('t_shouxufei_log')->add(array(
                            'num' => $shouxufei,
                            'user' => $v['userid'],
                            'time' => time()
                        ));
                        /* $rs[]=$this->ChongZhi->where("typeid=5 and userid={$_SESSION['USER_KEY_ID']} ")->setDec('goldnum',$shouxufei);//买
                         $rs[] = $mo->table('t_shouxufei_log')->add(array(
                         'num' => $shouxufei,
                         'user' => $_SESSION['USER_KEY_ID'],
                         'time' => time()
                         ));*/
                    
                    }

                        continue;
                    }

                    $t1_ocz = $this->ChongZhi->where('userid='.$v['userid'].' and typeid='.$tb['name1'])->find();//CXC
                    $t2_ocz = $this->ChongZhi->where('userid='.$v['userid'].' and typeid='.$tb['name2'])->find();//RMB

                    if(coin($t2_ocz['gdgold']) < $sum){
                        //$this->error('Line136.gdgold less'.$t2_ocz['gdgold'].'|'.$sum.'|'.$v['userid'].'|'.$tb['name2']);
                        continue;
                    }

                    //每一轮及时获取卖家钱币变化
                    $t1_czB = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC
                    $t2_czB = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name2'])->find();//RMB
                    //卖家变化
                    if(coinInt($t1_czB['goldnum']) < $trans){
                        $this->error('Line:95|'.$t1_czB['goldnum'].'|'.$trans);
                    }

                    $rs['f'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $t1_cz['id'],
                        'goldnum' => coin($t1_czB['goldnum'] - $trans)
                    ));//CXC

                    $rs['g'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $t2_cz['id'],
                        'goldnum' => coin($t2_czB['goldnum'] + $sum)
                    ));//RMB



                    //买入方
                    $rs['h'] = $mo->table('t_chong_zhi')->save(array(
                        'id'=>$t1_ocz['id'],
                        'goldnum'=>coin($t1_ocz['goldnum'] + $trans)
                    ));

                    if(coinInt($t2_ocz['gdgold'])  < $sum){
                        $this->error('Line:116|'.$t2_ocz['gdgold'].'|'.$sum);
                    }

//                    $bsum = coin($trans * $v['price']);
                    $rs['i'] = $mo->table('t_chong_zhi')->save(array(
                        'id'=>$t2_ocz['id'],
                        'gdgold'=>coin($t2_ocz['gdgold'] - $sum)
                    ));



                    if($v['num'] > $trans){
                        $rs['j'] = $mo->table('t_gua_dan')->save(array(
                            'id'=>$v['id'],
                            'num'=>coin($v['num']-$trans)
                        ));
                    }else{
                        $rs['k'] = $mo->table('t_gua_dan')->where('id='.$v['id'])->delete();
                    }

                    // 写日志的暂时忽略
                    $rs['l'] = $mo->table('t_trans_log')->add(array(
                        'sum' => $sum,
                        'price' => $v['price'],
                        'num' => $trans,
                        'flag' => 0,
                        'typeboxid' => $tbid,
                        'userid' => $userid,
                         'fee'=>$sum*$shouxufei,
                     'realnum'=>$sum*(1-$shouxufei),
                        'addtime' => date('Y-m-d H:i:s',time())
                    ));

                    $rs['m'] = $mo->table('t_trans_log')->add(array(
                        'sum' => $sum,
                        'price' => $v['price'],
                        'num' => $trans,
                        'flag' => 1,
                        'zhu' => 1,
                        'typeboxid' => $tbid,
                        'userid' => $v['userid'],
                          'fee'=>$sum*$shouxufei,
                    'realnum'=>$sum*(1-$shouxufei),
                        'addtime' => date('Y-m-d H:i:s',time())
                    ));
                    if ($sys['shouxufei_on']) {
                         
                        $shouxufei=$sum*$sys['shouxufei'];
                      
                        $this->ChongZhi->where("typeid=5 and userid={$userid} ")->setDec('goldnum',$shouxufei);//卖
                        $rs[] = $mo->table('t_shouxufei_log')->add(array(
                            'num' => $shouxufei,
                            'user' => $v['userid'],
                            'time' => time()
                        ));
                        /* $rs[]=$this->ChongZhi->where("typeid=5 and userid={$_SESSION['USER_KEY_ID']} ")->setDec('goldnum',$shouxufei);//买
                         $rs[] = $mo->table('t_shouxufei_log')->add(array(
                         'num' => $shouxufei,
                         'user' => $_SESSION['USER_KEY_ID'],
                         'time' => time()
                         ));*/
                    
                    }
                    
                }
				  
                if($n > 0){

                    //挂单显示
                    $data['price'] = coin($price);
                    $data['num'] = coinInt($n);
                    $data['flag'] = 0;
                    $data['typeboxid'] = $tbid;
                    $data['userid'] = $userid;
                    $data['addtime'] = date('Y-m-d H:i:s',time());

                    $rs['n'] = $mo->table('t_gua_dan')->add($data);

                    //冻结这部分诚信币

                    $t1_czC = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC

                    //CXC数量减少，挂单数量增加
                    if(coinInt($t1_czC['goldnum'])   < coinInt($n)){
                        $this->error('Line:176|'.$t1_czC['goldnum'].'|'.$n);
                    }


                    $rs['o'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $t1_czC['id'],
                        'goldnum' => coin($t1_czC['goldnum'] - $n),
                        'gdgold' => coin($t1_czC['gdgold'] + $n)
                    ));
                } 		

                if(chkArr($rs)){
                    $mo->commit();
                    $this->success('提交成功(有成交)！');
                }else{
                    $mo->rollback();
                    $this->error('提交失败（1）！');
                }
            }else{
                $data['price'] = coin($price);
                $data['num'] = coinInt($num);
                $data['flag'] = 0;
                $data['typeboxid'] = $tbid;
                $data['userid'] = $userid;
                $data['addtime'] = date('Y-m-d H:i:s',time());
                $rs1 = $mo->table('t_gua_dan')->add($data);

                $t['id'] = $t1_cz['id'];


                $t1_czD = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC

                if(coinInt($t1_czD['goldnum'])   < $n){
                    $this->error('Line:205|'.$t1_czD['goldnum'].'|'.$num);
                }

                $t['goldnum'] = coin($t1_czD['goldnum'] - $num);
                $t['gdgold'] = coin($t1_czD['gdgold'] + $num);

                $rs2 = $mo->table('t_chong_zhi')->save($t);

                if($rs1 && $rs2){
                    $mo->commit();

                    $this->success('提交成功（完全无成交挂单）！');
                }else{
                    $mo->rollback();
                    $this->error('提交失败（2）！');
                }
            }
        }else{//buy
            $total = coin($num * $price);
            if($total > $t2_cz['goldnum']) {
                $this->error('余额不够！');exit;

            }
			$buy_user=M('User')->where("id={$_SESSION['USER_KEY_ID']}")->find();
            $orders = $this->GuaDan->where('flag=0 and typeboxid='.$tbid.' and price<='.$price)->order('price asc,addtime asc,num desc')->select();
            $rs=array();
            if($orders){
                foreach($orders as $v){
                    if($n<=0||$v['num']<=0) break;

                    $trans = $n < $v['num'] ? $n : $v['num'];
                    $sum = coin($trans * $v['price']);

                    if($n >= $trans) $n = $n - $trans; else break;

                    $t1_ocz = $this->ChongZhi->where('userid='.$v['userid'].' and typeid='.$tb['name1'])->find();//CXC
                    $t2_ocz = $this->ChongZhi->where('userid='.$v['userid'].' and typeid='.$tb['name2'])->find();//RMB

                    if(bccomp($t1_ocz['gdgold'],$trans,2) < 0){
                        continue;
                    }


                    //如果自己买到自己的
                    if($v['userid'] ==$userid ){

                        $cz_self = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC
                        $rs['aa'] = $mo->table('t_chong_zhi')->save(array(
                            'id' => $cz_self['id'],
                            'goldnum' => coin($cz_self['goldnum'] + $trans),
                            'gdgold' => coin($cz_self['gdgold'] - $trans),
                        ));
                        //挂单部分改变了
                        if($v['num'] > $trans){
                            $rs['bb'] = $mo->table('t_gua_dan')->save(array(
                                'id'=>$v['id'],
                                'num'=>coin($v['num']-$trans)
                            ));
                        }else{
                            $rs['cc'] = $mo->table('t_gua_dan')->where('id='.$v['id'])->delete();
                        }
                        $rs['dd'] = $mo->table('t_trans_log')->add(array(
                            'sum' => $sum,
                            'price' => $v['price'],
                            'num' => $trans,
                            'flag' => 0,
                            'zhu' => 1,
                            'typeboxid' => $tbid,
                            'userid' => $userid,
                       		 'fee'=>$trans*$shouxufei,
                        	 'realnum'=>$trans*(1-$shouxufei),
                            'addtime' => date('Y-m-d H:i:s',time())
                        ));
                        $rs['ee'] = $mo->table('t_trans_log')->add(array(
                            'sum' => $sum,
                            'price' => $v['price'],
                            'num' => $trans,
                            'flag' => 1,
                            'typeboxid' => $tbid,
                            'userid' => $userid,
                        'fee'=>$trans*$shouxufei,
                        'realnum'=>$trans*(1-$shouxufei),
                            'addtime' => date('Y-m-d H:i:s',time())
                        ));
						if ($sys['shouxufei_on']) {
                         
                        $shouxufei=$sum*$sys['shouxufei'];
                     
                        $this->ChongZhi->where("typeid=5 and userid={$userid} ")->setDec('goldnum',$shouxufei);//卖
                        $rs[] = $mo->table('t_shouxufei_log')->add(array(
                            'num' => $shouxufei,
                            'user' => $v['userid'],
                            'time' => time()
                        ));
                        /* $rs[]=$this->ChongZhi->where("typeid=5 and userid={$_SESSION['USER_KEY_ID']} ")->setDec('goldnum',$shouxufei);//买
                         $rs[] = $mo->table('t_shouxufei_log')->add(array(
                         'num' => $shouxufei,
                         'user' => $_SESSION['USER_KEY_ID'],
                         'time' => time()
                         ));*/
                    
                    }

                        continue;
                    }



                    //购买者
                    $cz1 = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name1'])->find();//CXC
                    $cz2 = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name2'])->find();//RMB

                    if($cz2['goldnum']  < $sum){
                        $this->error('Line:246|'.$cz2['goldnum'].'|'.$sum);
                    }

                    $rs['ff'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $cz2['id'],
                        'goldnum' => coin($cz2['goldnum'] - $sum)
                    ));
                    $rs['gg'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $cz1['id'],
                        'goldnum' => coin($cz1['goldnum'] + $trans)
                    ));


                    //卖出方
                    if($t1_ocz['gdgold']  < $trans)
                        $this->error('Line:257|'.$t1_ocz['gdgold'].'|'.$trans);

                    $rs['hh'] = $mo->table('t_chong_zhi')->save(array(
                        'id'=>$t1_ocz['id'],
                        'gdgold'=>coin($t1_ocz['gdgold'] - $trans)

                    ));

                    //$bsum = coin($trans * $v['price']);
                    $rs['ii'] = $mo->table('t_chong_zhi')->save(array(
                        'id'=>$t2_ocz['id'],
                        'goldnum'=>coin($t2_ocz['goldnum'] +$sum)
                    ));


                    if($v['num'] > $trans){
                        $rs['jj'] = $mo->table('t_gua_dan')->save(array(
                            'id'=>$v['id'],
                            'num'=>coin($v['num']-$trans)
                        ));
                    }else{
                        $rs['kk'] = $mo->table('t_gua_dan')->where('id='.$v['id'])->delete();
                    }
				

                    if ($sys['shouxufei_on']) {
                        $shouxufei=$trans*$sys['shouxufei'];
                    
                        $rs['aaa']=$this->ChongZhi->where("typeid=5 and userid={$v['userid']} ")->setDec('goldnum',$shouxufei);//卖
                        $rs['bbb'] = $mo->table('t_shouxufei_log')->add(array(
                            'num' => $shouxufei,
                            'user' => $v['userid'],
                            'time' => time()
                        ));
                        /*$rs[]=$this->ChongZhi->where("typeid=7 and userid={$_SESSION['USER_KEY_ID']} ")->setDec('goldnum',$shouxufei);//买
                         $rs[] = $mo->table('t_shouxufei_log')->add(array(
                         'num' => $shouxufei,
                         'user' => $_SESSION['USER_KEY_ID'],
                         'time' => time()
                         ));*/
                    }

                    $rs['ll'] = $mo->table('t_trans_log')->add(array(
                        'sum' => $sum,
                        'price' => $v['price'],
                        'num' => $trans,
                        'flag' => 1,
                        'typeboxid' => $tbid,
                        'userid' => $userid,
                    'fee'=>$trans*$shouxufei,
                    'realnum'=>$trans*(1-$shouxufei),
                        'addtime' => date('Y-m-d H:i:s',time())
                    ));

                    $rs['mm'] = $mo->table('t_trans_log')->add(array(
                        'sum' => $sum,
                        'price' => $v['price'],
                        'num' => $trans,
                        'flag' => 0,
                        'zhu' => 1,
                        'typeboxid' => $tbid,
                        'userid' => $v['userid'],
                    'fee'=>$trans*$shouxufei,
                     'realnum'=>$$trans*(1-$shouxufei),
                        'addtime' => date('Y-m-d H:i:s',time())
                    ));
                }

                if($n > 0){
                    $data['price'] = $price;
                    $data['num'] = $n;
                    $data['flag'] = 1;
                    $data['typeboxid'] = $tbid;
                    $data['userid'] = $userid;
                    $data['addtime'] = date('Y-m-d H:i:s',time());

                    $rs['nn'] = $mo->table('t_gua_dan')->add($data);


                    $t2_czD = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name2'])->find();//RMB

                    if($t2_czD['goldnum'] < $price*$n){

                        $this->error('Line:319|'.$t2_czD['gdgold'].'|'.$price.'|'.$n);

                    }


                    //买入成交还有剩余，那么就挂单
                    $rs['oo'] = $mo->table('t_chong_zhi')->save(array(
                        'id' => $t2_czD['id'],
                        'goldnum' => coin($t2_czD['goldnum'] - $price*$n),
                        'gdgold' => coin($t2_czD['gdgold'] + $price*$n)
                    ));
                }

                if(chkArr($rs)){
                    $mo->commit();

                    $this->success('提交成功(有买到成功)！');

                }else{
                    $mo->rollback();

                    $this->error('提交失败0！'.print_r($rs));
                }
            }else{
                $data['price'] = $price;
                $data['num'] = $num;
                $data['flag'] = 1;
                $data['typeboxid'] = $tbid;
                $data['userid'] = $userid;
                $data['addtime'] = date('Y-m-d H:i:s',time());
                $rs1 = $mo->table('t_gua_dan')->add($data);

                $t2_czE = $this->ChongZhi->where('userid='.$userid.' and typeid='.$tb['name2'])->find();//RMB

                if($t2_czE['goldnum'] < $price*$num){

                    $this->error('Line:319|'.$t2_czE['gdgold'].'|'.$price.'|'.$num);
                }


                $t['id'] = $t2_czE['id'];
                $t['goldnum'] = coin($t2_czE['goldnum'] - $price*$num);
                $t['gdgold'] = coin($t2_czE['gdgold'] + $price*$num);

                $rs2 = $mo->table('t_chong_zhi')->save($t);

                if($rs1 && $rs2){
                    $mo->commit();

                    $this->success('提交成功（无成交）！');
                }else{
                    $mo->rollback();

                    $this->error('提交失败2！');
                }
            }
        }

    }

    //调节精度
    private  function JQDCheck(){
        //这里显示的时候再次检测是否显示异常,及时更新
        $TypeBox = D('TypeBox');
        $AllTypeCheck=$TypeBox->select();
        $CoinArr=array();
        foreach($AllTypeCheck as $value){
            //循环N种币 N种市场

            $name1=$value['name1'];
            $name2=$value['name2'];
            $tbid=$value['id'];

            //买的东西 name1 比如 2ha 结果 chongzhi里面 需要计算 total的冻结
            //冻结的应该是RMB
            $r2=$this->ChongZhi->field('*')->where('userid='.$_SESSION['USER_KEY_ID']. ' and typeid=' .$name2)->select();
            $chongzhi['sell'] = $r2['0'];

            //卖的东西 不需要计算total 0
            //冻结的应该是 2ha
            $r=$this->ChongZhi->field('*')->where('userid='.$_SESSION['USER_KEY_ID']. ' and typeid=' .$name1)->select();
            $chongzhi['buy'] = $r['0'];

            //查找对应ID币的挂单量
            $r3=$this->GuaDan->where('userid=' . $_SESSION['USER_KEY_ID'] . ' and typeboxid='.$tbid.'  and flag=1')->
                field('*,SUM(num*price) as nums')->select();
            $BuyGuaDan = $r3['0'];
			$r4= $this->GuaDan->where('userid=' . $_SESSION['USER_KEY_ID'] . ' and typeboxid='.$tbid.' and flag=0')->
                field('*,SUM(num) as nums')->select();
            $saleGuaDan =$r4['0'];


            //格式 $CoinArr['chongzhi']['typeid'] 不同的币挂买卖单总量
            $CoinArr['chongzhi'][$name1]['saveid']=$chongzhi['buy']['id'];//保存时需要的主键
            $CoinArr['chongzhi'][$name1]['gdgold']=$chongzhi['buy']['gdgold'];
            //判断财产负值
            if($chongzhi['buy']['goldnum'] < 0){
                $data=array();
                $data['id'] = $chongzhi['buy']['id'];
                $data['goldnum'] = 0;
                $this->ChongZhi->save($data);
            }

            $CoinArr['chongzhi'][$name2]['saveid']= $chongzhi['sell']['id'];//保存时需要的主键
            $CoinArr['chongzhi'][$name2]['gdgold']= $chongzhi['sell']['gdgold'];
            //判断财产负值
            if($chongzhi['sell']['goldnum'] < 0){
                $data=array();
                $data['id'] = $chongzhi['sell']['id'];
                $data['goldnum'] = 0;
                $this->ChongZhi->save($data);
            }

            //找出总的挂单量
            if(isset($BuyGuaDan['id']))
                $CoinArr['guadan'][$name2]+=$BuyGuaDan['nums'];
            if(isset($saleGuaDan['id']))
                $CoinArr['guadan'][$name1]+=$saleGuaDan['nums'];

        }
        foreach($CoinArr['chongzhi'] as $key=>$val){
            //判断如果有挂单，那么就将挂单和充值冻结同步
            $gdgold = -1;
            $data=array();
            if(isset($CoinArr['guadan'][$key])){
                if($CoinArr['guadan'][$key]!=$val['gdgold']){
                    //有买入挂单，但是冻结金额误差
                    $gdgold=$CoinArr['guadan'][$key];
                }
            }else if($val['gdgold']!=0){
                $gdgold=0;
            }

            if($gdgold != -1){
                $data['id'] = $val['saveid'];
                $data['gdgold']=$gdgold;
                $this->ChongZhi->save($data);
            }
        }

    }

    public function cancel(){
        if(empty($_GET['id'])){
            $this->error('操作失败！');
        }

        $mo = new Model();
        $mo->startTrans();

        $value = $this->GuaDan->where('id='.$_GET['id'])->find();
        $tb = $mo->table('t_type_box')->where('id='.$value['typeboxid'])->find();

        if($value['flag']==0){
            $t1_cz = $this->ChongZhi->where('userid='.$value['userid'].' and typeid='.$tb['name1'])->find();

            $data['id'] = $t1_cz['id'];
            $data['gdgold'] = coin($t1_cz['gdgold'] - $value['num']);
            $data['goldnum'] = coin($t1_cz['goldnum'] + $value['num']);

            $rs = $mo->table('t_chong_zhi')->save($data);

        }else{
            $t2_cz = $this->ChongZhi->where('userid='.$value['userid'].' and typeid='.$tb['name2'])->find();

            $data['id'] = $t2_cz['id'];
            $data['gdgold'] = coin($t2_cz['gdgold'] - $value['num'] * $value['price']);
            $data['goldnum'] = coin($t2_cz['goldnum'] + $value['num'] * $value['price']);

            $rs = $mo->table('t_chong_zhi')->save($data);
        }

        $rs1 = $this->GuaDan->where('id='.$_GET['id'])->delete();

        if($rs && $rs1){
            $mo->commit();
            $this->success('操作成功！');
        }else{
            $mo->rollback();
            $this->error('操作失败！');
        }
    }
    
     public function check(){
        $cur = isset($_GET['cur']) ? $_GET['cur']:0;
        $time = time();
       while(true){
           $user = $this->User->where('id >' .$cur)->limit(100)->select();
           if(empty($user)) break;

           foreach($user as $val){
               $arr = $this->ChongZhi->where('userid = '.$val['id'])->select();
               $len = count($arr);

               if($len == 0){

                   $this->ChongZhi->add(array(
                       'userid'=>$val['id'],
                       'typeid'=>5,
                       'goldnum'=>0,
                       'gdgold'=>0,
                       'addtime'=>$time,
                   ));
                   $this->ChongZhi->add(array(
                       'userid'=>$val['id'],
                       'typeid'=>5,
                       'goldnum'=>0,
                       'gdgold'=>0,
                       'addtime'=>$time,
                   ));

               }else if($len == 1){

               }
           }
       }
       echo 'CUR='.$cur;
    }
    
}