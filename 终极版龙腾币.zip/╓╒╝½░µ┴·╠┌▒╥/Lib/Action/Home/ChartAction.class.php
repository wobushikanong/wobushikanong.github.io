<?php
class ChartAction extends CommonAction {
	private $Orders;

	public function __construct(){
		parent::__construct();
        $this->Orders = D('Orders');
	}

	function index(){
		$this->assign('coin',$_GET['coin']);
		$this->display('./Tpl/Home/Json.html');
	}

	function chart(){
		$coin = chkStr($_GET['coin']) ? $_GET['coin'] : 'kg';
        $basetime = intval(time()/60)-24*60;
	    for($i=1;$i<=24*60;$i++){
			$start = ($basetime+$i-1)*60;
		    $end = ($basetime+$i)*60;
            $max = $this->Orders->where('coin="'.$coin.'" and ctime>='.$start.' and ctime<'.$end)->max('price');
			$d[] = array($start*1000,floatval($max));
		}
		echo json_encode($d);
	}
}