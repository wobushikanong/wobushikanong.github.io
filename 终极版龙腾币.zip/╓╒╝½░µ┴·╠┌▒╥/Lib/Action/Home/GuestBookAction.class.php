<?php 
class GuestBookAction  extends CommonAction{
	public function __construct(){
		parent::__construct();
		$this->checkAuth();
		$this->renzheng();
	}
	public function  index(){
		//$list = $Dao->field('username,email')->select();
		$Dao=M('Guest_book');//实例化表
		//dump($list);
		$count=$Dao->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,5);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->order('id ASC')->where("username='{$_SESSION['USER_KEY']}'")->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
		foreach ($list as $k=>$v){
			$list[$k][$v]=mb_substr (strip_tags($v['content']),0,16,'utf-8');
		}
		$new_page=str_replace('/GuestBook','?s=Home/GuestBook',$page);
		$this->assign('page', $new_page);//模板变量赋值
		$this->assign('list', $list);//模板变量赋值
		$this->display('./Tpl/Home/guest_book.html');
	}
	public function addGestBook(){
		$name=$_SESSION['USER_KEY'];
		$id=$_SESSION['USER_KEY_ID'];
		$time=time();
		$content=$_POST['content'];
		$m=M('Guest_book');//实例化表的model类，其实加载表
		$data['username']=$name;
		$data['time']=$time;
		$data['content']=$content;
		$data['ishuifu']='否';
		$m->add($data);//tp add方法，插入数据
		//echo $m->getlastSql();
		//exit();
		if ($m) {
			$this->success('留言成功');
		}else {
			$this->error('留言失败');
		}
	}
	public function del(){
		$id=$_GET['id'];
		//echo "您想执行删除操作";
		$Dao=M('Guest_book');
		//echo "$id";
		$where = 'id='.$id;
		//dump($where);
		//exit();
		$result = $Dao->where($where)->delete();
		//$result = $Dao->where('uid = 1')->delete();
		//echo "222";
		if($result !==false){
			//注意点：
			$this->success('删除成功');
		}else {
			$this->error('删除失败');
		}
	}
	
}

?>