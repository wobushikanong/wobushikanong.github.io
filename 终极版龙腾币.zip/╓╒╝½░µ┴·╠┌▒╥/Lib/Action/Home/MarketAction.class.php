<?php
class MarketAction extends CommonAction {
	private $Orders;
	private $Trans;

	public function __construct(){
		parent::__construct();
        $this->Orders = D('Orders');
		$this->Trans = D('Trans');
	}

	function index(){
		$coin = chkStr($_GET['coin']) ? $_GET['coin'] : 'kg';

        $this->assign('coin',$coin);

		$lasttrade = $this->Orders->where('coin="'.$coin.'" and deal>0')->order('ctime desc')->find();
		$lastprice = $this->Orders->where('coin="'.$coin.'"')->order('ctime desc')->find();
		$max = $this->Orders->where('coin="'.$coin.'" and type=1')->max('price');
		$min = $this->Orders->where('coin="'.$coin.'" and type=0')->min('price');
		$top = $this->Orders->where('coin="'.$coin.'"')->max('price');
		$low = $this->Orders->where('coin="'.$coin.'"')->min('price');
		$sum = $this->Orders->where('coin="'.$coin.'"')->sum('num');
		$this->assign('lasttrade',floatval($lasttrade['price']));
		$this->assign('lastprice',floatval($lastprice['price']));
		$this->assign('max',floatval($max));
		$this->assign('min',floatval($min));
		$this->assign('sum',floatval($sum));

        $buyorders = $this->Orders->where('coin="'.$coin.'" and type=1 and status=0')->order('price desc')->limit(50)->select();
		foreach($buyorders as $k => $v){
		    $buylist .= '<tr>
							 <td class="lightgreen">买('.($k+1).')</td>
	                          <td>
	                          	￥<span>'.floatval($v['price']).'</span>
	                          </td>
	                         <td>
	                         	<span>฿'.floatval($v['num']).'</span>
	                         </td>
                             <td><span style="width:'.(floatval($v['num'])>105 ? 105 : floatval($v['num'])).'px; " class="buyspan"></span> </td>
						 </tr>';
		}
        
        $this->assign('buylist',$buylist);

		$sellorders = $this->Orders->where('coin="'.$coin.'" and type=0 and status=0')->order('price asc')->limit(50)->select();

		foreach($sellorders as $k => $v){
		    $selllist .= '<tr>
							 <td class="red">卖('.($k+1).')</td>
	                          <td>
	                          	￥<span>'.floatval($v['price']).'</span>
	                          </td>
	                         <td>
	                         	<span>฿'.floatval($v['num']).'</span>
	                         </td>
                             <td><span style="width:'.(floatval($v['num'])>105 ? 105 : floatval($v['num'])).'px; " class="sellspan"></span> </td>
						 </tr>';
		}
        
        $this->assign('selllist',$selllist);

		$trade = $this->Trans->where('coin="'.$coin.'"')->group('ctime')->order('ctime desc')->limit(50)->select();

		foreach($trade as $k => $v){
		    $tradelist .= '<tr>
							 <td><span>'.date('H:i:s',$v['ctime']).'</span></td>
	                        <td class="">￥<span class="lightgreen">'.$v['price'].'</span></td>
	                         <td><span id="colorAmount1">฿'.$v['num'].'</span></td>
						   </tr>';
		}
        
        $this->assign('tradelist',$tradelist);

		$this->display('./Tpl/Home/Market.html');
	}

	public function freshlist(){
	    $coin = chkStr($_POST['coin']) ? $_POST['coin'] : 'kg';

		$buyorders = $this->Orders->where('coin="'.$coin.'" and type=1 and status=0')->order('price desc')->limit(50)->select();
		foreach($buyorders as $k => $v){
		    $buylist .= '<tr>
							 <td class="lightgreen">买('.($k+1).')</td>
	                          <td>
	                          	￥<span>'.floatval($v['price']).'</span>
	                          </td>
	                         <td>
	                         	<span>฿'.floatval($v['num']).'</span>
	                         </td>
                             <td><span style="width:'.(floatval($v['num'])>105 ? 105 : floatval($v['num'])).'px; " class="buyspan"></span> </td>
						 </tr>';
		}

		$sellorders = $this->Orders->where('coin="'.$coin.'" and type=0 and status=0')->order('price asc')->limit(50)->select();

		foreach($sellorders as $k => $v){
		    $selllist .= '<tr>
							 <td class="red">卖('.($k+1).')</td>
	                          <td>
	                          	￥<span>'.floatval($v['price']).'</span>
	                          </td>
	                         <td>
	                         	<span>฿'.floatval($v['num']).'</span>
	                         </td>
                             <td><span style="width:'.(floatval($v['num'])>105 ? 105 : floatval($v['num'])).'px; " class="sellspan"></span> </td>
						 </tr>';
		}

		$trade = $this->Trans->where('coin="'.$coin.'"')->group('ctime')->order('ctime desc')->limit(50)->select();

		foreach($trade as $k => $v){
		    $tradelist .= '<tr>
							 <td><span>'.date('H:i:s',$v['ctime']).'</span></td>
	                        <td class="">￥<span class="lightgreen">'.$v['price'].'</span></td>
	                         <td><span id="colorAmount1">฿'.$v['num'].'</span></td>
						   </tr>';
		}

		$this->ajaxReturn(array('buylist'=>$buylist,'selllist'=>$selllist,'tradelist'=>$tradelist),'',0);
	}
}