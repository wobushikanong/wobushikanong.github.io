<?php
class GudongAction extends CommonAction {

   public function __construct()
    {
        parent::__construct();
        $this->checkAuth();
    }

     public function index(){
    	//判断会员级别
    	$u=M('User');
    	$c=M('Chong_zhi');
    	$j=M('Jiaoyi');
        $username=$_SESSION['USER_KEY'];
        
   
        $id=$_SESSION['USER_KEY_ID'];
    	$user=$u->field('typeid')->where("username='$username'")->find();
    	
    	$type=$_GET['type']?intval($_GET['type']):0;
    	
    	if ($type==1) {
    		$where= "post_user='$username'";
    	}elseif ($type==2){
    		$where="get_user='$username'";
    	}else{
    		$where="post_user='$username' or get_user='$username'";
    	}
    	
     	if ($user['typeid']<1) {
    		$this->error('预计9月1日-至3日之间开启，敬请留意官方公告');
    	}
    	$r=$c->where('userid='.$id.' and typeid=7')->find();
    	
    	
    	$count=$j->where($where)->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,5);//实例化分页类
		$r2=$j->where($where)->limit($p->firstRow.','.$p->listRows)->order("id desc")->select();
		
		$T=M('type');
		$bizhong=$T->select();
		
		$page=$p->show();//分页显示输出
    	foreach ($r2 as $k=> $v){
    		if ($v['post_user']==$username) {
    			$r2[$k]['do']='del';
    			$r2[$k]['doname']='撤销';
    		}else {
    			$r2[$k]['do']='del';
    			$r2[$k]['doname']='拒绝';
    			
    			$r2[$k]['do2']='do_jiaoyi';
    			$r2[$k]['do2name']='同意';
    		}

    		if ($v['status']!=1) {
    			$r2[$k]['do']='';
    			$r2[$k]['do2']='';
    			$r2[$k]['doname']='';
    			$r2[$k]['do2name']='';
    		}
    		switch ($v['status']){
    			case 1:$r2[$k]['status']='交易已提交'; break;
    			case 2:$r2[$k]['status']='交易成功';break;
    			case 0:$r2[$k]['status']='交易已关闭';break;
    		}
    		$r2[$k]['time']=date('Y-m-d H:i:s',$v['time']);
    	}
    	$new_page=str_replace('/Gudong','?s=Home/Gudong',$page);
    	$this->assign('bizhong',$bizhong);
    	$this->assign('page',$new_page);
    	$this->assign('list',$r2);
    	$this->assign('glodnum',$r['goldnum']);
		$this->display('./Tpl/Home/Gudongjiaoyi.html');
    }
   public function getnum(){
   		$id=$_SESSION['USER_KEY_ID'];
   		$typid=intval($_POST['type']);
   		$num=M('Chong_zhi')->where("userid=$id and typeid=$typid")->find();
   		
   		$this->ajaxReturn($num);
   }
    public function  jiaoyi(){
    	$other_usernme=$_POST['other_username'];
    	$goldnum=intval($_POST['goldnum']);//类型转换，作用防止SQL注入，确保传的是数字
    	$price=intval($_POST['price']);
    	$pw=md5($_POST['transpw']);
    	
    	$u=M('User');//tp M D
    	$c=M('Chong_zhi');
    	$j=M('Jiaoyi');
    	
        $id=$_SESSION['USER_KEY_ID'];
        $typeid=intval($_POST['bizhong']);
    	$user_chongzhi=$c->field('goldnum')->where('userid='.$id.' and typeid='.$typeid)->find();
    	
    	$user=$u->field('id,username,transpw,typeid')->where("id=$id")->find();
    	
    	/*if ($user['typeid']<1) {
    		$this->error('非VIP会员不能发起交易');
    		return;
    	}*/
    	$other_user=$u->field('id,typeid')->where("username='$other_usernme'")->find();
    	if ($pw!=$user['transpw']) {
    		$this->error('交易密码不正确');
    		return;
    	}
    	if($user_chongzhi['goldnum']<$goldnum){
    		$this->error('您余额不足，请充值');
    		return;
    	}
    	if (empty($other_user)) {
    		$this->error('您发起的交易会员不存在，请查证');
    		return;
    	}
    	/*if ($other_user['typeid']<1) {
    		$this->error('不能向非VIP会员发起交易');
    		return;
    	}*/
    	$data['post_user']=$user['username'];
    	$data['get_user']=$other_usernme;
    	$data['num']=$goldnum;
    	$data['price']=$price;
    	$data['typeid']=$typeid;
    	$data['time']=time();
    	$data['status']=1;
    	
    	//减钱
    	$r1=$c->where('userid='.$id.' and typeid='.$typeid)->setDec('goldnum',$goldnum);
    	
    	$r2=$j->add($data);
    	if ($r2) {
    		$this->success('发起交易成功！等待对方响应');
    	}else {
    		$this->error('发起交易失败，稍后重试');
    	}	
    }
    
   		 
    	
       public function del(){
       		$id=$_GET['id'];
    		$j=M('Jiaoyi');
    		$c=M('Chong_zhi');
    		$u=M('User');
    		
    		$jiaoyi=$j->where("id=$id")->find();
			$num=$jiaoyi['num'];
			$user=$jiaoyi['post_user'];
			
			$user_array=$u->where("username='{$user}'")->find();
			$id=$user_array['id'];
			
			
			$r=$c->where("userid=$id and typeid={$jiaoyi['typeid']}")->setInc('goldnum',$num);
			$data['status']=0;
			$r=$j->where("id={$jiaoyi['id']}")->save($data);
			

    		if ($r) {
    			$this->success('交易取消成功');
    		}else{
    		
    			$this->error('交易取消失败');
    		}
    	
   		 }
   		 
   		public function do_jiaoyi(){
   			$id=$_GET['id'];
   			$j=M('Jiaoyi');
    		$c=M('Chong_zhi');
    		$u=M('User');
    		$uid=$_SESSION['USER_KEY_ID'];
    		//取出交易
    		$jiaoyi=$j->where("id=$id")->find();
    		//echo $j->getLastSql();
    		//取出post_user name
    		$user=$u->where("username='{$jiaoyi['post_user']}'")->find();
    		//取手续费
   			$rSys=M('Sys');
   			$zhuanzhangshouxufei=$rSys->field("zhuanzhangshouxufei")->find();
   			$zhuanzhangshouxufei=$zhuanzhangshouxufei['zhuanzhangshouxufei'];
    		//echo $u->getLastSql();
    		//计算所需手续费
    		$money=$jiaoyi['num']*$zhuanzhangshouxufei;
    		$goldnum=$c->where("typeid=5 and userid={$uid}")->find();
    		if ($goldnum['goldnum']<$money) {
    			$this->error('账户余额不足，无法支付手续费');
    		}
    		//减钱
    		$r1=$c->where("userid=$uid and typeid=5")->setDec('goldnum',$money);
    		//echo $c->getLastSql();
   			//对方加钱
   			//$r2=$c->where("userid={$user['id']} and typeid=5")->setInc('goldnum',$jiaoyi['num']);
   		//	echo $c->getLastSql();
   			
   			//加goldnum
   			$r3=$c->where("userid=$uid and typeid=7")->setInc('goldnum',$jiaoyi['num']*(1-$zhuanzhangshouxufei));
   			//更新状态
   			$data['status']=2;
   			$data['zhuanzhangshouxufei']=$zhuanzhangshouxufei*$jiaoyi['num'];
   			$r4=$j->where("id=$id")->save($data);
   			if ($r1!==FALSE&&$r2!==FALSE&&$r3!==FALSE) {
   				$this->success('提交成功(有成交)！');
   			}else{
   				$this->error('提交失败（1）！');
   			}
    		
   		}
   		
   	public function ticheng(){
   		$this->display('./Tpl/Home/ticheng.html');
   	}
   	
   	public function factory(){
   		$this->display("./Tpl/Home/Gudong_factory.html");
   	}


}