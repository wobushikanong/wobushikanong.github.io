<?php
class TradeAction extends CommonAction {
	private $User;
	private $Orders;
	private $Trans;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
        $this->checkReal();
		$this->User = D('User');
		$this->Orders = D('Orders');
		$this->Trans = D('Trans');

        $this->assign('coin',$_GET['coin']?$_GET['coin']:'kg');
        //$this->assign('jumpUrl',$this->path.'/Buy');
		//$this->error('现在是矿工购买期，暂时还不能交易。认购期结束即可进行交易。马上去购买矿工吧！');
	}

    public function index(){

		if($_GET['type']=='0')
			$this->assign('type',0);
		else
			$this->assign('type',1);

        $coin = chkStr($_GET['coin']) ? $_GET['coin'] : 'kg';
		$where = ' and coin="'.$coin.'"';
        
		$this->assign('coin',$coin);
		if($coin=='kg'){
		    $this->assign('balance',$this->auth['xnb']);
			$this->assign('unit',$this->sys['kgname']);
			$field = 'xnb';
		}else{
		    $this->assign('balance',$this->auth['ks']);
			$this->assign('unit',$this->sys['ksname']);
			$field = 'ks';
		}

		$last = $this->Trans->where('1=1'.$where)->order('ctime desc')->find();
		$this->assign('last',floatval($last['price']));

        $best['sell'] = $this->Orders->where('status=0 and type=1'.$where)->max('price');
		$best['buy'] = $this->Orders->where('status=0 and type=0'.$where)->min('price');
		$best['sell'] = floatval($best['sell']);
		$best['buy'] = floatval($best['buy']);
		$best['sellrmb'] = floatval(number_format(floatval($this->auth[$field]*$best['sell']),2));
		$best['buynum'] = floatval(number_format(floatval($this->auth['rmb']/$best['buy']),2));
		$this->assign('best',$best);

		$orders['sell'] = $this->Orders->field("SUM(num)-SUM(deal)  as num,price,id,type")->group("price")->where('type=0 and status=0'.$where)->order('price asc')->limit(5)->select();
		$orders['sell']=array_reverse($orders['sell']);
		foreach($orders['sell'] as $k => $v){
			$orders['sell'][$k]['price']= floatval($v['price']);
			$orders['sell'][$k]['num']= floatval($v['num']);
			$orders['sell'][$k]['total']= floatval($v['price'] * $v['num']);
			$orders['sell'][$k]['cur']= $v['num'] - $v['deal'];
		}
		$orders['buy'] = $this->Orders->field("SUM(num)-SUM(deal)  as num,price,id,type")->group("price")->where('type=1 and status=0'.$where)->order('price desc')->limit(5)->select();
        foreach($orders['buy'] as $k => $v){
			$orders['buy'][$k]['price']= floatval($v['price']);
			$orders['buy'][$k]['num']= floatval($v['num']);
			$orders['buy'][$k]['total']= floatval($v['price'] * $v['num']);
			$orders['buy'][$k]['cur']= $v['num'] - $v['deal'];
		}
		        
		$orders['entrust'] = $this->Orders->where('uid='.$this->auth['id'])->limit(10)->select();
		foreach($orders['entrust'] as $k => $v){
			$orders['entrust'][$k]['price'] = floatval($v['price']);
			$orders['entrust'][$k]['num'] = floatval($v['num']);
			$orders['entrust'][$k]['deal'] = floatval($v['deal']);
			$orders['entrust'][$k]['total'] = floatval($v['price']*$v['num']);
			$orders['entrust'][$k]['dealtotal'] = floatval($v['price']*$v['deal']);

			if($v['type']==0){
			    $orders['entrust'][$k]['fee'] = floatval($orders['entrust'][$k]['total']*$this->sys['tradefee']/100);
			}else{
			    $orders['entrust'][$k]['fee'] = floatval($v['num']*$this->sys['tradefee']/100);
			}
		}

        $orders['trade'] = $this->Trans->where('uid='.$this->auth['id'])->limit(10)->select();
		foreach($orders['trade'] as $k => $v){
			$orders['trade'][$k]['total'] = floatval($v['price']*$v['num']);
			if($v['type']==0){
			    $orders['trade'][$k]['fee'] = floatval($orders['trade'][$k]['total']*$this->sys['tradefee']/100);
			}else{
			    $orders['trade'][$k]['fee'] = floatval($v['num']*$this->sys['tradefee']/100);
			}
		}
		$sys=M('Sys')->where("id=1")->find();
		$min_price=(float)$sys['min_price'];
		$max_price=(float)$sys['max_price'];
		$this->assign('min_p',$min_price);
		$this->assign('max_p',$max_price);
        $this->assign('orders',$orders);

		$this->assign('empty','<tr><td colspan="8" style="text-align:center;">您暂时没有未成交的挂单。</td></tr>');
		$this->display('./Tpl/Home/Trade.html');
    }

	public function buys(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Orders->where('uid='.$this->auth['id'].' and type=1')->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Orders->where('uid='.$this->auth['id'].' and type=1')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_buys.html');
	}

	public function sells(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Orders->where('uid='.$this->auth['id'].' and type=0')->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Orders->where('uid='.$this->auth['id'].' and type=0')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_sells.html');
	}

	public function buylog(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Trans->join('t_orders o on o.id=t_trans.buyid')->field('o.price,t_trans.*')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_buylog.html');
	}

	public function selllog(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Trans->join('t_orders o on o.id=t_trans.sellid')->field('o.price,t_trans.*')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_selllog.html');
	}

	public function mybuylog(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->where('uid='.$this->auth['id'].' and type=1')->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Trans->where('uid='.$this->auth['id'].' and type=1')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_mybuylog.html');
	}

	public function myselllog(){
	    $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->where('uid='.$this->auth['id'].' and type=0')->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        $list=$this->Trans->where('uid='.$this->auth['id'].' and type=0')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
			$list[$k]['total'] = floatval($v['price']*$v['num']);
		}

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="8" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trade_myselllog.html');
	}

	public function buy(){
		$best = $this->Orders->where('status=0 and type=0')->min('price');
		$this->assign('best',$best);
	    $this->display('./Tpl/Home/Trade_buy.html');
	}

	public function sell(){
		$best = $this->Orders->where('status=0 and type=1')->max('price');
		$this->assign('best',$best);
	    $this->display('./Tpl/Home/Trade_sell.html');
	}

	function chart1(){
	   	$line = $_GET['line'];
        $time = time();
		for($i=25; $i > 0; $i--){
		    $start = $time - $i * $line;
			$end = $time - ($i-1) * $line;

			$where = 'ctime BETWEEN "'.$start.'" AND "'.$end.'"';

			$o = $this->Trans->where($where)->order('id asc')->find();
			$c = $this->Trans->where($where)->order('id desc')->find();
			$h = $this->Trans->where($where)->max('price');
			$l = $this->Trans->where($where)->min('price');
			$v = $this->Trans->where($where)->sum('num');
				
			$arr[]=array(coin($h),coin($l),coin($o['price']),coin($c['price']),$v,($time-($i-1)*$line)*1000);
		}

		//当前数据
		$orders = $this->Orders->order('id desc')->find();
		$this->assign('last',coin($orders['price']));

		$sum = $this->Trans->where('ctime between unix_timestamp()-3600*24 and unix_timestamp()')->sum('num');
		$this->assign('sum',coin($sum));

		$rs = $this->Orders->where('ctime between unix_timestamp()-3600*24 and unix_timestamp() and status=1')->select();
	
		foreach($rs as $v) $total+=coin($v['price']*$v['num']);
		$this->assign('total',coin($total));
		unset($total);
		
		$this->assign('chart',$arr);
		$this->assign('line',$line);
		$this->display('./Tpl/Home/Chart.html');
	}

	function chart2(){
		$this->display('./Tpl/Home/json.html');
	}

	function chart(){
	   	$rs = $this->Orders->order('ctime desc')->select();
		$d = array();
		foreach($rs as $k => $v){
			$d[] = array(intval($v['ctime'])*1000,floatval($v['price']));
		}
		echo json_encode($d);
	}

	function entrust(){
	    $coin = chkStr($_POST['coin']) ? $_POST['coin'] : 'kg';
		$where = ' and coin="'.$coin.'"';
		$orders['sell'] = $this->Orders->field("SUM(num)-SUM(deal) as num,price,id,type")->group("price")->where('type=0 and status=0'.$where)->order('price asc')->limit(5)->select();
		$lis = '';
		$orders['sell']=array_reverse($orders['sell']);
		foreach($orders['sell'] as $k => $v){
			$lis .= '<li class="red"><span class="c1 height-35">卖 ('.(5-$k).')</span><span class="c2 height-35">'.$v['price'].'</span><span class="c3 height-35">฿'.$v['num'].'</span></li>';
		}
		
		$orders['buy'] = $this->Orders->field("SUM(num)-SUM(deal)  as num,price,id,type")->group("price")->where('type=1 and status=0'.$where)->order('price desc')->limit(5)->select();
        foreach($orders['buy'] as $k => $v){
			$lis .= '<li class="lightgreen5"><span class="c1 height-35">买 ('.(5-$k).')</span><span class="c2 height-35">'.floatval($v['price']).'</span><span class="c3 height-35">฿'.floatval($v['num']).'</span></li>';
		}

		$this->ajaxReturn($lis,'',0);
	}
}