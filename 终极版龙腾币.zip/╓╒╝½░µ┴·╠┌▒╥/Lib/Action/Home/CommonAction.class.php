<?php
// 本类由系统自动生成，仅供测试用途
class CommonAction extends Action {
    protected $sys;
	protected $auth;
	protected $art;

	public function __construct(){
        //清空超过12个小时
		$Sys = D('Sys');
        $this->sys = $Sys->where('id=1')->find();
        $this->sys['invitfen']=floatval($this->sys['invitfen']);
		$this->assign('sys',$this->sys);

		$qqqun = explode("\r\n",$this->sys['qqqun']);
		$qun = array();
		foreach($qqqun as $k => $v){
			$arr = explode('|',$v);
		    $qun[$k]['name'] = $arr[0];
			$qun[$k]['code'] = $arr[1];
			$qun[$k]['full'] = $arr[2];
		}
		$this->assign('qqqun',$qun);

		$Art = D('Art');
        $this->art = $Art->order('id asc')->select();
		$this->assign('art',$this->art);

		$about = $Art->where('cate="about"')->order('id asc')->limit(6)->select();
		$this->assign('about',$about);

		$help = $Art->where('cate="help"')->order('id asc')->limit(6)->select();
		$this->assign('help',$help);

		$news = $Art->where('cate="news"')->order('id asc')->limit(6)->select();
		$this->assign('news',$news);

		$serv = $Art->where('cate="serv"')->order('id asc')->limit(6)->select();
		$this->assign('serv',$serv);

		$this->assign('path',C('URL_DIR'));
		$this->assign('pubdir',C('PUB_DIR'));
		
		$map['ctime']=array('between',array(strtotime(date('y-m-d'),time()),time()));
		$map['type']=1;
		$count=M('Trans')->where($map)->sum('num');//数量
		$money=M('Trans')->where($map)->sum('num*price');//数量
		$fcount=M('Factory_log')->sum("num");//挖矿数量
		$allf=M('Factory_user')->join("t_factory on t_factory_user.factory=t_factory.id")->where("t_factory_user.status=1")->sum('t_factory.suanli');//矿池总算力
		$this->assign('allf',$allf);
		$this->assign('count',$count);
		$this->assign('money',$money);
		$this->assign('fount',$fcount);

        $User = D('User');
		$this->auth = $User->where('id='.$_SESSION['USER_KEY_ID'])->lock(true)->find();
        $this->auth['rmb'] = floatval($this->auth['rmb']);
		$this->auth['rmb_frozen'] = floatval($this->auth['rmb_frozen']);
		$this->auth['xnb'] = floatval($this->auth['xnb']);
		$this->auth['xnb_frozen'] = floatval($this->auth['xnb_frozen']);
		$this->auth['ks'] = floatval($this->auth['ks']);
		$this->auth['ks_frozen'] = floatval($this->auth['ks_frozen']);
		$this->auth['rmbtotal'] = floatval($this->auth['rmb']+$this->auth['rmb_frozen']);
		$this->auth['kgtotal'] = floatval($this->auth['xnb']+$this->auth['xnb_frozen']);
		$this->auth['kstotal'] = floatval($this->auth['ks']+$this->auth['ks_frozen']);
		$this->auth['total'] = floatval($this->auth['rmb']+$this->auth['rmb_frozen']);
		
		$this->assign('auth',$this->auth);

		$this->assign('act',$_GET['_URL_'][1]);
		$this->assign('fun',$_GET['_URL_'][2]);

		$Orders = D('Orders');
		$kglast = $Orders->where('coin="kg"')->order('ctime desc')->find();
		$kslast = $Orders->where('coin="ks"')->order('ctime desc')->find();
		$this->assign('kglast',floatval($kglast['price']));
		$this->assign('kslast',floatval($kslast['price']));

		$this->assign('invit',$_SESSION['invit']);
	}

	protected function checkAuth(){
		if (!$_SESSION['USER_KEY'] || !$_SESSION['USER_KEY_ID']) {
			$_SESSION['notlogin']=1;
			redirect($_SESSION['back_url'], 0, '页面跳转中...');
			exit(0);
		}
	}

    protected function checkReal(){
		$_SESSION['prev_url'] = $_SERVER['HTTP_REFERER'];
		if(!chkStr($this->auth['xm'])||!chkStr($this->auth['idnumber'])||!chkStr($this->auth['phone']))
			echo '<script language="javascript">alert("您的资料没有填写完整，请完成资料填写后在进行此操作！");location.href="/?s=Home/User/real";</script>';
	}

	protected function checkAuthAjax(){
		if (!$_SESSION['USER_KEY'] || !$_SESSION['USER_KEY_ID']) {
			return false;
			exit(0);
		}else{
		    return true;
		}
	}

	protected function sendEmail($uemail,$title,$content){

	    require("class.phpmailer.php");

        if($this->sys['smtp']=='smtp.gmail.com'){
			$mail = new PHPMailer();
			$mail->IsSMTP();
			$mail->CharSet='UTF-8';
			$mail->Host = C('SMTP');
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "ssl"; 
			$mail->Port = "465";
			$mail->Username = $this->sys['email'];
			$mail->Password = $this->sys['pwd'];
			$mail->From = $this->sys['email'];
			$mail->FromName = $this->sys['auth'];
			$mail->AddAddress($uemail, "user");
			$mail->IsHTML(true);
			$mail->Subject = $title;
			$mail->Body = $content;
			$mail->SMTPDebug=false;

			if(!$mail->Send())
			{
				return false;
			}else{
				return true;
			}
		}else{
			$mail = new PHPMailer();
			$mail->IsSMTP();
			$mail->CharSet='UTF-8';
			$mail->Host = C('SMTP');
			$mail->SMTPAuth = true;
			$mail->Port = "25";
			$mail->Username = $this->sys['email'];
			$mail->Password = $this->sys['pwd'];
			$mail->From = $this->sys['email'];
			$mail->FromName = $this->sys['auth'];
			$mail->AddAddress($uemail, "user");
			$mail->IsHTML(true);
			$mail->Subject = $title;
			$mail->Body = $content;
			$mail->SMTPDebug=false;

			if(!$mail->Send())
			{
				return false;
			}else{
				return true;
			}
		}
	}
}