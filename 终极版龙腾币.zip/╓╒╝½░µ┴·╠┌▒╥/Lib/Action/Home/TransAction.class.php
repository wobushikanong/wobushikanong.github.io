<?php
class TransAction extends CommonAction {
    private $Trans;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
	    $this->Trans = D('Trans');
	}

    public function index(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->where('userid='.$_SESSION['USER_KEY_ID'])->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;

        $list=$this->Trans
			->join(array('t_market m on m.id=t_trans.marketid','t_coin c on c.id=m.wareid','t_coin c1 on c1.id=m.coinid'))
			->where('t_trans.userid='.$_SESSION['USER_KEY_ID'])
			->field('t_trans.*,m.wareid,m.coinid,c.sname as wsname,c1.sname as csname')
			->limit(($page-1)*$per_num.','.$per_num)
			->select();

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan="6" style="text-align:center">没有找到数据！</td></tr>');
		$this->display('./Tpl/Home/Trans.html');
    }

}