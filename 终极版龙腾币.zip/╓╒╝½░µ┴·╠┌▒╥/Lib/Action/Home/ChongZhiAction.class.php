<?php

class ChongZhiAction extends CommonAction
{
  

    public function __construct()
    {
        parent::__construct();
        $this->checkAuth();
        $this->renzheng();
    }
    
    public function index(){
    	
    	$this->display('./Tpl/Home/chongzhi_center.html');
    }
    public function chongzhi_cami(){
    	if (IS_POST) {
    		$cami=$_POST['cami'];
			$code = trim($_POST['code']);
    		 $checkcode = strtolower($_SESSION['checkcode']);
            if ($code != $checkcode) {
                $this->error('验证码错误！');
                exit;
            }
			$C=M('Cami');
			$CZ=M('Chong_zhi');
			$r=$C->where("code='$cami' and status=1")->find();
			if (empty($r)) {
				$this->error("您输入的卡密不正确");
				return ;
			}
           	$id = $_SESSION['USER_KEY_ID'];   	
           	$r1=$CZ->where("userid=$id and typeid=5")->setInc('goldnum',$r['money']);
           	$data['status']=0;
           	$data['user']= $_SESSION['USER_KEY'];  
           	$r2=$C->where("code='$cami'")->save($data);
           if ($r1) {
           	 	$_SESSION['checkcode'] = '';
           	 	$data['typeid'] = 3;
          		$data['orderno'] = time();
         		$data['url'] = "卡密充值";
	            $data['goldnum'] = $r['money'];
	            $data['userid'] = $_SESSION['USER_KEY_ID'];
	            $data['addtime'] = date('Y-m-d H:i:s', time());
	            $data['status']=3;
	            $m=M('Cz_apply');
           		 $r=$m->add($data);
           	//充值增加红包
           	$this->addHongBao($id);
           		$this->success("充值已成功");
           }else{
           		$this->error("充值失败，请联系管理员");
           }   		
    	}else {
    		
    		$S=M('Sys');
     		$r=$S->where("id=1")->find();
     		if ($r['pay_yibao']!=1) {
     			$this->error("卡密充值已关闭");
     		}
    		$user= $_SESSION['USER_KEY'];  
    	$Dao=M('Cami');//实例化表
		//dump($list);
		$count=$Dao->where("user='$user'")->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,10);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->where("user='$user'")->order('id DESC')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
			$new_page=str_replace('/GuestBook','?s=Home/GuestBook',$page);
		$this->assign('page', $new_page);//模板变量赋值
		$this->assign('list',$list);
    	
    		$this->display('./Tpl/Home/chongzhi_cami.html');
    	}
    	
  
    }

     	public function chongzhi1(){
     		$S=M('Sys');
     		$r=$S->where("id=1")->find();
     		if ($r['pay_zhifubao']!=1) {
     			$this->error("在线充值已关闭");
     		}
     		$id=$_SESSION['USER_KEY_ID'];
     		$Dao=M('Cz_apply');//实例化表
			$count=$Dao->where("userid='$id'")->count();//计算总页数
			import("ORG.Util.Page");// 导入分页类
			$p=new Page($count,5);//实例化分页类
			$page=$p->show();//分页显示输出
			$list = $Dao->where("userid='$id' and typeid=3")->order('id DESC')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
			foreach ($list as $k=> $v){
				switch ($v['status']){
					case 1:$list[$k]['status']="充值成功"; break;
					case 3:$list[$k]['status']="未充值"; break;
					default:$list[$k]['status']="未知状态";
				}
				
			}
     		$this->assign('list',$list);
     		$new_page=str_replace('/ChongZhi','?s=Home/ChongZhi',$page);
     		$this->assign('page',$new_page);
			$this->display("./Tpl/Home/chongzhi_cz_apply.html");		
    	}
    	
 public function getchongzhi(){

	include_once("Lib/Behavior/pay_config.php");
 	$code = trim($_POST['code']);
    $OrderNo = createOrderNo();
    $checkcode = strtolower($_SESSION['checkcode']);
    if ($code != $checkcode) {
       $this->error('验证码错误！');
        exit;
     }
     if (empty($_POST['bank'])) {
     	 $this->error('银行不能为空，请选择充值银行！');
     	 exit();
     }else {
     	$bankType =$_POST['bank'];
     }
 	$amount = intval($_POST['amount']);   //充值的金额
	if ($amount<0) {
		$this->error("充值金额不能低于1元");
		exit;
	}
	/*
	 * 获取表单数据
	 * */
	$order_id = time(); //您的订单Id号，你必须自己保证订单号的唯一性，千网不会限制该值的唯一性
	$payType = 'bank' ; //充值方式：bank为网银，card为卡类支付
	$account = $_SESSION['USER_KEY_ID'];  //充值的账号

	

	//网银支付
	if ('bank' == $payType) {
	 	   //银行类型
	    /*
	     * 提交数据
	     * */
	    include_once("Lib/Behavior/class.bankpay.php");
	    $bankpay = new bankpay();
	    $bankpay->parter = $eka_merchant_id;  //商家Id
	    $bankpay->key = $eka_merchant_key; //商家密钥
	    $bankpay->type = $bankType;   //商家密钥
	    $bankpay->value = $amount;    //提交金额
	    $bankpay->orderid = $order_id;   //订单Id号
	    $bankpay->callbackurl = $eka_callback_url; //下行url地址
	    $bankpay->hrefbackurl = $eka_bank_hrefbackurl; //下行url地址
	   $this->addChongzhi($amount);
	    
	    //发送
	    $bankpay->send();
	}
	//卡类支付
	else if ('card' == $payType) {
	    $cardType = $_POST['cardType'];   //卡类型
	    $card_number = $_POST['card_number'];  //卡号
	    $card_password = $_POST['card_password'];  //卡密
	    /*
	     * 提交数据
	     * */
	    include_once("eka/class.ekapay.php");
	    $ekapay = new ekapay();
	    $ekapay->type = $cardType;   //卡类型	
	    $ekapay->cardno = $card_number;   //卡号
	    $ekapay->cardpwd = $card_password;  //卡密
	    $ekapay->value = $amount;    //提交金额
	    $ekapay->restrict = $eka_restrict;  //地区限制, 0表示全国范围
	    $ekapay->orderid = $order_id;   //订单号
	    $ekapay->callbackurl = $eka_callback_url; //下行url地址
	    $ekapay->parter = $eka_merchant_id;  //商家Id
	    $ekapay->key = $eka_merchant_key; //商家密钥
	    //发送
	    $result = $ekapay->send();
	
	    /*
	     * 处理结果
	     * */
	    switch ($result) {
	        case '0':
	            header("location: pay_card_finish.php?order_id=$order_id");
	            break;
	        case '-1':
	            header("location: pay_card_finish.php?order_id=$order_id");
	            break;
	        case '-2':
	            print('签名错误');
	            break;
	        case '-3':
	            print('<script language="javascript">alert("对不起，您填写的卡号卡密有误！"); history.go(-1);</script>');
	            break;
	        case '-999':
	            print('<script language="javascript">alert("对不起，千网接口维护中，请选择其他的充值方式！"); history.go(-1);</script>');
	            break;
	        default:
	            print('未知的返回值, 请联系千网官方！');
	            break;
	    }
	} else if ('card_muti' == $payType) {
	    include_once("eka/class.ekapay.muti.php");
	
	    $cardType_muti = $_POST['cardType_muti'];
	
	    $card_number = $_POST['card_number'];
	    $card_password = $_POST['card_password'];
	    $card_value = $_POST['card_value'];
	    $restrict = $_POST['restrict'];
	    $attach = $_POST['attach'];
	
	    $ekapay = new ekapay();
	
	    $ekapay->type = $cardType_muti;
	    $ekapay->parter = $eka_merchant_id;
	    $ekapay->cardno = implode(",", $card_number);
	    $ekapay->cardpwd = implode(",", $card_password);
	    $ekapay->value = implode(",", $card_value);
	    $ekapay->restrict = implode(",", $restrict);
	    $ekapay->orderid = $order_id;
	    $ekapay->attach = $attach;
	    $ekapay->callbackurl = $eka_callback_url_muti;
	    $ekapay->key = $eka_merchant_key;
	
	    $result = $ekapay->send();
	
	    switch ($result) {
	        case '0':
	            header("location: pay_card_finish.php?order_id=$order_id");
	            
	            break;
	        case '-1':
	            print("请求参数无效");
	            break;
	        case '-2':
	            print('签名错误');
	            break;
	        case '-3':
	            print('<script language="javascript">alert("卡密为重复提交，千网系统不进行消耗且不进入下行流程。"); history.go(-1);</script>');
	            break;
	        case '-4':
	            print("卡密不符合千网定义的卡号密码面值规则，千网系统不进行消耗且不进入下行流程。");
	            break;
	        case '-999':
	            print('<script language="javascript">alert("对不起，千网接口维护中，请选择其他的充值方式！"); history.go(-1);</script>');
	            break;
	        default:
	            print('未知的返回值, 请联系千网官方！');
	            break;
	    }
	}
 }
    private function addChongzhi($goldnum){
    
    	    $data['typeid'] = 3;
            $data['orderno'] = time();
            $data['url'] = "网银充值";
            $data['goldnum'] = $goldnum;
            $data['userid'] = $_SESSION['USER_KEY_ID'];
            $data['addtime'] = date('Y-m-d H:i:s', time());
            $data['status']=3;
            $m=M('Cz_apply');
            $r=$m->add($data);
    }
 
	 public function returnUrl1(){
    	
    		
    	}
    	
   public function  chongzhi2(){
   	
   
   	$this->display('./Tpl/Home/chongzhi2_cz_apply.html');
   }
    	
    public function chongzhi2_sand(){
    	$eMail='123538919@qq.com';
		$payId='3672831757612722'; //登陆第三方支付大师，点击左侧菜单“密匙管理”获取
		$payKey='BsfdbQQwXvgB2RQdUv2Btm3pvFHprKuY'; //登陆第三方支付大师，点击左侧菜单“密匙管理”获取
		$retUrl='http://www.pkbtc.com?s=Home/ChongZhi/ruturnurl2'; //支付结果接收地址,必须是外网能访问的地址
		
		$orderId=time();
		$payMode=$_POST['payMode'];
		$money=$_REQUEST["money"];
		$signstr='eMail='.$eMail.'&payId='.$payId.'&payKey='.$payKey.'&orderId='.$orderId.'&payMode='.$payMode.'&retUrl='.$retUrl.'&money='.$money;
		
		$sign=strtoupper(md5($signstr));
		
		$this->assign('eMail',$eMail);
		$this->assign('orderId',$orderId);
		$this->assign('payMode',$payMode);
		$this->assign('payKey',$payKey);
		$this->assign('retUrl',$retUrl);
		$this->assign('orderId',$orderId);
		$this->assign('cardPass',$cardPass);
		$this->assign('money',$money);
		$this->assign('money',$money);
		$this->assign('signstr',$signstr);
		$this->assign('sign',$sign);
		
		$this->display('./Tpl/Home/chongzhi2.html');
    	
    }
    public function ruturnurl2(){
    	 require_once("Lib/Behavior/pay_config.php");
		require_once("Lib/Behavior/class.bankpay.php");
		
		//获取返回的下行数据
		$orderid        = trim($_GET['orderid']);
		$opstate        = trim($_GET['opstate']);
		$ovalue         = trim($_GET['ovalue']);
		$ekaorderid		= trim($_GET['ekaorderid']);
		$ekatime		= trim($_GET['ekatime']);
		
		//进行千网签名认证
		$bankpay		= new bankpay();
		$bankpay->key	= $eka_merchant_key;
		$bankpay->recive();
	
		if ($opstate==0) {
				//你的业务处理，注意查重，避免重复增加服务
			$m=M('Cz_apply');
			$r=$m->where("orderno=$orderid and status=3 and typeid=3")->find();
			if (!$r) {
				Header("Location:?s=Home/User");
			} 
			
			$C=M(Chong_zhi);
			$id=$r['userid'];
			$r=$C->where("userid=$id and typeid=5")->setInc('goldnum',$ovalue);
			$data['status']=1;
			$m->where("orderno=$orderid")->save($data);
			//充值增加一个红包
			$this->addHongBao($id);
			echo "<script language=javascript>this.window.opener = null;window.close();</script>";
			echo ("opstate=0");    
		}
    }
 public function chongzhi3(){
    	$money=$_POST['money'];
    	$this->assign('money',$money);
    	$this->display("./Tpl/Home/chongzhi3.html");
    }
    
    
//开红包    
public function hongbao(){
	$rUser=M('User');
	$rChongzhi=M('Chong_zhi');
	$auser=$rUser->field("hongbao")->where("id={$_SESSION['USER_KEY_ID']}")->find();
	if (IS_POST) {
		if (intval($_POST['num'])>=$auser['hongbao']) {
			$this->error('红包数量不足，充值可获取新的红包');
		}
		$hongbao=rand(1,50)/10;
		$r=$rChongzhi->where("userid={$_SESSION['USER_KEY_ID']} and typeid=7")->setInc('goldnum',$hongbao);
		$r1=$rUser->where("id={$_SESSION['USER_KEY_ID']}")->setDec('hongbao',1);
		if ($r) {
			$this->success('您打开一个红包获取奖励'.$hongbao.'个币');
		}else {
			$this->error('打开失败');
		}
	}else {
		$this->assign('hongbao',$auser['hongbao']);
		$this->display("./Tpl/Home/hongbao.html");
	}
	
}
    	
}