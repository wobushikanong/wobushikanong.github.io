<?php
// 本类由系统自动生成，仅供测试用途
class FenhongAction extends CommonAction {

	public function __construct(){
		parent::__construct();

		if($this->role !== 0){
		    $this->error('对不起，您没有权限！');
			exit;
		}

	    $this->Admin=D('Admin');
	}
	public function index(){
		$Dao=M('Chong_zhi');
	    $count=$Dao->where('typeid=7')->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,10);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->field('u.id,t_chong_zhi.userid,(t_chong_zhi.goldnum+t_chong_zhi.gdgold) as goldnum,u.username')->join('t_user as u on t_chong_zhi.userid=u.id')->where('t_chong_zhi.typeid=7')->order('goldnum DESC')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
		$new_page=str_replace('Admin/Fenhong','?s=Admin/Fenhong',$page);
		
		$Type=M('Type');
		$type=$Type->select();
		$this->assign('type',$type);
		$this->assign('page', $new_page);//模板变量赋值
		$this->assign('list',$list);
		$this->display('./Tpl/Admin/Fenhong_index.html');
	}
	//处理分红
	public function add(){
		if ($_POST['bizhong']!='') {
			$bizhong=$_POST['bizhong'];
		}else {
			$this->error('请选择分红币种');
		}
		if ($_POST['type']!='') {
			$type=$_POST['type'];
		}else {
			$this->error('请选择分红方案');
		}
		if (($_POST['money'])!='') {
				$money=$_POST['money'];
			}else {
				$this->error('每币分红值不能为空');
			}
		if (($_POST['num'])!='') {
				$num=intval($_POST['num']);
			}else {
				$this->error('分红会员数量不能为空');
			}
		if ($type==4) {
			$Dao=M('Factory_user');
			$list=$Dao->field('sum(t_factory_user.num)as goldnum,t_user.id as userid,t_user.username')->join("t_user on t_factory_user.user=t_user.id")->where("status=1")->group('t_factory_user.user')->limit($num)->order('goldnum DESC')->select();
		}else{
			$Dao=M('Chong_zhi');
			$list = $Dao->field('u.id,t_chong_zhi.userid,(t_chong_zhi.goldnum+t_chong_zhi.gdgold) as goldnum,u.username')->join('t_user as u on t_chong_zhi.userid=u.id')->where('t_chong_zhi.typeid='.$type)->order('goldnum DESC')->limit($num)->select();
		}
		switch ($type){
			case 5:$laiyuan='人民币持币数排行所得'; break;
			case 7:$laiyuan='虚拟币持币数排行所得'; break;
			case 4:$laiyuan='矿机数排行所得'; break;
			default:$laiyuan='分红所得';
		}
	
		//分红
		foreach ($list as $k=>$v){
			$r=$Dao->where("userid={$v['userid']} and typeid=$bizhong")->setInc('goldnum',$money*$v['goldnum']);
			$this->addFenhongLog($v['userid'], $v['username'], $bizhong, $money*$v['goldnum'],$k,$laiyuan);
		}
		if ($r) {
			$this->success('分红成功');
		}else {
			$this->error('分红失败');
		}
		
	}
	//获取指定数量用户
	public function getAllNum(){
		$num=intval($_POST['num']);
		$typeid=intval($_POST['type']);
		if ($typeid==4) {
			$Dao=M('Factory_user');
			$sql='SELECT SUM(allsuanli) AS goldnum,a.username FROM(SELECT t_factory.suanli*t_factory_user.num AS allsuanli, t_user.username, t_factory.suanli, t_factory_user.id, t_factory_user.factory,t_factory_user.`user`,t_factory_user.num FROM `t_factory_user` JOIN t_factory ON t_factory_user.factory=t_factory.id JOIN t_user ON t_factory_user.`user`=t_user.id WHERE t_factory_user.status=1 ) as a GROUP BY USER ORDER BY allsuanli DESC LIMIT '.$num;
			$list=$Dao->query($sql)			
			foreach ($list as $v){
				$item+=$v['goldnum'];
			}
		}else {
			$Dao=M('Chong_zhi');
			$list = $Dao->field('u.id,t_chong_zhi.userid,(t_chong_zhi.goldnum+t_chong_zhi.gdgold) as goldnum,u.username')->join('t_user as u on t_chong_zhi.userid=u.id')->where('t_chong_zhi.typeid='.$typeid)->order('goldnum DESC')->limit($num)->select();
			foreach ($list as $v){
				$item+=$v['goldnum'];
			}
		}
		$data['num']=$item;
		//$data['info']=$Dao->getLastSql();
		$data['list']=$list;
		$this->ajaxReturn($data);
		
	}
	//分红日志
	private function addFenhongLog($id,$user,$type,$goldnum,$k,$laiyuan){
		$Fen=M('Fenhong_log');
		$log=array(
					'userid'=>$id,
					'user'=>$user,
					'type'=>$type,
					'num'=>$goldnum,
					'order'=>$k,
					'laiyuan'=>$laiyuan,
					'time'=>time(),
				);
		$r=$Fen->add($log);
	}
	public function log(){
		$Dao=M('Fenhong_log');
	    $count=$Dao->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,10);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->field('t_fenhong_log.userid,t_fenhong_log.user,t_fenhong_log.time,t_fenhong_log.user,t_fenhong_log.num,t_fenhong_log.type,t.name')->join('t_type as t on t_fenhong_log.type=t.id')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询

		
		$new_page=str_replace('Admin/Fenhong','?s=Admin/Fenhong',$page);
		
		$this->assign('page', $new_page);//模板变量赋值
		$this->assign('list',$list);
		$this->display('./Tpl/Admin/Fenhong_log.html');
	}
	
	

}