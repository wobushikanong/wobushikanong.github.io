<?php
class KuangAction extends CommonAction {

    private $Ks;
	private $Issue;
	private $Company;
	private $User;
	private $Companyfen;
	public function __construct(){
		parent::__construct();
		$this->checkAuth();
		$this->checkReal();
		$this->Ks = D('Buy');
		$this->Issue = D('Issue');
		$this->Company = D('Company');
		$this->User = D('User');
		$this->Companyfen = D('Companyfen');
	}

    public function index(){
		
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Ks->where('uid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num) > 0 ? ceil($count/$per_num) : 1;
		if($page > $page_num) $page = $page_num;
        
		$list = $this->Ks->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();
        foreach($list as $k => $v){
			$list[$k]['num'] = floatval($v['num']);
		}
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=2>您还没有认购记录！</td>');
		$this->assign('log',$list);
        $sum = $this->Ks->where('uid='.$this->auth['id'])->sum('num');
		$this->assign('sum',floatval($sum));

		$todaysum = $this->Ks->where('uid='.$this->auth['id'].' and DATE(FROM_UNIXTIME(ctime))=CURDATE()')->sum('num');
		$this->assign('todaysum',floatval($todaysum));

		$issue = $this->Issue->where('status=0')->find();
		$issue['price'] = floatval($issue['price']);
		$issue['num'] = floatval($issue['num']);
		$issue['limit'] = floatval($issue['limit']);
		$issue['cur'] = floatval($issue['num']-$issue['deal']);
		$this->assign('issue',$issue);

 		$this->display('./Tpl/Home/Kuang.html');
    }
    
	public function company(){
		$list = $this->Company->order('ctime desc')->select();
		foreach($list as $k => $v){
		    $list[$k]['kg'] = floatval($v['kg']);
			$list[$k]['ks'] = floatval($v['ks']);
		}
		$this->assign('list',$list);
		$this->assign('empty','<tr><td colspan=3>没有记录！</td>');

        $curnum = $this->sys['companylimit'] - $this->auth['companynum'] > 0 ? floatval($this->sys['companylimit'] - $this->auth['companynum']) : 0;
		$this->assign('curnum',$curnum);
	    $this->display('./Tpl/Home/Company.html');
	}

	public function zujian(){
	    $num = trim($_POST['num']);
		$num = floor($num);
		if(!chkNum($num)){$this->ajaxReturn('','公司数量不能为空或低于1个！',1);exit;}

		$mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_company write');
		$rs = array();

        $u = $mo->table('t_user')->find($this->auth['id']);
        if($u['companynum'] + $num > $this->sys['companylimit']){$mo->query('rollback');$this->ajaxReturn('','公司数量超过最大限制！',1);exit;}

        $curkg = ($u['companynum'] + $num)*$this->sys['companykg'];
		if($u['xnb']<$curkg){$mo->query('rollback');$this->ajaxReturn('','矿工数量不够！',1);exit;}

		$rs[] = $mo->table('t_company')->add(array(
		    'uid'=>$this->auth['id'],
			'kg'=>$this->sys['companykg'],
		    'ks'=>$this->sys['companyks'],
			'ctime'=>time()
		));
		$rs[] = $mo->table('t_user')->save(array(
		    'id'=>$this->auth['id'],
			'companynum'=>array('exp','companynum+'.$num)
		));

		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			$this->ajaxReturn('','组建成功！',0);
		}else{
			$mo->query('rollback');
		    $this->ajaxReturn('','组建失败！',1);
		}
	}

	public function mining(){
	    $iskuang = intval($_POST['iskuang']);
		if($iskuang==0)
			$iskuang=1;
		else
			$iskuang=0;
		$rs = $this->User->save(array('id'=>$this->auth['id'],'iskuang'=>$iskuang));
        if($rs) $this->ajaxReturn($iskuang,'',0);
		else $this->ajaxReturn('','',1);
	}

	public function companyfen(){
		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Companyfen->where('uid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num) > 0 ? ceil($count/$per_num) : 1;
		if($page > $page_num) $page = $page_num;
        
		$list = $this->Companyfen->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($list as $k => $v){
		    $list[$k]['num'] = floatval($v['kg']);
		}
		$this->assign('list',$list);
		$this->assign('empty','<tr><td colspan=2>没有记录！</td>');

	    $this->display('./Tpl/Home/Companyfen.html');
	}
}