<?php

class GameAction extends CommonAction {

    private $Safe;
    private $SRs=array();
    private $douSysArr=array();


    public function __construct(){
        parent::__construct();
        $this->checkAuth();

        $this->User=D('User');
        $this->ChongZhi=D('ChongZhi');
        $this->Type=D('Type');

        $this->DouSys=D('Dousys');
        $this->Dou=D('Dou');
        $this->Doulog=D('Doulog');
        $this->Doupool=D('Doupool');
        $this->Doupoollog=D('Doupoollog');



        $this->Safe = new Model();
        $this->Safe->startTrans();//创建安全事务

        $this->douSysArr=$this->DouSys->where('id = 1')->find();

        if($this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find()){
            $this->updateDdzDou();//同步足金豆和 斗地主
        }

}

    public function index(){
        $Dou=$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find();
        if(!$Dou){
            $this->assign('douBank',1);
            $this->display('./Tpl/Home/user_dou.html');
            exit;
        }
        $this->assign('userDou',$Dou['num']);

        $per_num = 10;
        $page = is_numeric($_GET['page']) ? $_GET['page'] : 1;
        $count = $this->Doulog->where('user_id='.$_SESSION['USER_KEY_ID'])->count();
        $page_num = ceil($count/$per_num);

        if($page < 1){
            $page = 1;
        }elseif($page > $page_num){
            $page = $page_num;
        }
        $this->assign('Url',$this->path.'/Game/index/');


        $Doulog=$this->Doulog->
                       where('user_id='.$_SESSION['USER_KEY_ID'])->
                       limit(($page-1)*$per_num.','.$per_num)->
                       order('id desc')->select();
        foreach($Doulog as &$val){
            $val['addtime']=date('Y-m-d H:i:s',$val['addtime']);
        }
        $this->assign('userDouLog',$Doulog);
        $this->assign('page',$page);
        $this->assign('page_num',$page_num);



        $this->display('./Tpl/Home/user_dou.html');
    }

    public function Chongzhi(){
        $this->checkOpen();
        if(!isset($_POST['typeId'])||!isset($_POST['num'])){
            $chongzhi =
                $this->ChongZhi->
                join('t_type as t on t.id=t_chong_zhi.typeid')->
                field('t.id as type_id,t.nickname,t.dourate,t.douflag,t_chong_zhi.*')->
                where('userid=' . $_SESSION['USER_KEY_ID'])->
                select();
            foreach ($chongzhi as $key => $val) {
                $chongzhi[$key]['total'] = $val['goldnum'] + $val['gdgold'];
                $chongzhi[$key]['total'] = round($chongzhi[$key]['total'], 8);

                $chongzhi[$key]['canget']=round($val['goldnum']/$val['dourate']);

            }
            $this->assign('chongzhi', $chongzhi);
            $this->display('./Tpl/Home/user_douChongzhi.html');
        }else{
            $flag=0;
            $typeId=AlFilter($_POST['typeId'],'D');
            $num=AlFilter($_POST['num'],'D');
            if(!$typeId||!$num||$num <= 0){
                echo json_encode(array('flag'=>-1));
                exit;
            }

            $userMoney=$this->ChongZhi->where('userid='.$_SESSION['USER_KEY_ID'].' and typeid='.$typeId)->find();
            $Type=$this->Type->where('id = '.$typeId)->find();
            $Dou=$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find();
            $dourate=$Type['dourate'];
            $douflag=$Type['douflag'];
            if(!$douflag){
                echo json_encode(array('flag'=>-2));
                exit;
            }

            if($num > $userMoney['goldnum']){
                //余额不足
                echo json_encode(array('flag'=>-3));
                exit;
            }

            $trueNum=$Dou['num']+$num;
            $al = new Model();
            $al->startTrans();
            $rs[] = $al->table('t_chong_zhi')->save(array(
                'id' => $userMoney['id'],
                'goldnum' => coin($userMoney['goldnum'] - ceil($num*$dourate)),
            ));

            $rs[] = $al->table('t_dou')->save(array(
                'id' => $Dou['id'],
                'num' =>$trueNum,
            ));

            $rs[] = $al->table('t_doulog')->add(array(
                'user_id' => $_SESSION['USER_KEY_ID'],
                'type'=>'充值',
                'numlog' =>$num,
                'content'=>$Type['nickname'].'充值',
                'addtime'=>time()
            ));

            if(chkArr($rs)){
                $al->commit();
                echo json_encode(array('flag'=>1));
                exit;
            }else{
                $al->rollback();
                echo json_encode(array('flag'=>-999));
                exit;
            }
        }
    }

    public function Tixian(){
        $this->checkOpen();
       if(!isset($_POST['typeId'])||!isset($_POST['num'])){
            $DouType =$this->Type->select();
            $r2=$this->Dou->where('user_id=' . $_SESSION['USER_KEY_ID'])->find();
            $DouNum=$r2['num'];
            foreach ($DouType as &$val) {
                $val['canget'] = $DouNum*$val['dourate'];
            }
           $this->assign('DouNum',$DouNum);
            $this->assign('DouType', $DouType);
        $this->display('./Tpl/Home/user_douTixian.html');
       }else{
           $flag=0;
           $typeId=AlFilter($_POST['typeId'],'D');
           $num=AlFilter($_POST['num'],'D');
           if(!$typeId||!$num||$num <= 0){
               echo json_encode(array('flag'=>-1));
               exit;
           }

           $userMoney=$this->ChongZhi->where('userid='.$_SESSION['USER_KEY_ID'].' and typeid='.$typeId)->find();
           $Type=$this->Type->where('id = '.$typeId)->find();
           $Dou=$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find();
           $dourate=$Type['dourate'];
           $douflag=$Type['douflag'];
           if(!$douflag){
               echo json_encode(array('flag'=>-2));
               exit;
           }

           if($num > $Dou['num']){
               //余额不足
               echo json_encode(array('flag'=>-3));
               exit;
           }

           $trueNum=$Dou['num']-$num;
           $al = new Model();
           $al->startTrans();
           $rs[] = $al->table('t_chong_zhi')->save(array(
               'id' => $userMoney['id'],
               'goldnum' => coin($userMoney['goldnum'] + ceil($num*$dourate)),
           ));

           $rs[] = $al->table('t_dou')->save(array(
               'id' => $Dou['id'],
               'num' =>$trueNum,
           ));

           $rs[] = $al->table('t_doulog')->add(array(
               'user_id' => $_SESSION['USER_KEY_ID'],
               'type'=>'提现',
               'numlog' =>$num,
               'content'=>$Type['nickname'].'提现',
               'addtime'=>time()
           ));

           if(chkArr($rs)){
               $al->commit();
               echo json_encode(array('flag'=>1));
               exit;
           }else{
               $al->rollback();
               echo json_encode(array('flag'=>-999));
               exit;
           }
       }
    }
    public function openDou(){
        if($this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find()){
            echo -999;
            exit;
        }
        $dou= new Model();
        $dou->startTrans();//创建安全事务
        $data['user_id']=$_SESSION['USER_KEY_ID'];
        $data['num']='0';
        $dou->table('t_dou')->add($data);
        echo $dou->commit();

    }
    public function checkOpen(){
        if(!$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find()){
            header('Location:/?s=Home/Game');
            exit;
        }
    }
    public function zhuanpan(){
        $this->checkOpen();
        if(!$_POST){
        $this->assign('alCount',$this->getCountForPrice());
            $this->assign('alPool',$this->getPoolNum());
            $this->assign('alMyDou',$this->getDou());
            $this->assign('description',$this->douSysArr['description']);
        $this->display('./Tpl/Home/user_zhuanpan.html');

        }else{

         $userDouNum=$this->getDou();//当前用户的豆
         $veryDel=$this->getVeryFree();//每次抽奖消耗豆

         if($userDouNum < $veryDel){
             $result['flag']=0;
             $result['msg']='当前您的豆('. $userDouNum .')不够，抽奖至少需要'. $veryDel .'个豆！';
             echo json_encode($result);
             exit;
         }

         if(!$this->getCountForPrice()){
             $result['flag']=-1;
             $result['msg']='很抱歉，今天你已经没有抽奖机会了，明天再来看看吧！';
             echo json_encode($result);
             exit;
         }else{
             //获取剩下的抽奖次数
             $result['count']=$this->getCountForPrice();
         }

         $result['flag']=1;
         $result['poolNum']=$this->getPoolNum();
         $result['alMyDou']= $userDouNum;
		$r3=$this->Doupool->where('id=1')->find();
         $allPoolnum=$r3['allnum'];

         $rid =$this->getLuck(); //根据概率获取奖项id

        $priceRank=$this->priceRank($rid);//获奖比例
        $haveGetPrice=round($priceRank*$allPoolnum);



        $ChouJiang=$this->run($rid);//中奖指示（制定角度到前台显示）
        $msga=$haveGetPrice>$veryDel?'赚：'.($haveGetPrice - $veryDel):'亏'.($veryDel-$haveGetPrice);

        $result['angle']=$ChouJiang['angle'];
        $result['prize'] = $ChouJiang['prize'].'奖金为'.$haveGetPrice.'，扣除手续费：'. $veryDel.'个 最终'.$msga.'个';


        //减去抽奖用豆增加获奖豆  更新奖池豆
        $this->subDou($userDouNum - $veryDel+$haveGetPrice,$veryDel+$allPoolnum-$haveGetPrice);

        $this->DouPoolLog($haveGetPrice, $ChouJiang['prize']);//写入奖池日志

        //存储中奖信息到用户账号日志
        $this->savePriceLog($ChouJiang['prize'],$haveGetPrice,$veryDel);
            if(chkArr($this->SRs)){
                $this->Safe->commit();
                echo json_encode($result);
                exit;
            }else{
                $this->Safe->rollback();
                $result=array();
                $result['flag']=-999;
                $result['msg']='很抱歉，本次程序运行出错！';
                echo json_encode($result);
            }
        }


    }

    //减去抽奖用豆增加 奖池豆
    private function subDou($num,$poolNum){
        $this->SRs[] = $this->Safe->table('t_doupool')->save(array(
            'id'=> 1,
            'allnum' =>$poolNum
        ));
        $Dou=$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find();
        $this->SRs[] = $this->Safe->table('t_dou')->save(array(
            'id'=>$Dou['id'],
            'num' =>$num
        ));
    }

    private function DouPoolLog($haveGetPrice,$type){
        $this->SRs[] = $this->Safe->table('t_doupoollog')->add(array(
            'type'=>$type,
            'userid'=>$_SESSION['USER_KEY_ID'],
            'num' =>$haveGetPrice,
            'addtime'=>time()
        ));
    }
    //运行抽奖程序
    private function run($rid){
        $prize_arr = array(
            '0' => array('id'=>1,'min'=>3,'max'=>26,'prize'=>'一等奖','v'=>1),
            '1' => array('id'=>2,'min'=>304,'max'=>326,'prize'=>'二等奖','v'=>2),
            '2' => array('id'=>3,'min'=>244,'max'=>266,'prize'=>'三等奖','v'=>5),
            '3' => array('id'=>4,'min'=>184,'max'=>206,'prize'=>'四等奖','v'=>7),
            '4' => array('id'=>5,'min'=>124,'max'=>146,'prize'=>'五等奖','v'=>10),
            '5' => array('id'=>6,'min'=>64,'max'=>86,'prize'=>'六等奖','v'=>25),
            '6' => array('id'=>7,'min'=>array(34,94,154,214,274,334),
                'max'=>array(56,116,176,236,296,356),'prize'=>'七等奖','v'=>50)
        );



        $res = $prize_arr[$rid]; //中奖项
        $min = $res['min'];
        $max = $res['max'];
        if($rid==6){ //等奖
            $i = rand(0,5);
            $result['angle'] = rand($min[$i],$max[$i]);
        }else{
            $result['angle'] = rand($min,$max); //随机生成一个角度
        }
        $result['prize']=$res['prize'];
        return $result;
    }



    //保存中奖奖项
    private function savePriceLog($type,$haveGetPrice,$veryDel){
        $msg=$haveGetPrice>$veryDel?'赚：'.($haveGetPrice - $veryDel):'亏'.($veryDel-$haveGetPrice);
        $this->SRs[] = $this->Safe->table('t_doulog')->add(array(
            'user_id' => $_SESSION['USER_KEY_ID'],
            'type'=>2,  //抽奖标志位 2
            'numlog' =>$haveGetPrice-$veryDel,
            'content'=>'奖次'.$type.',奖金'.$haveGetPrice.',手续费'.$veryDel.','.$msg,
            'addtime'=>time()
        ));
    }

    //获取剩余抽奖次数
    private function getCountForPrice(){
        date_default_timezone_set('Asia/Shanghai');
        $todaydate = date('Y-m-d');
        $todayunix = strtotime($todaydate);  //获取今天零点的unix时间戳
        $userCount=$this->Doulog->where( 'user_id='.$_SESSION['USER_KEY_ID'].' and type = 2 and addtime >= '.$todayunix )->count();
        return $this->douSysArr['count'] > $userCount?$this->douSysArr['count'] - $userCount:0;
    }


    private function getDou(){
        //获取用户当前豆数
        $r5=$this->Dou->where('user_id='.$_SESSION['USER_KEY_ID'])->find();
        return $r5['num'];
    }
    //获取每次抽奖需要的费用
    private function getVeryFree(){
       //每次抽奖需要100个豆
        return $this->douSysArr['needdou'];
    }

    private function getPoolNum(){
    	$r=$this->Doupool->where('id = 1')->find();
         return $r['allnum'];
     }
    //获奖比例
    private function priceRank($rid){
        switch($rid){
            case '0': return $this->douSysArr['price0'];break;
            case '1': return $this->douSysArr['price1'];break;
            case '2': return $this->douSysArr['price2'];break;
            case '3': return $this->douSysArr['price3'];break;
            case '4': return $this->douSysArr['price4'];break;
            case '5': return $this->douSysArr['price5'];break;
            case '6': return $this->douSysArr['price6'];break;
        }
    }
    private function getLuck(){
        $a[]=$this->douSysArr['luck1'];
        $a[]=$this->douSysArr['luck2'];
        $a[]=$this->douSysArr['luck3'];
        $a[]=$this->douSysArr['luck4'];
        $a[]=$this->douSysArr['luck5'];
        $a[]=$this->douSysArr['luck6'];
        $luckNum=rand(1,100);
        foreach($a as $key=>$val){
            $val*=100;
            if($luckNum<= $val)
                return $key;
        }
        return  count($a);
    }

    //获取我的抽奖记录
    public function getMyPrice(){
         $arr=$this->Doulog->where('user_id='.$_SESSION['USER_KEY_ID'].' and type = 2')->field('numlog,content,addtime')->limit(10)->order('id desc')->select();
          foreach($arr as &$val){
              $val['addtime']=Date('Y-m-d H:i:s',$val['addtime']);
          }
                  echo json_encode($arr);
    }

    //获取最新中奖轮播
    public function getNewDouTrans(){
        $arr=$this->Doulog->where('type = 2')->field('user_id,numlog,content,addtime')->limit(0,10)->order('id desc')->select();
        foreach($arr as &$val){
            $val['addtime']=Date('m-d H:i',$val['addtime']);
            $val['content']=mb_substr($val['content'], 2, 3, 'utf-8');

       }
        echo json_encode($arr);
    }


    //农场游戏
    public function farm(){
        $this->checkOpen();//首先检查开启足金豆没有
        $this->assign('IsOpen',$this->checkOpenFarm());

        $this->assign('gamedes',$this->sysv['gamedes']);
        $UserBi=$this->getFarmCoin();


        session('NMC_ZUJINDOU',$UserBi['ZUJINDOU']);
        session('NMC_ZUJINDOU_LIMIT',$this->sysv['NMC_ZUJINDOU_LIMIT']);
        session('NMC_ZUJINBI',$UserBi['ZUJINBI']);
        session('NMC_ZUJINBI_LIMIT',$this->sysv['NMC_ZUJINBI_LIMIT']);


        $this->display('./Tpl/Home/user_douFarm.html');
    }

    //检查农场是否开启
    private function checkOpenFarm(){
        $checkFarm= new Model();
        return  $checkFarm->table('farm_al_config')->where('uid = '.$_SESSION['USER_KEY_ID'])->find();

    }

    //开启农牧场
    public function openFarm(){
        $checkFarm= new Model();
        if( $checkFarm->table('farm_al_config')->where('uid = '.$_SESSION['USER_KEY_ID'])->find()){
            echo -999;
            exit;
        }


        $Sys =D('Sys')->where('id=1')->find();

        $farm= new Model();
        $farm->startTrans();//创建安全事务

        $data['uid']=$_SESSION['USER_KEY_ID'];
        $data['username']=$_SESSION['USER_KEY'];
        $data['money']=$Sys['farm_songjinbi'];
        $data['YB']=$Sys['farm_songybi'];
        $farm->table('farm_al_config')->add($data);
        echo $farm->commit();
    }

    //获取农场各种金҉币҉资҉料҉
    public function getFarmMoney(){
       $moneyArr=$this->getFarmMoneyInfo();
       echo json_encode($moneyArr);
    }
    //获取用户各种币资料
    public function getFarmCoin(){
        $UserInfo=array();
        $Farm= new Model();
        $arr1=$Farm->table('farm_al_config')->where('uid = '.$_SESSION['USER_KEY_ID'])->find();
        $UserInfo['jinbi']=$arr1['money'];
        $UserInfo['ybi']=$arr1['YB'];
        $r=$this->Dou->where('user_id = '.$_SESSION['USER_KEY_ID'])->find();
        $UserInfo['ZUJINDOU']=$r['num'];
        $r1=D('ChongZhi')->where('userid = '.$_SESSION['USER_KEY_ID'].' and typeid = 7')->find();
        $UserInfo['ZUJINBI']=$r1['goldnum'];
        return $UserInfo;
    }
    //获取用户各种币资料
    public function getFarmRate(){
        $Arr=D('Sys')->where('id=1')->find();
        $UserInfo['ajrate']= $Arr['farm_ajrate'];
        $UserInfo['jarate']= $Arr['farm_jarate'];
        $UserInfo['yarate']= $Arr['farm_yarate'];
        $UserInfo['ayrate']= $Arr['farm_ayrate'];
        return $UserInfo;
    }

    //获取农场币种兑换配置
    private function getFarmMoneyInfo(){
        $UserInfo=$this->getFarmCoin();
        $ZUJINDOU=$UserInfo['ZUJINDOU'];
        $ZUJINBI=$UserInfo['ZUJINBI'];
        $jinbi=$UserInfo['jinbi'];
        $Ybi=$UserInfo['ybi'];

        $rate=$this->getFarmRate();
        $ajrate=$rate['ajrate'];//足金豆/金币
        $jarate=$rate['jarate'];//金币/足金豆
        $yarate=$rate['yarate'];//金币/足金币
        $ayrate=$rate['ayrate'];//足金币/金币

        $arr=array(
            'ZUJINDOU'=>$ZUJINDOU,
            'ZUJINBI'=>$ZUJINBI,
            'tjinbi'=>$jinbi,
            'tYbi'=>$Ybi,
            'ajrate'=>$ajrate,
            'tjarate'=>$jarate,
            'tyarate'=>$yarate,
            'ayrate'=>$ayrate,
        );
        return $arr;

    }

    private function getIdByUid($uid,$table,$uidname){
        $Farm= new Model();
        $r=$Farm->table($table)->where($uidname.' = '.$_SESSION['USER_KEY_ID'])->find();
        return $r['id'];
    }


    //农场充值提现处理
    public function farmBank(){
         $num=AlFilter($_POST['num'],'D');
         if(!$num){json_decod(array('msg'=>'参数错误！'));die;}
         switch($_POST['Flag']){
             case 'jinbichongzhi':$this->jinbichongzhi($num);break;
             case 'ybichongzhi':$this->ybichongzhi($num);break;
             case 'ZUJINDOUtixian':$this->ZUJINDOUtixian($num);break;
             case 'ZUJINBItixian':$this->ZUJINBItixian($num);break;
             default:echo json_decod(array('msg'=>'参数错误！'));die;
         }
     }
    private function jinbichongzhi($num){
        $UserInfo=$this->getFarmCoin();
        $rate=$this->getFarmRate();
        if($UserInfo['ZUJINDOU']< $rate['ajrate']*$num||$num<=0){
            echo json_encode(array('msg'=>-1));
            die;
        }

        $farm= new Model();
        $farm->startTrans();//创建安全事务
        //减豆
        $rs[] = $farm->table('t_dou')->save(array(
            'id' => $this->getIdByUid($_SESSION['USER_KEY_ID'],'t_dou','user_id'),
            'num' => intval($UserInfo['ZUJINDOU']-$rate['ajrate']*$num),
        ));
        //加金币
        $rs[] = $farm->table('farm_al_config')->save(array(
            'id' =>$this->getIdByUid($_SESSION['USER_KEY_ID'],'farm_al_config','uid'),
            'money' =>$UserInfo['jinbi']+$num,
        ));

        if(chkArr($rs)){
            $farm->commit();
            echo json_encode(array('flag'=>1));
            exit;
        }else{
            $farm->rollback();
            echo json_encode(array('flag'=>-999));
            exit;
        }


    }
    private function ybichongzhi($num){
        $UserInfo=$this->getFarmCoin();
        $rate=$this->getFarmRate();
        if($UserInfo['ZUJINBI'] < $rate['ayrate']*$num||$num<=0){
            echo json_encode(array('msg'=>-1));
            die;
        }

        $farm= new Model();
        $farm->startTrans();//创建安全事务
        $r=D('ChongZhi')->where('userid = '.$_SESSION['USER_KEY_ID'].' and typeid = 7')->find();
        $ZUJINBIId=$r['id'];
        //减足金币
        $rs[] = $farm->table('t_chong_zhi')->save(array(
            'id' =>$ZUJINBIId,
            'goldnum' => $UserInfo['ZUJINBI']-$rate['ayrate']*$num,
        ));
        //加Y币
        $rs[] = $farm->table('farm_al_config')->save(array(
            'id' =>$this->getIdByUid($_SESSION['USER_KEY_ID'],'farm_al_config','uid'),
            'YB' =>$UserInfo['ybi']+$num,
        ));

        if(chkArr($rs)){
            $farm->commit();
            echo json_encode(array('flag'=>1));
            exit;
        }else{
            $farm->rollback();
            echo json_encode(array('flag'=>-999));
            exit;
        }
    }


    private function ZUJINDOUtixian($num){
        $UserInfo=$this->getFarmCoin();
        $rate=$this->getFarmRate();
        if($UserInfo['jinbi'] < $rate['jarate']*$num||$num<=0){
            echo json_encode(array('msg'=>-1));
            die;
        }

        $farm= new Model();
        $farm->startTrans();//创建安全事务
        //加豆
        $rs[] = $farm->table('t_dou')->save(array(
            'id' => $this->getIdByUid($_SESSION['USER_KEY_ID'],'t_dou','user_id'),
            'num' => $UserInfo['ZUJINDOU']+$num,
        ));
        //减金币
        $rs[] = $farm->table('farm_al_config')->save(array(
            'id' =>$this->getIdByUid($_SESSION['USER_KEY_ID'],'farm_al_config','uid'),
            'money' =>$UserInfo['jinbi']-$rate['jarate']*$num,
        ));

        if(chkArr($rs)){
            $farm->commit();
            echo json_encode(array('flag'=>1));
            exit;
        }else{
            $farm->rollback();
            echo json_encode(array('flag'=>-999));
            exit;
        }

    }


    private function ZUJINBItixian($num){
        $UserInfo=$this->getFarmCoin();
        $rate=$this->getFarmRate();
        if($UserInfo['ybi']< $rate['yarate']*$num||$num<=0){
            echo json_encode(array('msg'=>-1));
            die;
        }


        $farm= new Model();
        $farm->startTrans();//创建安全事务
        $r=D('ChongZhi')->where('userid = '.$_SESSION['USER_KEY_ID'].' and typeid = 7')->find();
        $ZUJINBIId=$r['id'];
        //加足金币
        $rs[] = $farm->table('t_chong_zhi')->save(array(
            'id' =>$ZUJINBIId,
            'goldnum' => $UserInfo['ZUJINBI']+$num,
        ));
        //减Y币
        $rs[] = $farm->table('farm_al_config')->save(array(
            'id' =>$this->getIdByUid($_SESSION['USER_KEY_ID'],'farm_al_config','uid'),
            'YB' =>$UserInfo['ybi']-$rate['yarate']*$num,
        ));

        if(chkArr($rs)){
            $farm->commit();
            echo json_encode(array('flag'=>1));
            exit;
        }else{
            $farm->rollback();
            echo json_encode(array('flag'=>-999));
            exit;
        }

    }

    //获取金币 Y币
    public function getJYCoin(){
        $UserInfo=$this->getFarmCoin();
        $arr['jinbi']=$UserInfo['jinbi'];
        $arr['Ybi']=$UserInfo['ybi'];
        echo json_encode($arr);
    }




//
    //斗地主游戏
    public function ddz(){
        $this->checkOpen();//首先检查开启足金豆没有


//        $Arr=array(
//            'mode'=>'autoLogin_autoReg',
//            'account'=>'admin',
//            'session'=>'AsidF',
//            'pwd'=>'admin@admin.com',
//            'gender'=>0,
//            'color'=>'dushen'
//        );


        $UserInfo=$this->ddzcheckUser();

        $account=$UserInfo['username'];


        $session=$this->ddzGetSessionId();
        $pwd= 'admin@admin.com';
        $email=$_SESSION['USER_KEY'];
        $color=$this->ddzColor(AlFilter($_GET['color'],'W'));


//        session 传递验证门槛
        $UserBi=$this->getFarmCoin();
        session('DDZ_ZUJINDOU',$UserBi['ZUJINDOU']);
        session('DDZ_ZUJINDOU_LIMIT',$this->sysv['DDZ_ZUJINDOU_LIMIT']);
        session('DDZ_ZUJINBI',$UserBi['ZUJINBI']);
        session('DDZ_ZUJINBI_LIMIT',$this->sysv['DDZ_ZUJINBI_LIMIT']);



        $SwfLink="./ddz/?mode=@autoLogin_autoReg&amp;account=@$account&amp;session=@$session&amp;pwd=@$pwd&amp;email=@$email&amp;gender=@0&amp;color=@$color";
        $this->assign('SwfLink',$SwfLink);

        $this->display('./Tpl/Home/user_ddz.html');
//
    }




    //检查是否开启斗地主游戏
    private function ddzcheckUser(){
        $DDZ= new Model();
        $DDZ->startTrans();//创建安全事务

        $arr=$DDZ->table('ddz_common_member')->where('uid = '.$_SESSION['USER_KEY_ID'])->find();
        if($arr){
            return $arr;
        }else{
            $addArr=array(
                'uid' =>$_SESSION['USER_KEY_ID'],
                'username'=>'HA_'.$_SESSION['USER_KEY'],
                'email'=>$_SESSION['USER_KEY'],
                'password'=>'dba019956ac0b2f75dc549cfd2363d79'
            );

            $DDZ->startTrans();//创建安全事务
            $DDZ->table('ddz_common_member')->add($addArr);//创建 用户表

            $addArrB=array(
                'uid' =>$_SESSION['USER_KEY_ID'],
                'extcredits2'=>0,
                'root'=>0,
            );
            $DDZ->table('ddz_common_member_count')->add($addArrB);//创建 用户豆表
            $DDZ->commit();
            return $addArr;
        }
    }


    private  function ddzColor($color=''){
        if(!$color){
            $color=cookie('DDZCOLOR');
            switch($color){
                case'blue':
                    return 'blue';break;
                case'pink':
                    return 'pink';break;
                default:return 'dushen';
            }
        }else{
            cookie('DDZCOLOR',$color);
            return $color;
        }

    }

    //同步 斗地主 足金豆 和 系统足金豆
    public function updateDdzDou(){

        $this->ddzcheckUser();//检测开通

        $DDZ= new Model();
        $Adou=$DDZ->table('t_dou')->where('user_id = '.$_SESSION['USER_KEY_ID'])->find();

        $Ddou=$DDZ->table('ddz_common_member_count')->where('uid = '.$_SESSION['USER_KEY_ID'])->find();


        if($Ddou['root']<0||$Adou['num'] < 0 ){
            die('足金豆不足了,及时充值喔!');
            return false;
        }



        if($Ddou['extcredits2']!=$Ddou['root']||$Adou['num']!=$Ddou['root']){
             $DDZ->startTrans();//创建安全事务
             $Flag=array();
             $Flag[]=1;

             $newDou=$Adou['num']+($Ddou['extcredits2']-$Ddou['root']);


             if($newDou !=$Adou['num'] ){
                 $ZUJINDOU['id']=$Adou['id'];
                 $ZUJINDOU['num']=$newDou;
                 $Flag[]=$DDZ->table('t_dou')->save($ZUJINDOU);//更新足金豆表
             }


                 $newDdou=array();
                 $newDdou['id']=$Ddou['id'];
                 $newDdou['extcredits2']= $newDou;
                 $newDdou['root']=$newDou;
                 $Flag[]=$DDZ->table('ddz_common_member_count')->save($newDdou);//更新足金豆表



             if(chkArr($Flag)){
                 $DDZ->commit();
                 return true;
             }else{
                 $DDZ->rollback();
                 print_r($Flag);
                 echo $DDZ->getLastSql();
                 echo $DDZ->getDbError();
                 die('安全事务没有执行，刷新试试！');
             }

             return true;

         }else{
             return true;
        }
    }


    //自动检测数据库session
    private function ddzGetSessionId(){
        $DDZ= new Model();


        $arr1=$DDZ->table('ddz_common_session')->where('uid = '.$_SESSION['USER_KEY_ID'])->find();
        if($arr1){
            return $arr1['sid'];
        }else{
            $DDZ->startTrans();//创建安全事务
            $SID=md5($_SESSION['USER_KEY'].rand(100,1000));
            $DDZ->table('ddz_common_session')->add(array(
                'sid' =>$SID,
                'uid' =>$_SESSION['USER_KEY_ID'],
                'username'=>'HA_'.$_SESSION['USER_KEY']
            ));
            $DDZ->commit();
            return $SID;
        }


    }


}