﻿<?php
class AccountAction extends CommonAction {
	private $User;
	private $Email;
	public function __construct(){
        parent::__construct();
        $this->User=D('User');
		$this->Email=D('Email');
	}
	public function login(){
        $this->display('./Tpl/Home/Login.html');
	}
    public function  qqlogin(){
              require_once './Common/QQAPI/qqConnectAPI.php';
              $qc = new QC();
              $qc->qq_login();
    }
    public function callback(){
         require_once './Common/QQAPI/qqConnectAPI.php';
        $qc = new QC();
		$access_token= $qc->qq_callback();
		$openid= $qc->get_openid();
		$qc = new QC($access_token,$openid);
		$arr = $qc->get_user_info();
		
       $where['username']=$openid;
       $user=M('User')->where($where)->find();

       if($user){
           $_SESSION['USER_KEY_ID']=$user['id'];
           $_SESSION['USER_KEY']=$openid;
       }else{
           $rs = M('User')->order('id desc')->find();
           if(chkStr($_SESSION['invit'])){
               $invitup = $_SESSION['invit'];
           }else {
               $invitup ='';
           }
               $r=M('User')->add(array(
                   'able'=>1,
                   'ctime'=>time(),
                   'level'=>1,
                   'invit'=>$rs['id']+1,
                   'invitup'=>$invitup,
                   'username'=>$openid,
				   'password'=>MD5("123456"),
					'pwdshow' => 123456,
					'paypwd'=>123456
               ));
               $_SESSION['USER_KEY_ID']=$r;
               $_SESSION['USER_KEY']=$openid;
       }
       
      echo "<br><center>欢迎<font size=2 ><font color=red size=2>".$arr["nickname"]."</font>登陆奔跑币 <br><a href='/'>点此回到首页</a></font></center>";
    //$this->redirect('/');
    }
	public function go(){
	    $username = $_POST['username'];
		$password = md5($_POST['password']);

        $user = $this->User->where('username=\''.$username.'\'')->find();

		if(!$user||$user['password']!=$password) {$this->ajaxReturn('','用户名或密码错误！',1);exit;}

		$_SESSION['USER_KEY']=$username;
		$_SESSION['USER_KEY_ID']=$user['id'];

		$data['id']=$user['id'];
		$data['logintime']=date('Y-m-d H:i:s',time());
		$data['loginip']=get_client_ip();
		$this->User->save($data);

		$this->ajaxReturn('','登陆成功！正在跳转',0);
	}

	public function loginout(){
	    session(null);
		redirect('/');
	}

	public function checkcode(){
	    $img_height=70;//先定义图片的长、宽  
		$img_width=25;  
		$authnum='';  
		//生产验证码字符  
		$ychar="0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";  
		$list=explode(",",$ychar);  
		for($i=0;$i<4;$i++){  
			$randnum=rand(0,35);  
			$authnum.=$list[$randnum];  
		}  
		//把验证码字符保存到session  
		$_SESSION["checkcode"] = $authnum;  
		  
		  
		$aimg = imagecreate($img_height,$img_width);    //生成图片  
		imagecolorallocate($aimg, 255,255,255);            //图片底色，ImageColorAllocate第1次定义颜色PHP就认为是底色了  
		$black = imagecolorallocate($aimg, 0,0,0);        //定义需要的黑色  
		  
		  
		for ($i=1; $i<=100; $i++) {  
			imagestring($aimg,1,mt_rand(1,$img_height),mt_rand(1,$img_width),"@",imagecolorallocate($aimg,mt_rand(200,255),mt_rand(200,255),mt_rand(200,255)));  
		}  
		  
		//为了区别于背景，这里的颜色不超过200，上面的不小于200  
		for ($i=0;$i<strlen($authnum);$i++){  
			imagestring($aimg, mt_rand(3,5),$i*$img_height/4+mt_rand(2,7),mt_rand(1,$img_width/2-2), $authnum[$i],imagecolorallocate($aimg,mt_rand(0,100),mt_rand(0,150),mt_rand(0,200)));  
		}  
		imagerectangle($aimg,0,0,$img_height-1,$img_width-1,$black);//画一个矩形  
		Header("Content-type: image/PNG");  
		ImagePNG($aimg);                    //生成png格式  
		ImageDestroy($aimg);
	}

	public function reg(){
		if(chkStr($_GET['invit'])){
		    $user = $this->User->where('invit=\''.$_GET['invit'].'\'')->find();
			if($user) $_SESSION['invit'] = $_GET['invit'];
		}
		$this->assign('invit',$_SESSION['invit']);
		$this->display('./Tpl/Home/Reg.html');
    }

	public function insert(){

		$password   = trim($_POST['password']);
		$repassword = trim($_POST['repassword']);
		$paypwd   = trim($_POST['paypwd']);
		$repaypwd = trim($_POST['repaypwd']);
		$username   = trim($_POST['username']);
		$invitup   = trim($_POST['invitup']);

		if(!chkStr($password)||!chkStr($repassword)||$password!=$repassword||!chkStr($username)||!chkStr($paypwd)||!chkStr($repaypwd)||$paypwd!=$repaypwd){$this->ajaxReturn('','信息填写错误！',1);exit;}
		$mo = new Model();
		$user = $this->User->where('username=\''.$username.'\'')->find();
		if($user){$this->ajaxReturn('','该用户名已被使用！',2);exit;}
		$rs = $mo->table('t_user')->order('id desc')->find();
		$data['password'] = md5($password);
		$data['pwdshow']  = $password;
		$data['paypwd']  = $paypwd;
		$data['username'] = $username;
		$data['able'] = 1;
		$data['ctime'] = time();
		$data['invit'] = $rs['id']+1;//date('H',time()).rand(1000,9999);
		
      
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write');

		if(chkStr($_SESSION['invit'])){
			$data['invitup'] = $_SESSION['invit'];
		}elseif(chkStr($invitup)){
			$data['invitup'] = $invitup;
        }
		$rs = $mo->table('t_user')->add($data);
		if($rs){
			$mo->query('commit');
		    $mo->query('unlock tables');
            $_SESSION['invit']='';
			$this->ajaxReturn('','注册成功！马上登录。',0);
		}else{
			$mo->query('rollback');
			$this->ajaxReturn('','注册失败！',1);
		}
    }

	public function lostpwd(){
		$this->display('./Tpl/Home/Lostpwd.html');
    }

	public function getpwd(){
		if(!chkStr($_POST['email'])) {$this->ajaxReturn('','邮箱地址不能为空！',1);exit;}

		$email = $_POST['email'];
		$user = $this->User->where('email="'.$email.'"')->find();
		if(!$user) {$this->ajaxReturn('','邮箱地址错误！',1);exit;}

        $_SESSION['getpwduid'] = $user['id'];

		$e = $this->Email->where('id=2')->find();
		$url = rand(111111,999999);
		$_SESSION['getpwdcode'] = $url;
		$e['content'] = str_replace('[url]',$url,$e['content']);
		$send = $this->sendEmail($email,$e['title'],$e['content']);

		if($send){
			$this->ajaxReturn('','验证码已发送到您的邮箱，请注意查收！',0);
		}else{
			$this->ajaxReturn('','验证码发送失败！',2);
		}
	}

	public function getpwd2(){
		$this->display('./Tpl/Home/Lostpwd2.html');
    }

	public function getpwd3(){
		$this->display('./Tpl/Home/Lostpwd3.html');
    }

	public function setpwd(){
		$password = trim($_POST['password']);
		$checkcode = trim($_POST['checkcode']);
	    if(!chkStr($password)||!chkStr($checkcode)) {$this->ajaxReturn('','密码或验证码不能为空！',1);exit;}
		if($checkcode != $_SESSION['getpwdcode']) {$this->ajaxReturn('','验证码错误！',2);exit;}

		$data['password']=md5($password);
		$data['pwdshow']=$password;
		$data['id'] = $_SESSION['getpwduid'];

		if($this->User->save($data)!==false){
			$this->ajaxReturn('','密码修改成功！',0);
		}else{
			$this->ajaxReturn('','密码修改失败！',3);
		}
	}
}
?>