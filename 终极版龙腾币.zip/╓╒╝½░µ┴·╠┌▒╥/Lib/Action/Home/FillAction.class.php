<?php
class FillAction extends CommonAction {
    private $Fill;

	public function __construct(){
		parent::__construct();
		$this->checkAuth();
	    $this->Fill = D('Fill');
	}

    public function all(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Fill->where('uid='.$this->auth['id'].' and status=1')->count();
        $page_num = ceil($count/$per_num);
        if($page > $page_num) $page = $page_num;

        $list=$this->Fill->where('uid='.$this->auth['id'].' and status=1')->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('mod','list');
		$this->assign('empty','<tr><td colspan="2" style="text-align:center">没有找到数据！</td></tr>');

		$this->display('./Tpl/Home/Fill_list.html');
    }

    public function index(){
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Fill->where('uid='.$this->auth['id'])->count();
        $page_num = ceil($count/$per_num);
        if($page > $page_num) $page = $page_num;

        $list=$this->Fill->where('uid='.$this->auth['id'])->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

        $this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('mod','list');
		$this->assign('empty','<tr><td colspan="2" style="text-align:center">没有找到数据！</td></tr>');

		$this->display('./Tpl/Home/Fill.html');
    }

	public function add(){
	    $this->display('./Tpl/Home/Fill.html');
	}

	public function insert(){
        $rmb = trim($_POST['money']);
        if(!chkNum($rmb)) $this->error('请输入充值金额！');

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_fill write');
		$rs = array();
		$tradeno='Apay'.time();
		$rs[] = $mo->table('t_fill')->add(array(
			'uid'=>$this->auth['id'],
			'num'=>$rmb,
		    'tradeno'=>$tradeno,
			'ctime'=>time()
		));

		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
		    $this->assign('money',$rmb);
		    $this->assign('tradeno',$tradeno);
		    $this->display("./Tpl/Home/payto.html");
		  //  $this->success('充值成功！');
		}else{
			$mo->query('rollback');
		    $this->error('充值失败!');
		}
    }

	//##########
	public function insert2($money,$order_no,$type){
	// $money="0.01";
	// $order_no="Apay1411195123";
	//
		$num = $money;
        if(!chkNum($num)) {
			$this->error('请输入充值金额！');
            exit;
        }

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_fill write,t_user write');
		$rs = array();
		$mo->table('t_fill').
        $fill = $mo->table('t_fill')->where('tradeno=\''.$order_no.'\'')->find();

		if($fill['status']==1){
		    $mo->query('rollback');
			if($type!="notify"){
				$this->error('已经充值了！','/?s=Home/Fill');
			}
			exit;
		}
		$id=$fill['id'];
		$uid=$fill['uid'];

		$rs[] = $mo->table('t_fill')->save(array(
			'id'=>$id,
			'status'=>1
		));

		$rs[] = $mo->table('t_user')->save(array(
			'id'=>$uid,
			'rmb'=>array('exp','rmb+'.$num)
		));
		
		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			if($type!="notify"){
				$this->success('充值成功！','/?s=Home/Fill');
			}
		}else{
			$mo->query('rollback');
			if($type!="notify"){
				$this->error('充值失败！');
			}
		}
		
    }
	
	public function urlreturn(){
		$order_no = $_REQUEST["order_no"];
		$order_amount = $_REQUEST["order_amount"];
		$order_amount=number_format($order_amount,2,".","");
		$return=$_REQUEST["return"]; //return
		$sign=$_REQUEST["sign"];
		$md5key="a59068da06d57e2a8a49a65c7abec098";
		
		$signstr="order_no=".$order_no."&order_amount=".$order_amount."&return=".$return.$md5key;
		$signnew=md5($signstr);
		if($sign==$signnew){
			$this->insert2($order_amount,$order_no,$return);
		}else{
			echo "error";
		}
    }
	
    public function subdata(){
	    $num = trim($_POST['num']);
		$payt = trim($_POST['payt']);
		$bankid=trim(isset($_POST['bankid'])?$_POST['bankid']:"");
        if(!chkNum($num)) {echo '<script language="javascript">history.back();</script>';exit;}

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_fill write');
		$rs = array();

		$tradeno = "Apay".time();
		$alipayuer = $this->sys['alipay'];
		
		$rs[] = $mo->table('t_fill')->add(array(
			'uid'=>$this->auth['id'],
			'num'=>$num,
			'tradeno'=>$tradeno,
			'ctime'=>time()
		));
		
		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			$this->assign('num',$num);
			$this->assign('tradeno',$tradeno);
			$this->assign('alipayuer',$alipayuer);
			$this->assign('cellphone',$cellphone);
			if ($payt==1){
				echo "<script>location.href='http://shop.ykjfy.com/mobaopay/req.php?orderno=".$tradeno."&amount=".$num."&bankid=".$bankid."';</script>";
				exit();
				//$this->display('./mobaopay/Payw.html');
				//$this->display('./Tpl/Home/Payw.html');
			}else{
			    $this->display('./Tpl/Home/Pay.html');
			   }
			
		}else{
			$mo->query('rollback');
			echo '<script language="javascript">history.back();</script>';
		}
	}

	public function returndata(){
        $tradeno=$_GET['name'];  //软件上的[用户名] 支付宝交易中的[付款说明]  相当于网站上的充值订单
		$key=trim($_GET['key']);//接口上的key 与后台key相等后才进行逻辑处理　保证安全
		$money=$_GET['money'];//相当于交易中的支付金额

		if($key!=$this->sys['alipaypwd']){echo '0';exit();}

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_fill write');
		$rs = array();

		$fill = $mo->table('t_fill')->where('tradeno="'.$tradeno.'"')->find();
		if(!$fill || $fill['status']==1){echo '0';exit();}
		
		$rs[] = $mo->table('t_fill')->save(array(
			'uid'=>$fill['id'],
			'status'=>1
		));
		$rs[] = $mo->table('t_user')->save(array(
		    'id'=>$fill['uid'],
			'rmb'=>array('exp','rmb+'.$money)
		));

		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			echo '1';exit();
		}else{
			$mo->query('rollback');
		    echo '0';exit();
		}
    }
}