<?php
class PayAction extends CommonAction {

	public function __construct(){
		parent::__construct();
	}

	public function returndata(){
        $tradeno=$_GET['name'];  //软件上的[用户名] 支付宝交易中的[付款说明]  相当于网站上的充值订单
		$key=trim($_GET['key']);//接口上的key 与后台key相等后才进行逻辑处理　保证安全
		$money=$_GET['money'];//相当于交易中的支付金额

		if($key!=$this->sys['alipaypwd']){echo '0';exit();}

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_fill write');
		$rs = array();

		$fill = $mo->table('t_fill')->where('tradeno="'.$tradeno.'"')->find();
		if(!$fill || $fill['status']==1){echo '0';exit();}
		
		$rs[] = $mo->table('t_fill')->save(array(
			'id'=>$fill['id'],
			'status'=>1
		));
		$rs[] = $mo->table('t_user')->save(array(
		    'id'=>$fill['uid'],
			'rmb'=>array('exp','rmb+'.$money)
		));

		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			echo '1';exit();
		}else{
			$mo->query('rollback');
		    echo '0';exit();
		}
    }
}