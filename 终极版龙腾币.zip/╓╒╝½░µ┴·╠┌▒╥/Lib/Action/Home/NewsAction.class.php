<?php
class NewsAction extends CommonAction {
    private $Art;

	public function __construct(){
		parent::__construct();
	    $this->Art = D('Art');
	}

    public function index(){
        $id = $_GET['id'];
		$cate = $_GET['cate'];

		if(chkNum($id))
            $where = 'id='.$id;
		elseif(chkStr($cate))
            $where = 'cate="'.$cate.'"';

		$rs = $this->Art->where($where)->order('id asc')->find();
        $this->assign($rs);

		$list = $this->Art->where('cate="news"')->order('id asc')->select();
		$this->assign('list',$list);   
 		$this->display('./Tpl/Home/Art.html');
    }
    
	public function show(){
	    $v = $this->Art->where('id='.$_GET['id'])->find();
		$this->assign($v);   
 		$this->display('./Tpl/Home/Art.html');
	}
}