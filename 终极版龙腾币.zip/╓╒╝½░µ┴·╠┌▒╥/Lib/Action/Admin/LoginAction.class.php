<?php
// 本类由系统自动生成，仅供测试用途
class LoginAction extends Action {
	private $Admin;
	public function __construct(){
        parent::__construct();
        $this->Admin=D('Admin');
	}
	public function index(){
        $this->display('./Tpl/Admin/Login.html');
	}

	public function go(){
	    $username = $_POST['username'];
		$password = md5($_POST['password']);
        $user = $this->Admin->where('username=\''.$username.'\'')->find();

		$this->assign('jumpUrl','/?s=Admin/Login');
		if(!$user) $this->error('该用户不存在！');
		if($user['password']!=$password) $this->error('用户名或密码错误！');

		$_SESSION['USER_ADMIN_KEY']=$username;
		$_SESSION['USER_ADMIN_ID']=$user['id'];

		$data['id']=$user['id'];
		$data['Logintime']=time();
		$data['Loginip']=get_client_ip();
		$this->Admin->save($data);

		echo '<script language="javascript">top.location.href="/?s=Admin/";</script>';
	}

	public function loginout(){
		session(null);
		echo '<script language="javascript">top.location.href="/?s=Admin/Login";</script>';
	}
}
?>