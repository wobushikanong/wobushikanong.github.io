<?php
// 本类由系统自动生成，仅供测试用途
class DrawAction extends CommonAction {
	private $Draw;

	public function __construct(){
		parent::__construct();
	    $this->Draw=D('Draw');
	}

    public function index(){
		$status = $_GET['status'] ? $_GET['status'] : 0;
		$urls = '/status/'.$_GET['status'];

		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Draw->where('status='.$status)->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        
		$rs=$this->Draw->join('t_user on t_user.id=t_draw.uid')->field('t_draw.*,t_user.username,t_user.alipay')->where('status='.$status)->limit(($page-1)*$per_num.','.$per_num)->select();
		$this->assign('list',$rs);
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('status',$status);
		$this->assign('urls',$urls);
		$this->assign('empty','<tr><td colspan=9>没有找到数据！</td></tr>');
		$this->display('./Tpl/Admin/Draw.html');
    }

	public function set(){
		if(empty($_GET['id'])){
		   $this->error('对不起，您没有权限！');
		}
		$data['id']=$_GET['id'];
		$data['status'] = 1;
		
		if($this->Draw->save($data)){
			$this->assign('jumpUrl','?s=Admin/Draw');
			$this->success('操作成功！');
		}else{
		    $this->error('操作失败！');
		}
    }

	public function del(){
		if(empty($_GET['id'])){
		   $this->error('对不起，您没有权限！');
		}
	    $id=$_GET['id'];
	    if($this->Draw->where('id='.$id)->delete()){
		    $this->success('删除成功！');
		}else{
		    $this->error('删除失败！');
		}
    }

	public function delAll(){

		if(!empty($_POST['id']) && is_array($_POST['id'])){
			$ids = implode(',',$_POST['id']);
	
			if($this->Draw->where('id in ('.$ids.')')->delete()){
				$this->success('删除成功！');
			}else{
				$this->error('删除失败！');
			}
		}else{
		   $this->error('删除失败！'); 
		}
    }
}