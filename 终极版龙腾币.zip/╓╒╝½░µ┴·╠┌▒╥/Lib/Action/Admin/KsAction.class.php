<?php
// 本类由系统自动生成，仅供测试用途
class KsAction extends CommonAction {
	private $Ks;
	private $User;

	public function __construct(){
		parent::__construct();
	    $this->Ks=D('Buy');
		$this->User=D('User');
	}

    public function index(){
		$where = '1=1';
        if(chkStr($_GET['uid'])) $where.=' and uid='.$_GET['uid'];

		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Ks->where($where)->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        
		$rs=$this->Ks->where($where)->order('ctime desc')->limit(($page-1)*$per_num.','.$per_num)->select();

		foreach($rs as $k => $v){
		    $rs[$k]['uinfo'] = $this->User->find($v['uid']);
		}

		$this->assign('list',$rs);
		$this->assign('module','list');
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=6>没有找到数据！</td></tr>');
		$this->display('./Tpl/Admin/Ks.html');
    }
}