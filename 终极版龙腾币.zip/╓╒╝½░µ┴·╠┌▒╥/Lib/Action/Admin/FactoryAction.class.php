<?php
class FactoryAction extends CommonAction{
	
	public function index(){
		$m=M('Factory');
		$r=$m->select();
		foreach ($r as $k=>$v){
		    switch ($v['buytype']){
		      case 1:$r[$k]['buytype']='TMC'; break;
		      case 2:$r[$k]['buytype']='TG'; break;
		      case 3:$r[$k]['buytype']='RMB'; break;
		    }
		    switch ($v['zengsong']){
		        case 1:$r[$k]['zengsong']='TMC'; break;
		        case 2:$r[$k]['zengsong']='TG'; break;
		        case 3:$r[$k]['zengsong']='RMB'; break;
		    }
		}
		$this->assign('f',$r);
		
		$m=M('Factory_config');
		$r=$m->find();
		$this->assign('c',$r);
		
		
		$r=array(array('id'=>'1','name'=>'TMC'),array('id'=>2,'name'=>'TG'),array('id'=>3,'name'=>'RMB'));
		$this->assign('type',$r);
		$this->display('./Tpl/Admin/Factory_index.html');
	}
	
	public function save(){
		$data['start']=$_POST['start'];
		$data['end']=$_POST['end'];
		$data['oneDayNum']=$_POST['oneDayNum'];
		$data['jianjie']=$_POST['jianjie'];
		$data['shouhuostart']=$_POST['shouhuostart'];
		$data['shouhuoend']=$_POST['shouhuoend'];
		$data['iswakuang']=$_POST['iswakuang'];
		$data['bizhong']=$_POST['bizhong'];
		$m=M('Factory_config');
		$r=$m->where('id=1')->save($data);
		if ($r!==FALSE) {
			$this->success("修改成功！");
		}else {
			$this->error("修改失败");
		}
	}
	public function save_factory(){
		if (IS_POST) {
			$data=$_POST;
			$m=M('Factory');
			$r=$m->where("id={$_POST['id']}")->save($data);
			if ($r) {
				$this->success('修改成功');
			}else {
			 //   echo $m->getLastSql();
		//	    exit();
				$this->error('修改失败');
			}

		}else{
			$id=$_GET['id'];
			$m=M('Factory');
			$r=$m->where("id=$id")->find();
			$this->assign('f',$r);

    		$r=array(array('id'=>2,'name'=>'TG'),array('id'=>3,'name'=>'RMB'));
    		$this->assign('type',$r);
    		
    		
			$this->display('./Tpl/Admin/save_factory.html');
		}
	}
	public function factorylist(){
		$userid=$_GET['id'];
		$m=M('Factory_user');
		$r=$m->where("user={$userid}")->select();
		$m=M('Factory');
		foreach ($r as $k=> $v){
			$item=$m->where("id={$v['factory']}")->find();
			$r[$k]['factory']=$item['name'];
			$r[$k]['shouming']=round(($v['shouming']/60)/60,4);
		}
		$this->assign('factory',$r);
		$this->display('./Tpl/Admin/Factorylist.html');
	}
	
	public  function deletFactory(){
		$id=$_GET['id'];
		$m=M('Factory_user');
		$f=M('Factory');
		$u=M('User');
		$s=$m->where("id=$id")->find();
		$fr=$f->where("id={$s['factory']}")->find();
		$suanli=$fr['suanli']*$s['num'];
		$u->where("id={$s['user']}")->setDec('suanli',$suanli);
		$r=$m->where("id=$id")->delete();
		
		if ($r) {
		//	$data['id']=101;
			$data="删除成功";
		}else{
			$data="删除失败";
		}
		$this->success($data);
	}
	
}
?>