<?php
// 本类由系统自动生成，仅供测试用途
class FillAction extends CommonAction {
	private $Fill;

	public function __construct(){
		parent::__construct();
	    $this->Fill=D('Fill');
	}

    public function index(){
		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Fill->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        
		$rs=$this->Fill->join(array('t_user u on u.id=t_fill.uid'))->field('t_fill.*,u.username')->order('id asc')->limit(($page-1)*$per_num.','.$per_num)->select();

		$this->assign('list',$rs);
		$this->assign('module','list');
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('empty','<tr><td colspan=6>没有找到数据！</td></tr>');
		$this->display('./Tpl/Admin/Fill.html');
    }

	public function add(){
		$v = $this->Fill->find($_GET['id']);
		$this->assign('id',$_GET['id']);
		$this->assign($v);
	    $this->display('./Tpl/Admin/Fill.html');
	}

	public function insert(){
	    $num = trim($_POST['num']);
        if(!chkNum($num)) {
			$this->error('请输入数量');
            exit;
        }

        $mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_fill write,t_user write');
		$rs = array();
		
        $fill = $mo->table('t_fill')->find($_POST['id']);
		if($fill['status']==1){
		    $mo->query('rollback');
			$this->error('已经充值了！','/?s=Admin/Fill');
			exit;
		}

		$rs[] = $mo->table('t_fill')->save(array(
			'id'=>$_POST['id'],
			'status'=>1
		));

		$rs[] = $mo->table('t_user')->save(array(
			'id'=>$_POST['uid'],
			'rmb'=>array('exp','rmb+'.$num)
		));
		
		if(chkArr($rs)){
			$mo->query('commit');
		    $mo->query('unlock tables');
			$this->success('充值成功！','/?s=Admin/Fill');
		}else{
			$mo->query('rollback');
			$this->error('充值失败！');
		}
	}
}