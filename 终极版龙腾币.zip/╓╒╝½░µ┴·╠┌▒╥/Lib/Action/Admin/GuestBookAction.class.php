<?php
class GuestBookAction extends CommonAction{

	public function index(){
		$Dao=M('Guest_book');
	    $count=$Dao->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,20);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->order('id DESC')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
		$new_page=str_replace('/GuestBook','?s=Admin/GuestBook',$page);
		$this->assign('page', $new_page);//模板变量赋值
		foreach ($list as $k=>$v){
			$list[$k]['content']=mb_substr(strip_tags($v['content']),0,16,'utf-8');
			$list[$k]['huifu']=mb_substr(strip_tags($v['huifu']),0,16,'utf-8');
		}

		$this->assign('list',$list);
		$this->display('./Tpl/Admin/GuestBook.html');
	}
	
	public function huifu(){
		if (IS_POST) {
			$data[id]=$_POST['id'];
			$data[huifu]=$_POST['content'];
			$data[ishuifu]='是';
			$Dao=M('Guest_book');
			$r=$Dao->where("id={$data['id']}")->save($data);
			if($r !==false){
			//注意点：
			$this->success("回复成功");
			}else {
			$this->error("回复失败");
		}
			
		}else {
			$id=$_GET['id'];
			$Dao=M('Guest_book');
			$r=$Dao->where("id=$id")->find();
			$this->assign('r',$r);
			$this->display('./Tpl/Admin/huifu.html');
		}
	}
	public function del(){
		$id=$_GET['id'];
		$Dao=M('Guest_book');
		if (is_array($id)) {
   			$map['id']=array('in',$id);
   		}else{
   			$map['id']=$id;
   		}
		$result = $Dao->where($map)->delete();
		if($result !==false){
			//注意点：
			$this->success('删除成功');
		}else {
			$this->error('删除失败');
		}
	}
}
?>