<?php
// 本类由系统自动生成，仅供测试用途
class GudongAction extends CommonAction {
	public function jiaoyi(){
		$j=M('Jiaoyi');
		$count=$j->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,10);//实例化分页类
		$page=$p->show();//分页显示输出
		$list=$j->join("t_type on t_type.id=t_jiaoyi.typeid")->limit($p->firstRow.','.$p->listRows)->order("t_jiaoyi.id desc")->select();
		foreach ($list as $k=> $v){
		switch ($v['status']){
    			case 1:$list[$k]['status']='交易已提交'; break;
    			case 2:$list[$k]['status']='交易成功';break;
    			case 0:$list[$k]['status']='交易已关闭';break;
    		}
    		$list[$k]['time']=date('Y-m-d H:i:s',$v['time']);
    	}
    	$page=str_replace('/Admin','?s=Admin',$page);
    	$this->assign('list',$list);
    	$this->assign('page',$page);
    	$this->display("./Tpl/Admin/Gudong_jiaoyi.html");
	}
}