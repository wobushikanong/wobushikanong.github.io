<?php
// 本类由系统自动生成，仅供测试用途
class CaMiAction extends CommonAction {

	public function __construct(){
		parent::__construct();

		if($this->role !== 0){
		    $this->error('对不起，您没有权限！');
			exit;
		}

	    $this->Admin=D('Admin');
	}
	public function index(){
		$Dao=M('Cami');
	    $count=$Dao->count();//计算总页数
		import("ORG.Util.Page");// 导入分页类
		$p=new Page($count,25);//实例化分页类
		$page=$p->show();//分页显示输出
		$list = $Dao->order('id DESC')->limit($p->firstRow.','.$p->listRows)->select();// 当前页数据查询
	
		$new_page=str_replace('Admin/CaMi','?s=Admin/CaMi',$page);
	
		$this->assign('page', $new_page);//模板变量赋值
		
		$this->assign('list',$list);
		$this->display('./Tpl/Admin/CaMi_index.html');
	}
	public function add(){
		$num=intval($_POST['num']);
		$money=$_POST['money'];
		$C=M('Cami');
		for ($i=0;$i<$num;$i++){
			$data['num']=$num;
			$data['money']=$money;
			$data['status']=1;
			$data['time']=time();
			$data['code']=strtolower($this->genRandomString(13));
		$r=$C->add($data);	
		}
		if ($r) {
			$this->success('生成卡密成功');
		}else {
			$this->error('生成卡密失败');
		}
	
	}
	public function del(){
	
		$id=$_GET['id'];
		$C=M('Cami');
		$r=$C->where("id=$id")->delete();
		if ($r!==FALSE) {
			$this->success('删除成功');
		}else{
			$this->error("删除失败");
		}
	}
	
	
	
	
	
	
	private  function genRandomString($len) 
	{ 
    $chars = array( 
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",  
        "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",  
        "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",  
        "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",  
        "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",  
        "3", "4", "5", "6", "7", "8", "9" 
    ); 
    $charsLen = count($chars) - 1; 
    shuffle($chars);// 将数组打乱
    $output = ""; 
    for ($i=0; $i<$len; $i++) 
    { 
        $output .= $chars[mt_rand(0, $charsLen)]; //获得一个数组元素
    }  
    return $output;
}

}