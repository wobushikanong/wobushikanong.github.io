<?php
// 本类由系统自动生成，仅供测试用途
class AdminAction extends CommonAction {
	private $Admin;

	public function __construct(){
		parent::__construct();
	    $this->Admin=D('Admin');
	}
    public function index(){
		$value=$this->Admin->where('id=1')->find();
		$this->assign($value);
		$this->display('./Tpl/Admin/Admin.html');
    }

	public function update(){
		if(empty($_POST['id']) || empty($_POST['username']) || empty($_POST['password'])){
		   $this->error('信息不完整');
		}
		$data['id']=$_POST['id'];
		$data['username']=$_POST['username'];
		$data['password']=md5($_POST['password']);
		$data['loginip']=get_client_ip();
		$data['logintime']=date('Y-m-d H:i:s',time());
		if($this->Admin->save($data)){
		    $this->success('修改成功！');
		}else{
		    $this->error('修改失败！');
		}
    }
}