<?php
// 本类由系统自动生成，仅供测试用途
class TransAction extends CommonAction {
	private $Trans;
	private $Coin;
	private $User;

	public function __construct(){
		parent::__construct();
	    $this->Trans=D('Trans');
		$this->Market=D('Market');
		$this->User=D('User');
	}

    public function index(){

		//$where = 'main=1';
		if(chkNum($_GET['userid'])){
		    $where = '1=1 and userid='.$_GET['userid'];
			$urls = '/userid/'.$_GET['userid'];
		}
         //手续费统计
        $sum=M('Trans')->where('type=0')->sum('num*price');
        
        $this->assign('fei',$sum*$this->sys['tradefee']/100);
        $per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->Trans->where($where)->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;
        
		$rs=$this->Trans->where($where)->order('id desc')->limit(($page-1)*$per_num.','.$per_num)->select();
		foreach($rs as $k => $v){
		    $rs[$k]['user'] = $this->User->where('id='.$v['uid'])->find();
// 			$rs[$k]['market']= $this->Market->join('t_coin t on t.id=t_market.wareid')
// 											->join('t_coin t1 on t1.id=t_market.coinid')
// 											->where('t_market.id='.$v['marketid'])
// 											->field('t.sname as ware,t1.sname as coin')
// 											->find();
           $rs[$k]['total']=$v['price']*$v['num'];
		}
		$this->assign('list',$rs);
		$this->assign('module','list');
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->assign('urls',$urls);
		$this->assign('empty','<tr><td colspan=9>没有找到数据！</td></tr>');
		$this->display('./Tpl/Admin/Trans.html');
    }

	public function del(){
		if(!chkNum($_GET['id'])) $this->error('请选择要删除的项！');

	    if($this->Trans->where('id='.$_GET['id'])->delete()){
		    $this->success('删除成功！');
		}else{
		    $this->error('删除失败！');
		}
    }

	public function delAll(){
		if(!chkArr($_POST['id'])) $this->error('请选择要删除的项！');

		$ids = implode(',',$_POST['id']);

		if($this->Trans->where('id in ('.$ids.')')->delete()){
			$this->success('删除成功！');
		}else{
			$this->error('删除失败！');
		}
    }
}