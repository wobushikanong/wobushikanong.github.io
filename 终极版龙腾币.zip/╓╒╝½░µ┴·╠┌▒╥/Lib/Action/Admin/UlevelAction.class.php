<?php
// 本类由系统自动生成，仅供测试用途
class UlevelAction extends CommonAction {
	private $Ulevel;

	public function __construct(){
		parent::__construct();
	    $this->Ulevel=D('Ulevel');
	}

    public function index(){
		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
    	$count = $this->Ulevel->count();
		$page_num = ceil($count/$per_num)?ceil($count/$per_num):1;
		if($page < 1){
		    $page = 1;
		}elseif($page > $page_num){
		    $page = $page_num;
		}

		$rs = $this->Ulevel->limit((($page-1)*$per_num).','.$per_num)->select();

        foreach($rs as $k => $v){
		    $rs[$k]['ks'] = floatval($v['ks']);
		}

       	$this->assign('list',$rs);
		$this->assign('module','list');
		$this->assign('page',$page);
		$this->assign('page_num',$page_num);
		$this->display('./Tpl/Admin/Ulevel.html');
    }

	public function set(){
		if(empty($_GET['id'])){
		   $this->error('对不起，您没有权限！');
		}
		$value=$this->Ulevel->where('id='.$_GET['id'])->find();
		$value['ks'] = floatval($value['ks']);
		$this->assign($value);
		$this->display('./Tpl/Admin/Ulevel.html');
    }

	public function add(){
		$this->display('./Tpl/Admin/Ulevel.html');
    }

	public function update(){

        if(!chkStr($_POST['level']) || !chkStr($_POST['num'])){
		   $this->error('信息不完整！');
		   exit;
		}

		$data['level']=$_POST['level'];
		$data['num']=$_POST['num'];
		$data['ks']=$_POST['ks'];

		if(chkNum($_POST['id'])){
			$data['id']=$_POST['id'];

			if($this->Ulevel->save($data)){
				$this->assign('jumpUrl','?s=Admin/Ulevel');
				$this->success('修改成功！');
			}else{
				$this->error('修改失败！');
			}
		}else{
			if($this->Ulevel->add($data)){
				$this->assign('jumpUrl','?s=Admin/Ulevel');
				$this->success('添加成功！');
			}else{
				$this->error('添加失败！');
			}
		}
    }

	public function del(){
		if(!chkNum($_GET['id'])){
		   $this->error('删除失败！');
		   exit(0);
		}

	    if($this->Ulevel->where('id='.$_GET['id'])->delete()){
		    $this->success('删除成功！');
		}else{
		    $this->error('删除失败！');
		}
    }

	public function delAll(){

		if(!empty($_POST['id']) && is_array($_POST['id'])){
			$ids = implode(',',$_POST['id']);
	
			if($this->Ulevel->where('id in ('.$ids.')')->delete()){
				$this->success('删除成功！');
			}else{
				$this->error('删除失败！');
			}
		}else{
		   $this->error('删除失败！'); 
		}
    }
}