<?php
class KuangAction extends Action {
	private $Sys;
	public function __construct(){
		parent::__construct();
		$this->Sys = D('sys');
	}

    public function goafcpwfdkpo(){
        ignore_user_abort ( TRUE );
		set_time_limit ( 0 );
		$interval = 3;
		$stop = 1;
		do {
			$ss = $this->Sys->where('id=1')->field('kuangopen')->find();
			if($ss['kuangopen']==0) break;
			file_put_contents('liuhui.txt',' Current Time: '.time().' Stop: '.$stop);
			$stop++;
			sleep ( $interval );
		} while ( true );

		/*$mo = new Model();
		$mo->query('set autocommit=0');
		$mo->query('lock tables t_user write,t_draw write');
		$rs = array();

		$mo->query('commit');
		    $mo->query('unlock tables');

			$mo->query('rollback');*/
    }
}