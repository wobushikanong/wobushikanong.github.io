<?php
class DuihuanAction extends CommonAction {

   public function __construct()
    {
        parent::__construct();
    }
    public function index(){
        $User = M('Goods'); // 实例化User对象
        import('ORG.Util.Page');// 导入分页类
        $count      = $User->count();// 查询满足要求的总记录数
        $Page       = new Page($count,20);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        // 进行分页数据查询 注意limit方法的参数要使用Page类的属性
        $list = $User->order('create_time')->limit($Page->firstRow.','.$Page->listRows)->select();
        foreach ($list as $k=>$v){
            if ($v['status']==1) {
                $list[$k]['url']="<a href='?s=Admin/Duihuan/status/id/{$v['id']}/type/0'>下架</a>";
            }else {
                $list[$k]['url']="<a href='?s=Admin/Duihuan/status/id/{$v['id']}/type/1'>上架</a>";
            }
        }

        $this->assign('list',$list);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display('./Tpl/Admin/Duihuan_index.html');
    }
    public function status(){
        $data['id']=$_GET['id'];
        $data['status']=$_GET['type'];
        $r=M('Goods')->save($data);
        if($r){
            $this->success('操作成功');
        }else {
            $this->error('操作失败');
        }
    }
    public function del(){
        $id=$_GET['id'];
        $r=M('Goods')->where("id=$id")->delete();
        if ($r) {
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }
    public function add(){
        $Goods=D('Goods');
        import('ORG.Net.UploadFile');
        $upload = new UploadFile();// 实例化上传类
        $upload->maxSize  = 3145728 ;// 设置附件上传大小
        $upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->savePath =  './Public/Uploads/';// 设置附件上传目录
        if(!$upload->upload()) {// 上传错误提示错误信息
            $this->error($upload->getErrorMsg());
        }else{// 上传成功 获取上传文件信息
            $info =  $upload->getUploadFileInfo();
        }
        
        
        if ($Goods->create()) {
            $Goods->pic=$upload->savePath.$info[0]['savename'];
            $Goods->create_time=time();
            $Goods->status=1;
            $r=$Goods->add();
            if ($r) {
                $this->success('商品添加成功');
            }else {
                $this->error('商品添加失败');
            }
        }else {
            $this->error($Goods->getError());
        }
    }
    public function order(){
        $User = M('Goods'); // 实例化User对象
        import('ORG.Util.Page');// 导入分页类
        $count      = M('Order')->count();// 查询满足要求的总记录数
        $Page       = new Page($count,10);// 实例化分页类 传入总记录数和每页显示的记录数
        $show       = $Page->show();// 分页显示输出
        $list=M('Order')->field("t_order.*,t_type.name,t_user.username,t_goods.title")
        ->join("t_type on t_type.id=t_order.type")
        ->join("t_user ON t_order.userid=t_user.id")
        ->join("t_goods on t_goods.id=t_order.goodid")
        ->order("id desc")
        ->limit($Page->firstRow.','.$Page->listRows)
        ->select();
        foreach ($list as $k=>$v){
            switch ($v['status']){
                case 0:$status='已提交'; $url="<a href='/index.php/Admin/Duihuan/setstatus/type/1/id/{$v['id']}'>确认发货</a>";break;
                case 1:$status='已发货'; $url="<a href='/index.php/Admin/Duihuan/setstatus/type/2/id/{$v['id']}'>确认完成</a>";break;
                case 2:$status='已完成'; $url="<a href='/index.php/Admin/Duihuan/delt/id/{$v['id']}'>删除</a>";break;
            }
            $list[$k]['status']=$status;
            $list[$k]['url']=$url;
        }
        
        $this->assign('list',$list);
        $this->assign('page',$show);
        $this->display("./Tpl/Admin/Duihuan_order.html");
    }
    public function  setstatus(){
        $data['id']=$_GET['id'];
        $data['status']=$_GET['type'];
        $r=M('Order')->save($data);
        if ($r) {
            $this->success('操作成功');
        }else {
            $this->error('操作失败');
        }
    }
    public function delt(){
        $id=$_GET['id'];
        $r=M('Order')->where("id=$id")->delete();
        if ($r) {
            $this->success('操作成功');
        }else {
            $this->error('操作失败');
        }
    }
    public function hf(){
        if (IS_POST) {
            $data['id']=$_POST['id'];
            $data['huifu']=$_POST['huifu'];
            $r=M('Order')->save($data);
            if ($r) {
                $this->success('回复成功');
            }else {
                $this->error('回复失败');
            }
        }else{
            $this->assign('id',$_GET['id']);
            $this->display("./Tpl/Admin/Duihuan_hf.html");
        }
    }






}