<?php
class FarmAction extends CommonAction {
    private $DouSys;

    public function __construct(){
        parent::__construct();
        if($this->role !== 0){
            $this->error('对不起，您没有权限！');
            exit;
        }
    }
    public function index(){
        $this->display('./Tpl/Admin/farm.html');
    }
}