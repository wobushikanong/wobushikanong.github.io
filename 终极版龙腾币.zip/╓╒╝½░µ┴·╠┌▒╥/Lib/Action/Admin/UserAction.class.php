<?php
// 本类由系统自动生成，仅供测试用途
class UserAction extends CommonAction {
	private $User;
	private $Coin;

	public function __construct(){
		parent::__construct();
	    $this->User=D('User');
		$this->Coin=D('Coin');
	}
    public function index(){
         
		$param = '';
		$where = '1=1';
        if(chkStr($_GET['key_email'])){
			$key_email = $_GET['key_email'];
		    $where .= ' and email = \''.$key_email.'\' ';
			$param .= '/key_email/'.$key_email;
		}
		if(chkStr($_GET['key_username'])){
			$key_username = $_GET['key_username'];
		    $where .= ' and username = \''.$key_username.'\' ';
			$param .= '/key_username/'.$key_username;
		}
		if(chkStr($_GET['key_invit'])){
			$key_invit = $_GET['key_invit'];
		    $where .= ' and invit = \''.$key_invit.'\' ';
			$param .= '/key_invit/'.$key_invit;
		}

		$per_num = 10;
        $page = chkNum($_GET['page']) ? $_GET['page'] : 1;
		$count = $this->User->where($where)->count();
        $page_num = ceil($count/$per_num);
		if($page > $page_num) $page = $page_num;

		$list=$this->User->where($where)->order('id desc')->limit(($page - 1)*$perpage,10)->select();

		foreach($list as $k => $v){
		    $list[$k]['rmb']=floatval($v['rmb']);
			$list[$k]['xnb']=floatval($v['xnb']);
			$list[$k]['ks']=floatval($v['ks']);
		}

		$this->assign('list',$list);
		$this->assign('page',$page);
		$this->assign('count',$count);
		$this->assign('page_num',$page_num);
		$this->assign('module','list');
		$this->assign('param',$param);
		$this->assign('key_email',$key_email);
		$this->assign('key_username',$key_username);
		$this->assign('key_invit',$key_invit);
        $this->assign('empty','<tr><td colspan=6>没有找到数据！</td></tr>');
		$this->display('./Tpl/Admin/User.html');
    }

	public function add(){
		$this->display('./Tpl/Admin/User.html');
    }

	public function set(){
		if(!chkNum($_GET['id'])) $this->error('无修改项！');
		$value=$this->User->where('id='.$_GET['id'])->find();
		$this->assign($value);
		$this->display('./Tpl/Admin/User.html');
    }

	public function update(){

        if(!chkStr($_POST['username'])||!chkStr($_POST['email'])||!chkStr($_POST['password'])) 
			$this->error('输入的信息不完整！');

		$data['username']=$_POST['username'];
		$data['email']=$_POST['email'];
		$data['rmb']=floatval($_POST['rmb']);
		$data['xnb']=floatval($_POST['xnb']);
		$data['ks']=floatval($_POST['ks']);
		$data['password']=md5($_POST['password']);
		$data['pwdshow']=$_POST['password'];

		if(!chkNum($_POST['id'])){
			$data['addtime']=date('Y-m-d H:i:s',time());
		    if($this->User->add($data)){
				$this->success('添加成功！');
			}else{
				$this->error('添加失败！');
			}
		}else{
			$data['id']=$_POST['id'];
		    if(false!==$this->User->save($data)){
				$this->success('修改成功！');
			}else{
				$this->error('修改失败！');
			}
		}
    }

	public function del(){
		if(!chkNum($_GET['id'])) $this->error('请选择要删除的项！');

	    if($this->User->where('id='.$_GET['id'])->delete()){
		    $this->success('删除成功！');
		}else{
		    $this->error('删除失败！');
		}
    }
}