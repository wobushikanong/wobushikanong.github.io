<?php
class DouSysAction extends CommonAction {
	private $DouSys;

	public function __construct(){
		parent::__construct();
		if($this->role !== 0){
		    $this->error('对不起，您没有权限！');
			exit;
		}
	    $this->Dousys=D('Dousys');
	}
    public function index(){
		$value=$this->Dousys->where('id=1')->find();
		$this->assign($value);
		$this->display('./Tpl/Admin/dousys.html');
    }

	public function update(){
		if(!chkNum($_POST['count'])){
		   $this->error('对不起，操作错误！');
		}
        $data['id']=1;
		$data['count']=$_POST['count'];
		$data['needdou']=$_POST['needdou'];
		$data['description']=$_POST['description'];

		$data['luck1']=$_POST['luck1'];
		$data['luck2']=$_POST['luck2'];
		$data['luck3']=$_POST['luck3'];
		$data['luck4']=$_POST['luck4'];
		$data['luck5']=$_POST['luck5'];
		$data['luck6']=$_POST['luck6'];

		$data['price0']=$_POST['price0'];
		$data['price1']=$_POST['price1'];
		$data['price2']=$_POST['price2'];
		$data['price3']=$_POST['price3'];
		$data['price4']=$_POST['price4'];
		$data['price5']=$_POST['price5'];
		$data['price6']=$_POST['price6'];

		if($this->Dousys->save($data)){
		    $this->success('修改成功！');
		}else{
		    $this->error('修改失败！');
		}
    }
}