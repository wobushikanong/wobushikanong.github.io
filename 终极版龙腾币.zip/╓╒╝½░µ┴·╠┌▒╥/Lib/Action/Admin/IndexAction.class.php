<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends CommonAction {
	public function __construct(){
		parent::__construct();
		$this->assign('loginname',$_SESSION['USER_ADMIN_KEY']);
	}

    public function index(){
	    $this->display('./Tpl/Admin/Index.html');
    }

	public function top(){
	    $this->display('./Tpl/Admin/Top.html');
    }

	public function left(){
	    $this->display('./Tpl/Admin/Left.html');
    }

	public function home(){
	    $this->display('./Tpl/Admin/Home.html');
    }
}
?>