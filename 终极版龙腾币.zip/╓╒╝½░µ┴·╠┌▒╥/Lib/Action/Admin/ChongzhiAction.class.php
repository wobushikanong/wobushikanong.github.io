<?php
// 本类由系统自动生成，仅供测试用途
class ChongzhiAction extends CommonAction {
	   
    public function  index(){
        if (IS_POST) {
             $user=$_POST['name'];
             switch ($_POST['buytype']){
                 case 1:$field='xnb'; break;
                 case 2:$field='ks'; break;
                 case 3:$field='rmb'; break;
             }
             if(M('User')->where("username='$user'")->setInc($field,$_POST['money'])){
                 $this->success('充值成功');
             }else {
                 $this->error('充值失败');
             }
        }else {
            
                $r=array(array('id'=>'1','name'=>'TMC'),array('id'=>2,'name'=>'TG'),array('id'=>3,'name'=>'RMB'));
                $this->assign('username',$_GET['username']);
                $this->assign('type',$r);
                $this->display('./Tpl/Admin/cz.html');
            }
        }
}