<?php
// 本类由系统自动生成，仅供测试用途
class InviteAction extends CommonAction {
    private $InvitSys;
    private $Type;
	public function __construct(){
		parent::__construct();
		$this->assign('loginname',$_SESSION['USER_ADMIN_KEY']);

        $this->InvitSys=D('Invitsys');
        $this->Type=D('type');
	}

    public function index(){
        $arr=$this->InvitSys->select();
        $this->assign('list',$arr);
        $this->display('./Tpl/Admin/InviteIndex.html');
    }

    public function update(){
        $taskNo=isset($_GET['taskno'])?trim($_GET['taskno']):die('非法访问!');
        $arr=$this->InvitSys->where("taskno= '$taskNo'")->find();
        $arr['price']=unserialize($arr['price']);
        $arr['lastI']=empty($arr['price'])?0:count($arr['price']);
        $this->assign($arr);
        $types = $this->Type->select();
        $this->assign('types',$types);
        $this->display('./Tpl/Admin/Invite.html');
    }
    public function add(){
    	$r=D('invitsys')->where('status = 1')->field('taskno')->find();
        if($taskno=$r['taskno']){
            $this->error('第'.$taskno.'期推广奖励还未结束,不能添加新的比赛!');
        }

        $types = $this->Type->select();
        $this->assign('id',0);
        $this->assign('lastI',0);
        $this->assign('types',$types);
	    $this->display('./Tpl/Admin/Invite.html');
    }

    public function save(){
       if($_POST){
           $arr=$_POST;
           $len=(count($arr)-7);
           for($i=1;$i<=$len;$i++){
               $arrb[$i]['price']=$arr['price'.$i];
           }

           $data['starttime']=$arr['starttime'];
           $data['endtime']=$arr['endtime'];
           $data['shownum']=$arr['shownum'];
           $data['pricetype']=$arr['pricetype'];
           $data['content']=$arr['content'];
           $data['status']=$arr['status'];
           $data['price']=serialize($arrb);


           if($arr['id']){
               $data['id']=$arr['id'];
               if($this->InvitSys->save($data))
                   $this->success('保存成功!','?s=Admin/Invite');
               else
                   $this->success('保存失败!','?s=Admin/Invite');
           }else{
               $data['taskno']=date('Ymds',time());
               if($this->InvitSys->add($data))
                   $this->success('添加成功!','?s=Admin/Invite');
               else
                   $this->success('添加失败!','?s=Admin/Invite');
           }

       }
    }

    public function showprice(){
        $taskno=trim($_GET['taskno']);
        $this->assign('taskno',$taskno);
        $res=D('inviteres')->where("taskno = '$taskno'")->select();
        $this->assign('list',$res);
        $this->display('./Tpl/Admin/showInviteRes.html');
    }
    public function delPriceNo(){
        $model = new Model();
        $sql = 'TRUNCATE TABLE t_invite';
        $ret = $model->query($sql);
        $this->success('清空成功!','?s=Admin/Invite');

    }


}
?>