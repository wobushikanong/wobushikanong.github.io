<?php
class SysAction extends CommonAction {
	private $Sys;

	public function __construct(){
		parent::__construct();
	    $this->Sys=D('Sys');
	}

    public function index(){
		$value=$this->Sys->find();
		$this->assign($value);
		$this->display('./Tpl/Admin/Sys.html');
    }

	public function update(){
		if(empty($_POST['id'])){
		   $this->error('对不起，您没有权限！');
		}
		$data['id']=$_POST['id'];
		$data['title']=$_POST['title'];
		$data['key']=$_POST['key'];
        $data['des']=$_POST['des'];
		$data['copy']=$_POST['copy'];
		$data['code']=$_POST['code'];
		$data['email']=$_POST['email'];
		$data['pwd']=$_POST['pwd'];
		$data['auth']=$_POST['auth'];
		$data['invitfen']=$_POST['invitfen'];
		$data['drawfee']=$_POST['drawfee'];
		$data['tradefee']=$_POST['tradefee'];
		$data['qq']=$_POST['qq'];
		$data['qqqun']=$_POST['qqqun'];
		$data['tel']=$_POST['tel'];
		$data['addr']=$_POST['addr'];
		$data['icp']=$_POST['icp'];
		$data['alipay']=$_POST['alipay'];
		$data['alipaypwd']=$_POST['alipaypwd'];
		$data['ks']=$_POST['ks'];
		$data['ksper']=$_POST['ksper'];
		$data['companykg']=$_POST['companykg'];
		$data['companyks']=$_POST['companyks'];
		$data['companylimit']=$_POST['companylimit'];
		$data['companyinfo']=$_POST['companyinfo'];
		$data['kuangopen']=$_POST['kuangopen'];
		$data['kgname']=$_POST['kgname'];
		$data['ksname']=$_POST['ksname'];
		$data['min_price']=$_POST['min_price'];
		$data['max_price']=$_POST['max_price'];
		
		if($_FILES["logo"]["tmp_name"]){
			move_uploaded_file($_FILES["logo"]["tmp_name"],"upload/" . $_FILES["logo"]["name"]);
			$data['logo'] = "upload/" . $_FILES["logo"]["name"];
		}else{
		    $data['logo'] = $_POST['logoimg'];
		}

		if($this->Sys->save($data)!==false){
		    $this->success('修改成功！');
		}else{
		    $this->error('修改失败！');
		}
    }
}