<?php
// 本类由系统自动生成，仅供测试用途
class CommonAction extends Action {
	protected $site;
	protected $path;

	public function __construct(){

		if (!isset($_SESSION['USER_ADMIN_ID']) || empty($_SESSION['USER_ADMIN_ID'])) {
			$this->assign('jumpUrl','/?s=Admin/Login');
			$this->error('对不起,您还没有登录,请先登录！','/?s=Admin/Login');
			exit;
		}
 
        $Sys=D('Sys');
		$this->site = $Sys->find();
		$this->assign('sys',$this->site);

		$this->path = '/?s=Admin';
		$this->assign('path',$this->path);
	}

	public function error($msg,$url=''){
		header("Content-type:text/html;charset=utf-8");
	    echo '<script language="javascript">alert("'.$msg.'");</script>';
		if($url)
			echo '<script language="javascript">location.href="'.$url.'"</script>';
		else
		    echo '<script language="javascript">history.back();</script>';
		exit;
	}

	public function success($msg,$url=''){
		header("Content-type:text/html;charset=utf-8");
	    echo '<script language="javascript">alert("'.$msg.'");</script>';
		if($url)
			echo '<script language="javascript">location.href="'.$url.'"</script>';
		else
		    echo '<script language="javascript">history.back();</script>';
		exit;
	}
}