<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
  <div class="main_title"> <img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;手续费统计 <span style="margin-left:20px;">手续费总额：<?php echo ($all); ?></span></div>
  <div class="list_body">
    <table cellspacing=0 cellpadding=0 border=0>
      <tr>
        <th>账号</th>
        <th>手续费总和</th>
      </tr>
      <?php if(is_array($shouxufei)): foreach($shouxufei as $key=>$v): ?><tr>
          <td><?php echo ($v["username"]); ?></td>
          <td><?php echo ($v["num"]); ?></td>
        </tr><?php endforeach; endif; ?>
      <tr>
        <td colspan=6 class="page"> <?php echo ($page); ?> </td>
      </tr>
    </table>
  </div>
</div>
</body>
</html>