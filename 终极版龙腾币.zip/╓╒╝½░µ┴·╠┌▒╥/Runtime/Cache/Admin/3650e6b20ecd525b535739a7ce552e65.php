<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<style>
	li{ margin-bottom:20px;}
	input{ margin-left:40px; height:25px; line-height:25px;}
</style>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;矿机配置
	</div>
	<div class="list_body">
	    <form action="?s=Admin/Factory/save" method="post" id="formid">
        	<ul>
                <li>挖矿开始:<input type="text" name="start" value="<?php echo ($c["start"]); ?>" />
                挖矿结束<input type="text" name="end" value="<?php echo ($c["end"]); ?>" />按秒设置，0时为0秒24时为86400秒</li>
                <li>收货开始:<input type="text" name="shouhuostart" value="<?php echo ($c["shouhuostart"]); ?>" />
                收货结束<input type="text" name="shouhuoend" value="<?php echo ($c["shouhuoend"]); ?>" />按秒设置，0时为0秒24时为86400秒</li>
                <li>单天产量:<input type="text" name="oneDayNum" value="<?php echo ($c["oneDayNum"]); ?>" /></li>
               
             	 <li>描述:<textarea style="width:300px; height:200px; vertical-align:middle" name="jianjie" value="<?php echo ($c["jianjie"]); ?>"><?php echo ($c["jianjie"]); ?></textarea>数值为秒</li>
                <li>是否开启挖矿:
                	<?php if($c['iswakuang'] == 1): ?><input checked="checked" type="radio" name="iswakuang" value="1" />开启<input type="radio" name="iswakuang" value="0" />关闭 <?php else: ?>
                        <input type="radio" name="iswakuang" value="1" />开启<input checked="checked" type="radio" name="iswakuang" value="0" />关闭<?php endif; ?>
                        </li>
                <li>选择挖矿产出币种：<select name='bizhong'>
                	<option>选择币种</option>
                	<?php if(is_array($type)): foreach($type as $key=>$v): if($v["id"] == $c['bizhong']): ?><option selected="selected" value="<?php echo ($v['id']); ?>"><?php echo ($v['name']); ?></option>
                            <?php else: ?><option value="<?php echo ($v['id']); ?>"><?php echo ($v['name']); ?></option><?php endif; endforeach; endif; ?>
                </select>
                
                </li>   
                <li><input type="submit" value="修改" width="200" /></li>
            </ul>
		</form>
	</div>
    <style>
    	td{ border:1px solid #A0A0A4; text-align:center}
    </style>
    <table cellspacing=0 cellpadding=0 border=0 style="width:100%">
		    <tr>
			   <th width="5%">ID</th><th width="20%">种类</th><th width="10%">购买币种</th><th width="10%">赠送币种</th><th width="10%">算力</th><th>价格</th><th width="10%">数量</th><th width="20%">购买限制数量</th><th width="10%">操作</th>
			</tr>
			<?php if(is_array($f)): $i = 0; $__LIST__ = $f;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                	<td><?php echo ($v["id"]); ?></td>
                    <td><?php echo ($v["name"]); ?></td>
                    <td><?php echo ($v["buytype"]); ?></td>
                     <td><?php echo ($v["zengsong"]); ?></td>
                    <td><?php echo ($v["suanli"]); ?></td>
                    <td><?php echo ($v["price"]); ?></td>
                    <td><?php echo ($v["num"]); ?></td>
                    <td><?php echo ($v["limitnum"]); ?></td>
                    <td><a href="?s=Admin/Factory/save_factory/id/<?php echo ($v["id"]); ?>">修改</a></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
		</table>
</div>
</body>
</html>