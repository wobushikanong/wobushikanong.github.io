<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
	    <div class="search" style="width:800px;">
			<span>账号：</span><input type="text" name="key_username" id="key_username" value="<?php echo ($key_username); ?>"/>
			<span>邮箱：</span><input type="text" name="key_email" id="key_email" value="<?php echo ($key_email); ?>"/>
			<span>推广链接：</span><input type="text" name="key_invit" id="key_invit" value="<?php echo ($key_invit); ?>"/>
			<input type="button" id="s_btn" value=" 搜 索 "/>
			<script language="javascript">
			    $('#s_btn').click(function(){
					 window.location.href='<?php echo ($path); ?>/User/index/key_email/'+$('#key_email').val()+'/key_username/'+$('#key_username').val()+'/key_invit/'+$('#key_invit').val();
				});
			</script>
		</div>
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;认购记录
	</div>

	<div class="list_body">
		<table cellspacing=0 cellpadding=0 border=0>
		    <tr>
			   <th width="15%">时间</th><th width="15%">用户ID</th><th width="15%">用户名</th><th width="15%">数量</th>
			</tr>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
			   <td><?php echo (date('Y-m-d H:i:s',$vo["ctime"])); ?></td><td><?php echo (($vo["uid"])?($vo["uid"]):'无'); ?></td><td><?php echo (($vo["uinfo"]["username"])?($vo["uinfo"]["username"]):'无'); ?></td><td><?php echo (($vo["num"])?($vo["num"]):'0'); ?></td>
			</tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
			<tr>
			    <td colspan=7 class="page">
					<a href="<?php echo ($path); ?>/Ks/index/page/1<?php echo ($urls); ?>">首页</a>
					<a href="<?php echo ($path); ?>/Ks/index/page/<?php echo ($page-1); echo ($urls); ?>">上一页</a>
					<a href="<?php echo ($path); ?>/Ks/index/page/<?php echo ($page+1); echo ($urls); ?>">下一页</a>
					<a href="<?php echo ($path); ?>/Ks/index/page/<?php echo ($page_num); echo ($urls); ?>">尾页</a>
                </td>
			</tr>
		</table>
	</div>
</div>
</body>
</html>