<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;网站设置
	</div>
	<div class="main_body">
		<form action="?s=Admin/Sys/update" method="post" enctype="multipart/form-data">
		<input type="hidden" name="id" value="<?php echo ($id); ?>"/>
		<input type="hidden" name="logoimg" value="<?php echo ($logo); ?>"/>
		<table cellspacing=0 cellpadding=0 border=0>
		<tr><td colspan=2><img src="<?php echo ($logo); ?>" width="300" height="100" border="1" onerror="javascript:this.src='/Public/Admin/images/noimg.jpg'"/></td></tr>
		<tr><td>网站LOGO</td><td><input type="file" name="logo"/><br/></td></tr>
		<tr><td>网站标题</td><td><input type="text" name="title" value="<?php echo ($title); ?>"/></td></tr>
		<tr><td>网站关键字</td><td><input type="text" name="key" value="<?php echo ($key); ?>"/></td></tr>
		<tr><td>网站描述</td><td><textarea name="des" cols=50 rows=5 class="not_edit"><?php echo ($des); ?></textarea></td></tr>
		<tr><td>版权信息</td><td><textarea name="copy" cols=50 rows=5><?php echo ($copy); ?></textarea></td></tr>
		<tr><td>统计代码</td><td><textarea name="code" cols=50 rows=5><?php echo ($code); ?></textarea></td></tr>
		<tr><td>备案信息</td><td><textarea name="icp" cols=50 rows=5><?php echo ($icp); ?></textarea></td></tr>
		<tr><td>地址</td><td><textarea name="addr" cols=50 rows=5><?php echo ($addr); ?></textarea></td></tr>
		<tr><td>电话</td><td><input type="text" name="tel" value="<?php echo ($tel); ?>"/></td></tr>
		<tr><td>QQ</td><td><input type="text" name="qq" value="<?php echo ($qq); ?>"/></td></tr>
		<tr><td>QQ群</td><td><textarea name="qqqun" cols=50 rows=5><?php echo ($qqqun); ?></textarea> 每一行为一个群，格式：群名|号码|是否满员</td></tr>
        <tr><td>邮箱地址</td><td><input type="text" name="email" value="<?php echo ($email); ?>"/></td></tr>
		<tr><td>邮箱密码</td><td><input type="text" name="pwd" value="<?php echo ($pwd); ?>"/></td></tr>
		<tr><td>发件人</td><td><input type="text" name="auth" value="<?php echo ($auth); ?>"/></td></tr>
        <tr><td>推广赠送矿石</td><td><input type="text" name="invitfen" value="<?php echo ($invitfen); ?>"/></td></tr>
		<tr><td>提现手续费</td><td><input type="text" name="drawfee" value="<?php echo ($drawfee); ?>"/> %</td></tr>
		<tr><td>交易手续费</td><td><input type="text" name="tradefee" value="<?php echo ($tradefee); ?>"/> %</td></tr>
		<tr><td>支付宝帐号</td><td><input type="text" name="alipay" value="<?php echo ($alipay); ?>"/></td></tr>
		<tr><td>支付宝密码</td><td><input type="text" name="alipaypwd" value="<?php echo ($alipaypwd); ?>"/></td></tr>
		<tr><td>开始交易</td><td><input type="radio" name="ks" value="0" <?php if(($ks) == "0"): ?>checked<?php endif; ?>/> 否 <input type="radio" name="ks" value="1" <?php if(($ks) == "1"): ?>checked<?php endif; ?>/> 是</td></tr>
		<tr><td>开始认购</td><td><input type="radio" name="kuangopen" value="0" <?php if(($kuangopen) == "0"): ?>checked<?php endif; ?>/> 否 <input type="radio" name="kuangopen" value="1" <?php if(($kuangopen) == "1"): ?>checked<?php endif; ?>/> 是</td></tr>
		<tr><td>每日单个矿工认购数</td><td><input type="text" name="ksper" value="<?php echo ($ksper); ?>"/></td></tr>
		<tr><td>组成公司矿工数</td><td><input type="text" name="companykg" value="<?php echo ($companykg); ?>"/></td></tr>
		<tr><td>公司获得矿石数</td><td><input type="text" name="companyks" value="<?php echo ($companyks); ?>"/></td></tr>
		<tr><td>组成公司最大数</td><td><input type="text" name="companylimit" value="<?php echo ($companylimit); ?>"/></td></tr>
		<tr><td>组建公司介绍</td><td><textarea name="companyinfo" cols=50 rows=5 class="not_edit"><?php echo ($companyinfo); ?></textarea></td></tr>
		<tr><td>矿工名称</td><td><input type="text" name="kgname" value="<?php echo ($kgname); ?>"/></td></tr>
		<tr><td>矿石名称</td><td><input type="text" name="ksname" value="<?php echo ($ksname); ?>"/></td></tr>
        <tr><td>交易最低价</td><td><input type="text" name="min_price" value="<?php echo ($min_price); ?>"/></td></tr>
        <tr><td>交易最高价</td><td><input type="text" name="max_price" value="<?php echo ($max_price); ?>"/></td></tr>
		</table>
		<div><input type="submit" value="提交"/></div>
		</form>
	</div>
</div>
</body>
</html>