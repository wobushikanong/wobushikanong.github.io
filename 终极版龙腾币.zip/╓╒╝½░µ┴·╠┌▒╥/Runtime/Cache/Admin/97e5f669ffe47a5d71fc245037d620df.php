<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<style type="text/css">
.box1{width:100%;height:35px;line-height:35px;background:#71A302;color:#fff;text-align:left;}
.box2{width:100%;height:25px;line-height:25px;background:#333;color:#fff;text-align:left;}
.box2 a{color:#fff;}
.box21,.box22{margin-left:20px;color:#fff;}
.logo{font-size:20px;font-weight:bold;color:#fff;margin-left:20px;}
</style>
</head>
<body>
<div class="box1"><span class="logo">网站管理系统</span></div>
<div class="box2">
<span class="box21">当前登陆者：<?php echo ($loginname); ?></span>
<span class="box22"><a href="?s=Admin/Login/loginout">退出系统</a></span>
</div>
</body>
</html>