<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/index.css" />
</head>
<frameset rows="60,*" frameborder="NO" border="0" framespacing="0" cols="*">
  <frame name="head" scrolling="NO" noresize src="index.php?s=Admin/Index/top" >
  <frameset cols="230,*" frameborder="NO" border="0" framespacing="0" rows="*">
    <frame name="toc" scrolling="yes" noresize src="index.php?s=Admin/Index/left">
    <frame name="content" src="index.php?s=Admin/Index/welcome" title="mainFrame">
  </frameset>
</frameset>
<noframes>
<body >
不支持框架!
</body>
</noframes>
</html>