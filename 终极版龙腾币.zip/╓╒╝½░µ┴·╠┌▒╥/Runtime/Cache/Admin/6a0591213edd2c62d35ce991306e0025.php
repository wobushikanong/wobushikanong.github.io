<?php if (!defined('THINK_PATH')) exit();?><link rel="stylesheet" type="text/css" href="/Public/home/css/all.css" />

<!--交易页面的子导航区-->
<div class="marketArea clear">
    <div class="rightArea">
<!--全站交易记录-->
<div class="trade-part trade-part-hd mt20">
	<div class="trade-hd">
		<h5><i class="icon_condition"></i>财务明细</h5>
	</div>
	<div class="md" style="margin-bottom:10px;">
		<div class="my-grid" id="order-grid">
			<table class="items table table-striped table-bordered table-condensed detail_tb">
				<tbody>
				    <tr>
					<td class="tb_tit">币种：</td>
                    <?php if(is_array($type)): foreach($type as $key=>$v): ?><td class="tb_tit"><?php echo ($v["name"]); ?>(<?php echo ($v["nickname"]); ?>)</td><?php endforeach; endif; ?>
					</tr>
					<tr>
					<td class="tb_tit">总数量：</td>
                        <?php if(is_array($all)): foreach($all as $key=>$v): ?><td><?php echo ($v); ?></td><?php endforeach; endif; ?>
					</tr>
                    <tr>
					<td class="tb_tit">账户总数量：</td>
                            <?php if(is_array($goldnum)): foreach($goldnum as $key=>$v): ?><td><?php echo ($v); ?></td><?php endforeach; endif; ?>
					</tr>
                    <tr>
					<td class="tb_tit">冻结总数量：</td>
                            <?php if(is_array($gdgold)): foreach($gdgold as $key=>$v): ?><td><?php echo ($v); ?></td><?php endforeach; endif; ?>
					</tr>
					<!--tr>
					<td class="tb_tit">时间：</td><td><input type="text" name="start_time" readonly> — <input type="text" name="end_time" readonly><input type="submit" class="btn" value="确定"></td>
					</tr-->
				</tbody>
			</table>
		</div>
	</div>
	
</div>
</div>
</div>
<!--尾部-->
<!-- footer -->

<div class="modal hide fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>


</body></html>