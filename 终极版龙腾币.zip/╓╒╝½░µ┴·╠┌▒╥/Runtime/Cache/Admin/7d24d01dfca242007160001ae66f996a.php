<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;欢迎登陆本系统
	</div>
    <div class="list_body">
		<table cellspacing=0 cellpadding=0 border=0>
		<tr>
		<th colspan="2">系统信息</th>
		</tr>
		<tr><td>核心版本</td><td style="text-align: left">V2.1.0</td></tr>
		<tr><td>PHP版本</td><td style="text-align: left"><?php echo ($sysv); ?></td></tr>
        <tr><td>Mysql版本</td><td style="text-align: left"><?php echo ($sysmysqlv); ?></td></tr>
        <tr><td>Apache版本</td><td style="text-align: left"><?php echo ($sysapachev); ?></td></tr>
		<tr><td>操作系统</td><td style="text-align: left"><?php echo ($systype); ?></td></tr>
		<tr><td>服务器IP</td><td style="text-align: left"><?php echo ($sysip); ?></td></tr>
		<tr><td>域名</td><td style="text-align: left"><?php echo ($sysname); ?></td></tr>
<tr><td>用户RMB统计</td><td style="text-align: left;color:#F60">正常RMB:<?php echo ($rmb); ?>+冻结RMB：<?php echo ($drmb); ?>=RMB合计：<?php echo ($rmb+$drmb); ?></td></tr>
<tr><td>用户虚拟币统计</td><td style="text-align: left;color:#F60">正常虚拟币:<?php echo ($xnb); ?>+冻结虚拟币：<?php echo ($dxnb); ?>=虚拟币合计：<?php echo ($xnb+$dxnb); ?></td></tr>
<tr><td>推广奖励统计</td><td style="text-align: left;color:#F60"><?php echo ($jiangli); ?></td></tr>
<tr><td>充值统计</td><td style="text-align: left;color:#F60"><?php echo ($chongzhi); ?></td></tr>
<tr><td>提现统计</td><td style="text-align: left; color:#F60"><?php echo ($tixian); ?></td></tr>
<tr><td>提现手续费统计</td><td style="text-align: left;color:#F60"><?php echo ($shouxufei); ?></td></tr>
<tr><td>交易手续费统计</td><td style="text-align: left;color:#F60"><?php echo ($shouxu); ?></td></tr>
<tr><td>矿机总数量</td><td style="text-align: left;color:#F60"><?php echo ($f); ?></td></tr>
<tr><td>矿机总算力</td><td style="text-align: left;color:#F60"><?php echo ($suanli); ?></td></tr>
		</table>
	</div>
</div>

</body>
</html>