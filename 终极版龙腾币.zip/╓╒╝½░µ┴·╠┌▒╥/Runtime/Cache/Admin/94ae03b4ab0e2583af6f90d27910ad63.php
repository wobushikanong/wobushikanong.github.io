<?php if (!defined('THINK_PATH')) exit();?>
<div class="main">
	<div class="main_title">
		足金豆设置
	</div>
	<div class="main_body">
		<form action="?s=Admin/DouSys/update" method="post">
		<table cellspacing=0 cellpadding=0 border=0>
            <tr><td>转盘描叙</td><td>
                <textarea name="description" cols=100 rows=20><?php echo ($description); ?></textarea></td></tr>

            <tr><td>每天抽奖次数</td><td><input type="number" name="count" value="<?php echo ($count); ?>"/></td><td>限制每天抽奖的次数</td></tr>
		<tr><td>每次抽奖手续费</td><td><input type="number" name="needdou" value="<?php echo ($needdou); ?>"/></td></tr>

        <tr style="height: 30px;"></tr>

		<tr><td>一等奖概率</td><td><input type="text" name="luck1" value="<?php echo ($luck1); ?>"/></td></tr>
		<tr><td>二等奖概率</td><td><input type="text" name="luck2" value="<?php echo ($luck2); ?>"/></td></tr>
		<tr><td>三等奖概率</td><td><input type="text" name="luck3" value="<?php echo ($luck3); ?>"/></td></tr>
		<tr><td>四等奖概率</td><td><input type="text" name="luck4" value="<?php echo ($luck4); ?>"/></td></tr>
		<tr><td>五等奖概率</td><td><input type="text" name="luck5" value="<?php echo ($luck5); ?>"/></td></tr>
		<tr><td>六等奖概率</td><td><input type="text" name="luck6" value="<?php echo ($luck6); ?>"/></td></tr>

        <tr style="height: 30px;">
            <td colspan="5" style="color: palevioletred">
                这里设置获奖概率
                <br>假设一等奖概率0.01&nbsp;二等奖概率0.03&nbsp;三等奖概率0.07&nbsp;四等奖概率0.15&nbsp;五等奖概率0.20&nbsp;六等概率0.54
                <br>那么随机产生一个0.00--1.00之间的数
                <br>落在0.00-0.01为一等奖
                <br>落在0.01-0.03为二等奖
                <br>落在0.03-0.07为三等奖
                <br>落在0.07-0.15为四等奖
                <br>落在0.15-0.20为五等奖
                <br>落在0.20-0.54为六等奖
                <br>落在0.54-1.00为七等奖
                <br>因此，总共七个奖项
            </td>
        </tr>

		<tr><td>一等奖</td><td><input type="text" name="price0" value="<?php echo ($price0); ?>"/></td></tr>
		<tr><td>二等奖</td><td><input type="text" name="price1" value="<?php echo ($price1); ?>"/></td></tr>
		<tr><td>三等奖</td><td><input type="text" name="price2" value="<?php echo ($price2); ?>"/></td></tr>
		<tr><td>四等奖</td><td><input type="text" name="price3" value="<?php echo ($price3); ?>"/></td></tr>
		<tr><td>五等奖</td><td><input type="text" name="price4" value="<?php echo ($price4); ?>"/></td></tr>
		<tr><td>六等奖</td><td><input type="text" name="price5" value="<?php echo ($price5); ?>"/></td></tr>
		<tr><td>七等奖</td><td><input type="text" name="price6" value="<?php echo ($price6); ?>"/></td></tr>

        <tr style="height: 30px;">
            <td colspan="5" style="color: palevioletred">
                这里设置奖金比例，这个比例很大程度决定奖池的期望值，每次抽奖，将获得奖池百分比的奖金
                <br>比如现在奖池1000个豆
                <br>一等奖       奖金比例 0.4（40%）
                <br>那么某人中一等奖将获得 10000*0.4=4000个豆，当然这个概率很低很低
                <br>      其他的依次类推
                <br>说明：如果不随意改变     汇率，总豆数其实是不会变化的，奖池的豆都是来自用户输的，
                <br>当奖池豆很少的时候，输的概率很大，当奖池豆很多的时候，赢得概率很大
                <br>所以奖池豆数会动态平衡在某个点。不用担心系统会亏钱，因为没有空手造豆，所有的豆豆是来自用户兑换出来的。
                <br>所以如果汇率不改变的话，豆还原成币，总币数是不会改变的
        </tr>

		</table>
		<div><input type="submit" value="提交"/></div>
		</form>
	</div>
</div>
</body>
</html>
<script language="javascript" src="/Public/plugin/kindeditor/jquery.tools.min.js"></script>
<script language="javascript" src="/Public/plugin/kindeditor/kindeditor-min.js"></script>
<script language="javascript" src="/Public/plugin/kindeditor/zh_CN.js"></script>
<script language=javascript>
    var editor;
    KindEditor.ready(function(K) {
        editor = K.create('textarea[name="description"]', {
            resizeArt : 1,
            allowPreviewEmoticons : false,
            allowImageUpload : true,
            items : [
                'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline',
                'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist',
                'insertunorderedlist', '|', 'image', 'link']
        });
    });
</script>