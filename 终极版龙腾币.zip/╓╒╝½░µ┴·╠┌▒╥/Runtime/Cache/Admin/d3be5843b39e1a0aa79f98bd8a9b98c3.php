<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
<style type="text/css">
body{background:#f8f8f8;}
.box{width:178px;padding:5px;border:1px solid #A9AE9A;text-align:center;margin-left:10px;background:#fff;}
.topclass{display:block;width:176px;height:25px;line-height:25px;font-weight:bold;cursor:pointer;border:1px solid #CFCFCF;margin:5px auto;}
.topclass a{display:block;width:100%;height:100%;color:#4D6C2F;}
.topclass a:hover{text-decoration:none;background:#ddd;}
</style>
</head>
<body >
<div class="box">
    <?php if(is_array($menu)): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><span class="topclass"><a href="<?php echo ($vo["url"]); ?>" target="content"><?php echo ($vo["name"]); ?></a></span><?php endforeach; endif; else: echo "" ;endif; ?>
    <span class="topclass"><a href="?s=Admin/Duihuan/index" target="content">商品管理</a></span>
     <span class="topclass"><a href="?s=Admin/Duihuan/order" target="content">订单中心</a></span>
<span class="topclass"><a href="?s=Admin/Fenhong/index" target="content">分红管理</a></span>
<span class="topclass"><a href="?s=Admin/Fenhong/log" target="content">分红日志</a></span>
	     <span class="topclass"><a href="?s=Admin/Factory/index" target="content">矿机管理</a></span>
 <span class="topclass"><a href="?s=Admin/Gudong/jiaoyi" target="content">线下交易日志</a></span>
	 <span class="topclass"><a href="?s=Admin/GuestBook/index" target="content">留言管理</a></span>
     <span class="topclass"><a href="?s=Admin/User/tongji" target="content">统计数据</a></span>
</div>
</body>
</html>