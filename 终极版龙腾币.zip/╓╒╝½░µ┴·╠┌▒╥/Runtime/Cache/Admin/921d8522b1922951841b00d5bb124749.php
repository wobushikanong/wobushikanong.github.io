<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;分红管理</eq>
	</div>
	<div class="main_body">
		<form action="?s=Admin/Fenhong/add" method="post">
		<input type="hidden" name="id" value="<?php echo ($id); ?>"/>
		<table cellspacing=0 cellpadding=0 border=0>
		<tr><td>每币分红值</td>
        <td>
            <input type="text" name="money" onchange="getAllNum()"/>
        </td></tr>
        <tr><td>分红币种</td><td>
        	<select name="bizhong" onchange="getAllNum()">
            	<option value="0">请选择分红币种</option>
                <?php if(is_array($type)): foreach($type as $key=>$v): ?><option value="<?php echo ($v["id"]); ?>"><?php echo ($v["name"]); ?></option><?php endforeach; endif; ?>
            </select>
        </td></tr>
		<tr><td>分红依据</td><td>
        	<select name="type" onchange="getAllNum()">
            	<option value="0">请选择分红方式</option>
                <option value="4">矿机</option>
                <?php if(is_array($type)): foreach($type as $key=>$v): ?><option value="<?php echo ($v["id"]); ?>"><?php echo ($v["name"]); ?></option><?php endforeach; endif; ?>
            </select>
        </td></tr>
        <tr><td>分红会员数量</td><td><input type="text" name="num"  onchange="getAllNum()"/></td><td>前&nbsp;<i id="num">0</i>&nbsp;名持<i id='type' style="color:#7F1F00"></i>总数量&nbsp;<i id='allnum' style="color:#D41F55; font-size:14px; font-weight:600;">0</i>&nbsp;个。 合计分红总数量<span id="fenhong" style="color:#00F; font-size:14px; font-weight:600;">0</span>个</td></tr>
        <script>
        	function getAllNum(){
				var num=$("input[name=num]").val();
				var type=$("select[name=type]").val();
				var bi=$("select option:selected").text();
				$("#num").html(num);
				$("#type").html(bi);
				if($("input[name=num]").val()!=''&&$("input[name=money]").val()!=''){
					$.post("?s=Admin/Fenhong/getAllNum",{'num':num,'type':type},function(data){
						$("#allnum").html(data.num);
						var fenhong=data.num*$("input[name=money]").val();
						$("#fenhong").html(fenhong);
						$(".list").empty();
						for(var i=0;i<data.list.length;i++){
							
							$(".list").append("<tr><td>"+data.list[i]['userid']+"</td><td>"+data.list[i]['username']+"</td><td>"+data.list[i]['goldnum']+"</td></tr>")
						}
					})
				}else{
					$("#num").html(0);
					$("#allnum").html(0);
					$("#type").html('');
					$("#fenhong").html(0);
				}
			}
        </script>
		</table>
		<div><input type="submit" value="提交" onclick="sumMax()"/></div>
		</form>
	</div>
     <div class="list_body">
			<table cellspacing=0 cellpadding=0 border=0>
				<thead>
                    <tr>
                    <th colspan="3">持币数量排行</th>
                    </tr>
                    <tr>
                       <th width="25%">会员ID</th><th>会员账户</th><th width="30%"> 持有数量</th>
                    </tr>
                </thead>
                <tbody class="list">
                    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                       <td><?php echo (($vo["id"])?($vo["id"]):'无'); ?></td> <td><?php echo (($vo["username"])?($vo["username"]):'无'); ?></td><td><?php echo (($vo["goldnum"])?($vo["goldnum"]):'无'); ?></td>
                    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                    <tr><td colspan=4><?php echo ($page); ?></td></tr>
                </tbody>
			</table>
		</div>
</div>
</body>
</html>