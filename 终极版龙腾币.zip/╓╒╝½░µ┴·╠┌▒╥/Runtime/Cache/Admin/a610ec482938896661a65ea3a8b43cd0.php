<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
	    <div class="search" style="width:800px;">
			<span>账号：</span><input type="text" name="key_username" id="key_username" value="<?php echo ($key_username); ?>"/>
			<span>邮箱：</span><input type="text" name="key_email" id="key_email" value="<?php echo ($key_email); ?>"/>
			<span>推广链接：</span><input type="text" name="key_invit" id="key_invit" value="<?php echo ($key_invit); ?>"/>
			<input type="button" id="s_btn" value=" 搜 索 "/>
			<script language="javascript">
			    $('#s_btn').click(function(){
					 window.location.href='<?php echo ($path); ?>/User/index/key_email/'+$('#key_email').val()+'/key_username/'+$('#key_username').val()+'/key_invit/'+$('#key_invit').val();
				});
			</script>
		</div>
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;会员管理
	</div>
	<?php if(($module) == "list"): ?><if condition="$module eq 'list'">
	<div class="list_body">
		<table cellspacing=0 cellpadding=0 border=0>
			<tr>
			<th width="30">选择</th>
			<th>推广链接</th>
			<th>帐号</th>
			<th>密码</th>
			<th>姓名</th>
            <th>手机号</th>
			<th>邮箱</th>
			<th>人民币</th>
			<th>BPC</th>
			<th>BPG</th>
			<th width="70">注册时间</th>
			<th width="190">操作</th>
			</tr>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
			<td><input type="checkbox" class="id" name="id[]" value="<?php echo ($vo["id"]); ?>"></td>
			<td><?php echo ($vo["invit"]); ?></td>
			<td><?php echo (($vo["username"])?($vo["username"]):'无'); ?></td>
			<td><?php echo (($vo["pwdshow"])?($vo["pwdshow"]):'无'); ?></td>
			<td><?php echo (($vo["xm"])?($vo["xm"]):'无'); ?></td>
			<td><?php echo (($vo["phone"])?($vo["phone"]):'无'); ?></td>
			<td><?php echo (($vo["email"])?($vo["email"]):'无'); ?></td>
			<td><?php echo (($vo["rmb"])?($vo["rmb"]):'0'); ?></td>
			<td><?php echo (($vo["xnb"])?($vo["xnb"]):'0'); ?></td>
			<td><?php echo (($vo["ks"])?($vo["ks"]):'0'); ?></td>
			<td><?php echo (date('Y-m-d H:i:s',$vo["ctime"])); ?></td>
			<td nowrap="nowrap">
			  <div align="center"><a href="<?php echo ($path); ?>/Fill/index/userid/<?php echo (($vo["id"])?($vo["id"]):'0'); ?>">充值记录</a>;
			    <a href="<?php echo ($path); ?>/Trans/index/userid/<?php echo (($vo["id"])?($vo["id"]):'0'); ?>">交易记录</a>;
                <a href="<?php echo ($path); ?>/Chongzhi/index/username/<?php echo (($vo["username"])?($vo["username"]):'0'); ?>">充值</a>;
			    <a href="<?php echo ($path); ?>/User/set/id/<?php echo ($vo["id"]); ?>">修改</a>;
		      <a href="<?php echo ($path); ?>/User/del/id/<?php echo ($vo["id"]); ?>">删除</a></div></td>
			</tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
			<tr>
			    <td colspan=14 class="page">
				    <input type="button" id="all" value=" 全选 ">
					<input type="button" id="all_return" value=" 全不选 ">
					<input type="button" id="dels" value=" 批量删除 ">
					<input type="button" id="add" value=" 添加交易类型 ">
					<a href="<?php echo ($path); ?>/User/index/page/1">首页</a>
					<a href="<?php echo ($path); ?>/User/index/page/<?php echo ($page-1); ?>">上一页</a>
					<a href="<?php echo ($path); ?>/User/index/page/<?php echo ($page+1); ?>">下一页</a>
					<a href="<?php echo ($path); ?>/User/index/page/<?php echo ($page_num); ?>">尾页</a>
                </td>
			</tr>
		</table>
	</div>
	<?php elseif($module == 'fill'): ?>
	<div class="main_body">
		<form action="<?php echo ($path); ?>/Fill/insert" method="post">
		<input type="hidden" name="uid" value="<?php echo (($id)?($id):'0'); ?>"/>
		<table cellspacing=0 cellpadding=0 border=0>
		<tr><td>账号</td><td><?php echo ($username); ?></td></tr>
		<tr><td>数量</td><td><input type="text" name="num"/></td></tr>
		</table>
		<div><input type="submit" value="提交"/></div>
		</form>
	</div>
	<?php else: ?>
	<div class="main_body">
		<form action="<?php echo ($path); ?>/User/update" method="post">
		<input type="hidden" name="id" value="<?php echo (($id)?($id):'0'); ?>"/>
		<table cellspacing=0 cellpadding=0 border=0>
		<tr><td>账号</td><td><input type="text" name="username" value="<?php echo ($username); ?>"/></td></tr>
		<tr><td>邮箱</td><td><input type="text" name="email" value="<?php echo ($email); ?>"/></td></tr>
		<tr><td>人民币</td><td><input type="text" name="rmb" value="<?php echo ($rmb); ?>"/></td></tr>
		<tr>
		  <td>BPC</td><td><input type="text" name="xnb" value="<?php echo ($xnb); ?>"/></td></tr>
		<tr><td>BPG</td><td><input type="text" name="ks" value="<?php echo ($ks); ?>"/></td></tr>
		<tr><td>密码</td><td><input type="password" name="password" value="<?php echo ($pwdshow); ?>"/></td></tr>
		</table>
		<div><input type="submit" value="提交"/></div>
		</form>
	</div><?php endif; ?>
</div>
</body>
</html>
<script language="javascript">
$(document).ready(function(){
    $('#all').click(function(){
	    $('.id').attr('checked',true);
	});
	$('#all_return').click(function(){
	    $('.id').attr('checked',false);
	});
    $('#dels').click(function(){

		f = 0;
	    $('.id').each(function(){
		    if($(this).attr('checked')) f = 1;
		});
		
        if(f==0){
		    alert('请选择要删除的项！');
		}else{
		    $('#formid').submit();
		}
	});
	$('#add').click(function(){
	    location.href="<?php echo ($path); ?>/Market/add";
	});
});
</script>