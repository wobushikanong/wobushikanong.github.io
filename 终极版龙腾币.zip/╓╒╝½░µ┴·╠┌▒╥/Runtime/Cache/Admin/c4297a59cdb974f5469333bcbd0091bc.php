<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
<style type="text/css">
body{background:#f8f8f8;}
.box{width:188px;padding:0px;border:2px solid #ccc;text-align:center;margin-left:10px;background:#fff;}
.topclass{display:block;width:100%;height:35px;line-height:35px;font-weight:bold;cursor:pointer;border-bottom:1px solid #CFCFCF;margin:0px;padding:0px;}
.topclass a{display:block;width:100%;height:100%;color:#4D6C2F;}
.topclass a:hover{text-decoration:none;background:#eee;}
.toptit{background:#4C99FE;}
</style>
</head>
<body >
<div class="box">
	<span class="topclass"><a href="<?php echo ($path); ?>/User" target="content">会员管理</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Fill" target="content">充值记录</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Draw" target="content">提现记录</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Trans" target="content">交易记录</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Sys" target="content">网站设置</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Email" target="content">邮件管理</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Art" target="content">文章管理</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Ad" target="content">图片管理</a></span>
    <span class="topclass"><a href="<?php echo ($path); ?>/Factory" target="content">矿机管理</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Issue" target="content">认购管理</a></span>
	<span class="topclass"><a href="<?php echo ($path); ?>/Ks" target="content">认购记录</a></span>
    <span class="topclass"><a href="<?php echo ($path); ?>/Chongzhi" target="content">账户充值</a></span>
</div>
</body>
</html>