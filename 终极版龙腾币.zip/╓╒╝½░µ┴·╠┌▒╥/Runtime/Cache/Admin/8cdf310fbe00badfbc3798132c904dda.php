<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<style type="text/css">
.box1{width:100%;height:32px;line-height:32px;background:#2E8108;color:#fff;text-align:left;}
.box2{width:100%;height:25px;line-height:25px;background:#3AA20A;border-top:1px solid #bbb;border-bottom:2px solid #333;color:#fff;text-align:left;}
.box2 a{color:#fff;}
.box21{margin-left:20px;color:#fff;float:left;}
.box22{margin-left:150px;float:right;}
.logo{font-size:20px;font-weight:bold;color:#fff;margin-left:20px;}
a.linkbtn{height:23px;line-height:23px;text-align:center;display:inline-block;width:90px;border:1px solid #333;color:#333;background:#fff;margin-right:5px;float:left;}
a.linkbtn:hover{text-decoration:none;background:#ddd;}
</style>
</head>
<body>
<div class="box1"><span class="logo">网站管理系统</span></div>
<div class="box2">
	<span class="box21">当前登陆者：<?php echo ($loginname); ?></span>
	<span class="box21"><a href="<?php echo ($path); ?>/Login/loginout">退出系统</a></span><span class="box21">
	<a href="<?php echo ($path); ?>/Admin" target="content">修改帐号</a></span>
	<span class="box22">
	<a href="<?php echo ($path); ?>/User" target="content" class="linkbtn">会员管理</a>
	<a href="<?php echo ($path); ?>/Fill" target="content" class="linkbtn">充值记录</a>
	<a href="<?php echo ($path); ?>/Draw" target="content" class="linkbtn">提现记录</a>
	<a href="<?php echo ($path); ?>/Trans" target="content" class="linkbtn">交易记录</a>
	<a href="<?php echo ($path); ?>/Sys" target="content" class="linkbtn">网站设置</a>
	</span>
	<div style="clear:both;"></div>
</div>
</body>
</html>