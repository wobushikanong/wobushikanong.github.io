<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
    <div class="main_title">
        <img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;回购管理
    </div>

    <div class="list_body">
        <table cellspacing=0 cellpadding=0 border=0>
            <tr>
                <th width="10%">币种（认购期号)</th>
                <th width="12%">状态</th>

                <th width="10%">已回购量</th>
                <th width="7%">待审核量</th>
                <th width="5%">回购价格</th>
                <th width="5%">查看审核</th>
                <th width="15%">更改状态</th>
            </tr>
            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                    <td><?php echo ($vo["name"]); ?>(第<font color="red"><?php echo ($vo["taskno"]); ?></font>期)</td>
                    <td>
                        <?php if($vo["flag"] == 1): ?><font color="green">
                               可回购
                            </font>
                            <?php else: ?>
                            <font color="red">
                               禁止回购
                            </font><?php endif; ?>

                    </td>


                    <td><?php echo (($vo["numsa"])?($vo["numsa"]):'0'); ?></td>
                    <td><?php echo (($vo["numsb"])?($vo["numsb"]):'0'); ?></td>
                    <td><?php echo (($vo["price"])?($vo["price"]):'0'); ?></td>
                    <td>
                        <?php if($vo["flag"] == 1): ?><a href=" ?s=Admin/Hg/shenhe/id/<?php echo ($vo["id"]); ?>"><font color="green">查看审核</font></a>
                         <?php else: ?>
                              打开开关才能查看<?php endif; ?>
                    </td>

                    <td>
                        <?php if($vo["flag"] == 1): ?><a href="?s=Admin/Hg/flag/id/<?php echo ($vo["id"]); ?>/act/off"> <font color="red">关闭回购</font></a>
                            <?php else: ?>
                            <a href="?s=Admin/Hg/flag/id/<?php echo ($vo["id"]); ?>/act/on"><font color="green">开启回购</font></a><?php endif; ?>
                    </td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
    </div>

</div>
</body>
</html>