<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<form action="?s=Admin/Login/go" method="post">
	<div class="login_border">
		<div class="login_win">
			<h2>网站管理系统</h2>
			<p>账号：<input type="text" name="username"/></p>
			<p>密码：<input type="password" name="password"/></p>
			<div class="login_sub_border"><input type="image" src="/Public/Admin/images/login_sub.jpg"/></div>
		</div>
	</div>
</form>
</body>
</html>
<script language="javascript">
$(document).ready(function(){
    $('input[name="username"]').focus();
}); 
</script>