<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;分红日志</eq>
	</div>
     <div class="list_body">
			<table cellspacing=0 cellpadding=0 border=0>
				<tr>
				   <th width="25%">会员ID</th><th>会员账户</th><th width="30%">分红数量</th><th>分红日期</th><th>分红币种</th>
				</tr>
				<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				   <td><?php echo (($vo["userid"])?($vo["userid"]):'无'); ?></td> <td><?php echo (($vo["user"])?($vo["user"]):'无'); ?></td><td><?php echo (($vo["num"])?($vo["num"]):'无'); ?></td>
                   <td><?php echo (date('Y-m-d',$vo["time"])); ?></td><td><?php echo ($vo["name"]); ?></td>
				</tr><?php endforeach; endif; else: echo "" ;endif; ?>
				<tr><td colspan=4><?php echo ($page); ?></tr>
			</table>
		</div>
</div>
</body>
</html>