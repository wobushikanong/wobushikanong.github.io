<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;认购管理
        <?php if($addFlag == 1): ?><font color="red"><?php echo ($typename); ?></font>正在认购中...
            <?php else: ?>
            当前无任何认购币活动!<?php endif; ?>
	</div>
    <?php if($addFlag == 1): ?><div class="list_body">
            <table cellspacing=0 cellpadding=0 border=0>
                <tr>
                    <th width="20%">币种（认购期号）</th>
                    <th width="10%">认购总量</th>
                    <th width="7%">已认购量</th>
                    <th width="7%">剩余量</th>
                     <th width="5%">认购币种</th>
                    <th width="5%">认购价格</th>
                    <th width="12%">限购数量</th>
                    <th width="14%">认购时间</th>
                    <th width="12%">状态</th>
                    <th width="15%">操作</th>
                </tr>

                    <?php if(is_array($nowdoArr)): $i = 0; $__LIST__ = $nowdoArr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$nowdo): $mod = ($i % 2 );++$i;?><tr>
                            <td><?php echo ($nowdo["name"]); ?>(第<font color="red"><?php echo (($nowdo["taskno"])?($nowdo["taskno"]):'0'); ?></font>期)</td>
                            <td><?php echo (($nowdo["num"])?($nowdo["num"]):'0'); ?></td>
                            <td><?php echo (($nowdo["issuenum"])?($nowdo["issuenum"]):'0'); ?></td>
                            <td><?php echo (($nowdo["nownum"])?($nowdo["nownum"]):'0'); ?></td>
                            <td><?php echo (($nowdo["money_type"])?($nowdo["money_type"]):'rmb'); ?></td>
                            <td><?php echo (($nowdo["price"])?($nowdo["price"]):'0'); ?></td>
                            <td><?php echo (($nowdo["limit"])?($nowdo["limit"]):'0'); ?></td>
                            <td><?php echo (($nowdo["addtime"])?($nowdo["addtime"]):'无'); ?></td>
                            <td>
                                <font color="red">正在认购中......</font>
                                <a href="?s=Admin/Issue/setFlag/id/<?php echo ($nowdo["id"]); ?>" onclick= "return confirm('确定关闭？关闭后在对应币种历史记录里面能够查找到！');">关闭</a>
                            </td>

                            <td><a href="?s=Admin/Buy/index/issueid/<?php echo ($nowdo["id"]); ?>"><font color="red">查看认购历史</font></a>
                                <a href="?s=Admin/Issue/set/id/<?php echo ($nowdo["id"]); ?>">修改</a> <a href="?s=Admin/Issue/del/id/<?php echo ($nowdo["id"]); ?>" onclick= "return confirm('确定删除？');">删除</a></td>
                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>


    </div><?php endif; ?>

	<div class="list_body">
	   	<table cellspacing=0 cellpadding=0 border=0>
		    <tr>
			   <th width="5%">认购币类别</th><th width="7%">新增</th><th width="7%">操作</th>
			</tr>

            <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                     <td width="5%"><?php echo ($vo["name"]); ?></td>
                     <td width="7%"><a href="javascript:addNew('<?php echo ($vo["id"]); ?>')">新增</a>
                     </td><td width="7%"><a href="?s=Admin/Issue/showlog/typeid/<?php echo ($vo["id"]); ?>"> 查看历史</a></td>
                </tr><?php endforeach; endif; else: echo "" ;endif; ?>
		</table>
	</div>

</div>
</body>
</html>
<script language="javascript">
    function addNew(id){
            window.location.href=" ?s=Admin/Issue/add/typeid/"+id;
    }



</script>