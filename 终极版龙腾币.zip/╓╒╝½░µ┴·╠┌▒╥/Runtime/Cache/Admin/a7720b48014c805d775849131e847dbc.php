<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="/Public/Admin/css/common.css" />
<script language="javascript" src="/Public/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="main_title">
		<img src="/Public/Admin/images/book1.gif"/>&nbsp;&nbsp;充值记录
	</div>
	<?php if(($module) == "list"): ?><div class="list_body">
	    <form action="<?php echo ($path); ?>/Fill/delAll" method="post" id="formid">
		<table cellspacing=0 cellpadding=0 border=0>
		    <tr>
			   <!--th width="5%">选择</th--><th width="15%">充值时间</th><th width="15%">用户名</th><th width="15%">充值金额</th><th width="15%">交易号码</th><th width="10%">状态</th><th width="5%">操作</th>
			</tr>
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
			   <!--td><input type="checkbox" class="id" name="id[]" value="<?php echo ($vo["id"]); ?>"></td--><td><?php echo (date('Y-m-d H:i:s',$vo["ctime"])); ?></td><td><?php echo (($vo["username"])?($vo["username"]):'无'); ?></td><td><?php echo (($vo["num"])?($vo["num"]):'0'); ?></td><td><?php echo (($vo["tradeno"])?($vo["tradeno"]):'无'); ?></td><td><?php if(($status) == "0"): ?>待充值<?php else: ?>充值成功<?php endif; ?></td><td><a href="<?php echo ($path); ?>/Fill/add/id/<?php echo ($vo["id"]); ?>">手动充值</a></td>
			</tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
			<tr>
			    <td colspan=7 class="page">
				    <!--input type="button" id="all" value=" 全选 ">
					<input type="button" id="all_return" value=" 全不选 ">
					<input type="button" id="dels" value=" 批量删除 "-->
					<a href="<?php echo ($path); ?>/Fill/index/page/1<?php echo ($urls); ?>">首页</a>
					<a href="<?php echo ($path); ?>/Fill/index/page/<?php echo ($page-1); echo ($urls); ?>">上一页</a>
					<a href="<?php echo ($path); ?>/Fill/index/page/<?php echo ($page+1); echo ($urls); ?>">下一页</a>
					<a href="<?php echo ($path); ?>/Fill/index/page/<?php echo ($page_num); echo ($urls); ?>">尾页</a>
                </td>
			</tr>
		</table>
		</form>
	</div>
	<?php else: ?>
	<div class="main_body">
		<form action="<?php echo ($path); ?>/Fill/insert" method="post">
		<input type="hidden" name="id" value="<?php echo ($id); ?>"/>
		<input type="hidden" name="uid" value="<?php echo ($uid); ?>"/>
		<table cellspacing=0 cellpadding=0 border=0>
		<tr><td>数量</td><td><input type="text" name="num" value="<?php echo ($num); ?>"/></td></tr>
		</table>
		<div><input type="submit" value="提交"/></div>
		</form>
	</div><?php endif; ?>
</div>
</body>
</html>
<script language="javascript">
$(document).ready(function(){
    $('#all').click(function(){
	    $('.id').attr('checked',true);
	});
	$('#all_return').click(function(){
	    $('.id').attr('checked',false);
	});
    $('#dels').click(function(){

		f = 0;
	    $('.id').each(function(){
		    if($(this).attr('checked')) f = 1;
		});
		
        if(f==0){
		    alert('请选择要删除的项！');
		}else{
		    $('#formid').submit();
		}
	});
	$('#add').click(function(){
	    location.href="<?php echo ($path); ?>/Fill/add";
	});
});
</script>