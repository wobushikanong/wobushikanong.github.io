<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="Description" content="<?php echo ($sys["description"]); ?>" />
<meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" />
    <script type="text/javascript">var loginFlag='<?php echo ($loginFlag); ?>';</script>
    <!--非cdn加速部分  -->
     <script type="text/javascript" src="/Public/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="/Public/Home/layer/layer.min.js"></script>

    <script type="text/javascript" src="/Public/Home/js/function.js"></script>
	<script type="text/javascript" src="/Public/Home/js/WebSiteJs.js"></script>
    <link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css">
	<link href="/Public/Home/css/css.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
    <!--非cdn加速部分  -->










 <!--CDN css 加速-->
 <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/2.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="/Public/Home/css/all.css">


 <!--&lt;!&ndash;CDN JS 加速&ndash;&gt;-->

    <!--&lt;!&ndash;第一个首选，如果加载失败js就会加载第二个地址&ndash;&gt;-->
    <!--<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>-->
    <!--<script type="text/javascript">-->
        <!--!window.jQuery && document.write('<script src=http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js><\/script>');-->
    <!--</script>-->



    <!--<script src="http://cdn.bootcss.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>-->
    <!--<script type="text/javascript" src="http://libs.baidu.com/jqueryui/1.10.4/jquery-ui.min.js"></script>-->



    <!--<script type="text/javascript" src="/Public/Home/js/jquery.ba-bbq.min.js"></script>-->


<!--<script type="text/javascript" src="/Public/Home/js/config.js"></script>-->

<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-2.3.min.js"></script>-->
<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-zh-CN.js"></script>-->




    <!--<script type="text/javascript" src="/Public/Home/js/layer/layer.min.js"></script>-->


<title><?php echo ($sys["title"]); ?></title>
<style type="text/css">
<!--
.STYLE2 {
	font-size: 12px;
	color: #8A2BE2;
}
-->
</style>
</head>
<body>
<!--最顶上的内容-->
<div class="top-fixed-all">
    <div class="top-fixed">
    
    
        <div class="container" style="background:#f6f6f6; border-bottom:1px solid #dedede">
        <div class="top">
            <div class="top-fixed-info" style="color:#000">
              <marquee behavior="scroll">你好，欢迎来到钻石世界，这里将带你开启财富之门</marquee>
               </div>
            <!--登录状态-->
            <div class="top-fixed-user">
                <?php if($login_user_id > 0 ): ?><div>
                        <div class="ll mt4 mr10">
                        </div>
                        <div class="user-msg-all">
                            <div class="f_ddd" id="user-hover" style="width:auto; color: #8A2BE2; font-weight: bold;"><em><?php echo ($login_user_name); ?></em><i></i></div>
                            <div class="user-msg">
  <p><a class="mr15" href="<?php echo ($path); ?>/User">用户信息</a>
                                    <a class="mr15" href="<?php echo ($path); ?>/User/detail">财务明细</a>
                                    <a href="<?php echo ($path); ?>/User/chongzhi">充值</a></p>
                            </div>
                        </div>
                        <div class="ll" style="margin-left:10px;"><a href="<?php echo ($path); ?>/Login/loginout">退出</a></div>
                        <div class="clear"></div>
                    </div>
                
                    <?php else: ?>
                    <div class="unsign">
                        <div class="ll mt4 mr10">
                        </div>
                        <a href="#" style="color:#666;" >加入收藏</a><a href="#" style="color:#666;">|&nbsp;&nbsp;设为首页</a>
                    </div><?php endif; ?>
            </div>
            <div class="clear"></div>
            </div>
        </div>
        
        
        
    </div>
</div>
<div class="mt30">
    <!--头部-->
    <div class="container">
        <div class=" o_h_z" style="width:1000px;">
            <div class="logo-index"><a href="/"><img src="/<?php echo ($sys["logo"]); ?>"/></a></div>
        </div>
         <!--导航-->
            <div class="nav-bar rr">
                <ul>
                    <li class="cur"><a href="/">首页</a>
                    <li><a href="?s=Home/Factory/index" onClick="return jumpLogin();">我的矿场</a></li>
                     <li><a href="?s=Home/User/invit" onClick="return jumpLogin();">邀请好友</a></li>
                     <li><a href="?s=Home/User" onClick="return jumpLogin();">会员中心</a></li>
                    <li><a href="?s=Home/ChongZhi/index" onClick="return jumpLogin();">资金充值</a></li>
                     <li><a href="?s=Home/User/tixian" onClick="return jumpLogin();">资金提现</a></li>
                    <li><a href="<?php echo ($path); ?>/Art/index/cate/news" onClick="return jumpLogin();">帮助</a></li>

                </ul>
            </div>
        
    </div>
    </div>
<!--交易页面的子导航区-->
<div class="marketArea clear">
<div class="leftMenu">
  <div class="bor">
    <div id="left_main_trance" class="tradeTitle"> <span class="trade1">交易中心</span> </div>
    <ul>
     
      <li id="left_findex"><a href="<?php echo ($path); ?>/Factory/index" class="items13">矿机专区</a></li>
      <li id="left_fwakuang"><a href="<?php echo ($path); ?>/Factory/wakuang" class="items13">造币工厂</a></li>
      <li id="left_jiaoyi"> <a href="<?php echo ($path); ?>/Gudong/index" class="items12">资金转账</a> </li>
    </ul>
  </div>
  <div class="bor">
    <div class="tradeTitle" id="left_main_user"> <span class="questionAnswer">用户中心</span></div>
    <ul>
      <li id="left_user"> <a href="<?php echo ($path); ?>/User" class="items11">账户信息</a><i></i> </li>
      <li id="left_safe"> <a href="<?php echo ($path); ?>/User/safe" class="items10">认证中心</a><i></i> </li>
      <li id="left_usercard"> <a href="<?php echo ($path); ?>/User/chkAlipay" class="items12">支付宝绑定</a> </li>
    </ul>
  </div>
  <div class="bor">
    <div class="tradeTitle" id="left_main_caiwu"> <span class="basicSetting1">财务管理</span> </div>
    <ul>
      <li id="left_chongzhi"> <a href="<?php echo ($path); ?>/ChongZhi/index" class="items8">人民币充值</a> </li>
      <li id="left_tixian"> <a href="<?php echo ($path); ?>/User/tixian" class="items6">人民币提现</a> </li>
    </ul>
  </div>
    <div class="bor">
    <div class="tradeTitle" id="left_main_tuiguang"> <span class="basicSetting1">推广中心</span> </div>
    <ul>
     <li id="left_invit"> <a href="<?php echo ($path); ?>/User/invit" class="items13">我的邀请</a></li>
       <li id="left_game"><a href="<?php echo ($path); ?>/Factory/ticheng" class="items4">推广提成列表</a></li> 
       </ul>
  </div>
    <div class="bor">
    <div class="tradeTitle" id="left_main_tuiguang"> <span class="basicSetting1">网站留言</span> </div>
    <ul>
     <li id="left_invit"> <a href="<?php echo ($path); ?>/GuestBook/index" class="items13">留言板</a></li>
       </ul>
  </div>
</div>

<div class="rightArea">
<!--全站交易记录-->
<div class="trade-part trade-part-hd mt20">
  <div class="trade-hd">
        <h5></i>账户提现【提现处理时间24小时内】</h5>
  </div>
  <div class="md">
    <div class="my-grid account_info" id="order-grid" style="margin-bottom:20px; width:905px !important;  border-top: 1px solid #ccc !important; height:auto; " >
	    <form action="<?php echo ($path); ?>/User/tixian" method="post" id="formid">
			<table class="items table  table-bordered table-condensed chkreal table-1">
			<tbody>
			<tr height="31">
				<td >币种：</td>
				<td>
				    <select id='typeid' name="typeid">
					    <?php if(is_array($types)): $i = 0; $__LIST__ = $types;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>" <?php if(($vo["tid"]) == $vo["id"]): ?>selected<?php endif; ?>><?php echo ($vo["nickname"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
					</select>
				    钻石可直接提现：提现比例1:1
					
				</td>
                
			</tr>
            <tr height="51">
            <td>当前余额：</td>
            <td>
            <?php if(is_array($rmb)): foreach($rmb as $key=>$v): ?><span style="width:150px; margin-left:20px">  <?php echo ($v["name"]); ?>:&nbsp;&nbsp;&nbsp;<?php echo ($v["goldnum"]); ?></span><?php endforeach; endif; ?>
                </td>
            </tr>
             <tr>
                <td>户主姓名：</td><td><span type="text" readonly><?php echo ($username); ?></span>



            </td>
            <tr>
                <td>提现地址：</td><td>
                <select name="url">
                <?php if(is_array($Arr)): $i = 0; $__LIST__ = $Arr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voA): $mod = ($i % 2 );++$i;?><option value="<?php echo ($key); ?>"><?php echo ($voA); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                </select>
                温馨提示：提现地址必须选择支付宝账号。没有的将不处理提现。 </td>
			</tr>
			<tr><td>提现金额：</td><td><input type="text" name="goldnum" placeholder="只能在100-50000元"/>
			提现金额必须是100的倍数</td></tr>
            <tr><td>手续费：</td><td><input type="hidden" name="shouxu" readonly value='<?php echo ($txfee); ?>' ><?php echo ($txfee); ?> %</td></tr>
			<tr><td>实际到帐：</td><td><input type="text" name="realnum" readonly value='')/></td></tr>
            
            </tr>
			<tr><td>交易密码：</td><td><input name="transpw" placeholder="请输入交易密码"/></td></tr>
			
			<tr><td colspan=2><span type="button" id="subbtn" class="btn" style="width:240px; display:block; background:#fb8318; color:#FFF;"/>确定</span></td></tr>
			</tbody>
			</table>
		</form>
	</div>
	<div class="my-grid account_info" id="order-grid" style="width:905px !important;">
		<table class="items table table-bordered table-condensed saferoom table-1">
		<thead>
		<tr><th>币种</th><th>金额</th><th>实际到帐</th><th>手续费</th><th>提现地址</th><th>时间</th><th width="10%">状态</th><th width="10%">操作</th></tr>
		</thead>
		<tbody>
		<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr><td class="chkTit"><?php echo (($vo["nickname"])?($vo["nickname"]):'无'); ?></td><td><?php echo (($vo["goldnum"])?($vo["goldnum"]):'0'); ?></td><td><?php echo (($vo["realnum"])?($vo["realnum"]):'0'); ?></td><td><?php echo (($vo["shouxu"])?($vo["shouxu"]):'0'); ?> %</td><td><?php echo (($vo["url"])?($vo["url"]):'0'); ?></td><td><?php echo (($vo["addtime"])?($vo["addtime"]):'无'); ?></td><td><?php if(($vo["status"]) == "0"): ?>正在处理<?php else: ?>已处理<?php endif; ?></td><td><a href="/index.php/Home/User/deltixian/id/<?php echo ($vo["id"]); ?>">撤销</a></td></tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
		</tbody>
		</table>
	</div>
  </div>
</div>
</div></div>
<!--尾部-->
<div class="footer-all">
      <div class="t_c grid-990 sitecopyright"><?php echo ($sys["copyright"]); echo ($sys["tongji"]); ?>       
	  <img src="img/3.jpg" width="127" height="47" />    <img src="img/4.jpg" width="127" height="47" />      <img src="img/5.jpg" width="127" height="47" />      <a href="http://t.knet.cn/index_new.jsp" target="_blank"><img src="img/7.jpg" width="127" height="47" /></a></div>
</div>
<div id="alert_room1"></div>
<script language="javascript" src="/Public/js/alert.js"></script>
<script type="text/javascript">
    var default_view = 0; <!--1是默认展开，0是默认关闭，新开窗口看效果，别在原页面刷新-->
</script>
<script type="text/javascript" src="/Public/js/qq.js"></script>

<!-- footer -->

<div class="modal hide fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>

<script type="text/javascript">
$(document).ready(function(){
    $('#typeid').change(function(){
        var flag="<?php echo ($tixianflag); ?>";
        if(flag){

            var Al=$(this).children('option:selected').val();
            if(Al!='5'){
                msgDalog('目前只支持人民币提现！');
                $("#subbtn").attr("disabled", true);
            }else{
                $("#subbtn").attr("disabled", false);
            }
        }
    })
});

$(document).ready(function(){
	$('#subbtn').click(function(){
		var goldnum = $('input[name=goldnum]').val();
	    if(goldnum=="" || goldnum <= 0){
		    msgDalog("请输入提现金额！","",0);
		}else if(isNaN(goldnum)){
			msgDalog('提现金额应该是数字！');
			$('input[name=goldnum]').val('');
			return false;
		}else if($('input[name=url]').val()==""){
		    msgDalog("你没有设置提现地址，请到钱包管理设置！","",0);
		}else if($('input[name=code]').val()==""){
		    msgDalog("请输入验证码！","",0);
		}else{
			var pos = goldnum.indexOf('.');
			if(pos != -1){
				if(goldnum.substring(0,pos)=='') {
					msgDalog('提现金额不合法！');
					return false;
				}
				len = goldnum.substring(pos+1,goldnum.length);
				if(len.length > 8) {
					msgDalog('提现金额小数位数不能超过8位！');
					return false;
				}
                $('#formid').submit();
			}else{
		        $('#formid').submit();
			}
		}
	});

	$('input[name=goldnum]').keyup(function(){

	    var goldnum = $('input[name=goldnum]').val();

		if(isNaN(goldnum)){
			msgDalog('提现金额应该是数字！');
			$('input[name=goldnum]').val('');
			return false;
		}

        var pos = goldnum.indexOf('.');
		if(pos != -1){

			if(goldnum.substring(0,pos)=='') {
				msgDalog('提现金额不合法！');
				$('input[name=goldnum]').focus();
				return false;
			}
			len = goldnum.substring(pos+1,goldnum.length);
			if(len.length > 8) {
				v = goldnum.substring(0,pos) + '.' + goldnum.substring(pos+1,pos+9);
				$('input[name=goldnum]').val(v);
				goldnum = v;
			}
		}

		var shouxu = $('input[name=shouxu]').val();
		realnum = goldnum - goldnum * shouxu / 100;
		if(realnum > 0) {
			realnum = String(realnum);
			var pos = realnum.indexOf('.');
			if(pos != -1){
				len = realnum.substring(pos+1,realnum.length);

				if(len.length > 8) {
					realnum = realnum.substring(0,pos) + '.' + realnum.substring(pos+1,pos+9);
				}
			}
		}

        $('input[name=realnum]').val(realnum);
	});

	$('input[name=goldnum]').change(function(){

	    var goldnum = $('input[name=goldnum]').val();

		if(isNaN(goldnum)){
			msgDalog('提现金额应该是数字！');
			$('input[name=goldnum]').val('');
			return false;
		}

        var pos = goldnum.indexOf('.');
		if(pos != -1){

			if(goldnum.substring(0,pos)=='') {
				msgDalog('提现金额不合法！');
				$('input[name=goldnum]').focus();
				return false;
			}
			len = goldnum.substring(pos+1,goldnum.length);
			if(len.length > 8) {
				v = goldnum.substring(0,pos) + '.' + goldnum.substring(pos+1,pos+9);
				$('input[name=goldnum]').val(v);
				goldnum = v;
			}
		}

		var shouxu = $('input[name=shouxu]').val();
		realnum = goldnum - goldnum * shouxu / 100;
		if(realnum > 0) {
			realnum = String(realnum);
			var pos = realnum.indexOf('.');
			if(pos != -1){
				len = realnum.substring(pos+1,realnum.length);

				if(len.length > 8) {
					realnum = realnum.substring(0,pos) + '.' + realnum.substring(pos+1,pos+9);
				}
			}
		}

        $('input[name=realnum]').val(realnum);
	});
});

$(document).ready(function(){
    $('#sendbtn').click(function(){
        var moble = '<?php echo ($user_info["moble"]); ?>';
        $('#sendbtn').attr('disabled','disabled');
        $.post('/?s=Home/Call/tixian',{phone:moble},function(flag){
            if(flag==1){
                alert('验证短信已经发送到'+moble+'上，请注意查收！');
            }else{
                alert('发送失败('+flag+')！请重新发送。');
            }
        });
        var i=60;
        var si = setInterval(function(){
            $('#sendbtn').val('（'+i+'）秒后可再次获取');

            if(i<=0) {
                clearInterval(si);
                $('#sendbtn').val('发送验证码');
                $('#sendbtn').attr('disabled',false);
            }
            i--;
        },1000);
    });
	var czurl = new Array();
	var czcoin = new Array();
	var czyuan = new Array();
	var rmbs = '';
	<?php if(is_array($types)): $i = 0; $__LIST__ = $types;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>czurl[<?php echo ($vo["id"]); ?>] = "<?php echo ($vo["url"]); ?>";
		czcoin[<?php echo ($vo["id"]); ?>] = "<?php echo ($vo["coin"]); ?>";
		czyuan[<?php echo ($vo["id"]); ?>] = "<?php echo ($vo["yuan"]); ?>";

		if(<?php echo ($vo["yuan"]); ?>==1){
		    <?php if(is_array($vo["url"])): $i = 0; $__LIST__ = $vo["url"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>rmbs += '<option value="'+"<?php echo ($vv); ?>"+'">'+"<?php echo ($vv); ?>"+'</option>';<?php endforeach; endif; else: echo "" ;endif; ?>
		}<?php endforeach; endif; else: echo "" ;endif; ?>
    $('select[name=typeid]').change(function(){
		if(czyuan[$(this).val()]==1){
			$('#urlshow').html('<select name="url">'+rmbs+'</select>');
		}else{
			$('#urlshow').html('<span type="text" name="url" readonly value="<?php echo ($url); ?>"/>');
			$('input[name=url]').val(czurl[$(this).val()]);
		}
		$('input[name=coin]').val(czcoin[$(this).val()]);
	});

	var typeid = $('select[name=typeid]').val();
	if(czyuan[typeid]==1){
		$('#urlshow').html('<select name="url">'+rmbs+'</select>');
	}else{
		$('#urlshow').html('<span type="text" name="url" readonly value="<?php echo ($url); ?>"/>');
		$('input[name=url]').val(czurl[typeid]);
	}

	$('input[name=coin]').val(czcoin[typeid]);
});
</script>
<script type="text/javascript">
    //显示当前类别样式
    $('#left_main_caiwu').removeClass().addClass('tradeTitlecur');//一级
    $('#left_main_trance span').removeClass().addClass('trade1cur');
    $('#left_tixian').addClass('cur');//二级
</script>

</body></html>