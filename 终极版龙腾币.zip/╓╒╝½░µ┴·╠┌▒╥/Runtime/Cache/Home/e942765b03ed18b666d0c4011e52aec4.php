<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<a id="_pinganTrust" target="_blank" href="http://c.trustutn.org/s/wfjdw.cn"></a><script type="text/javascript" src="http://c.trustutn.org/show?type=3&sn=201508241002837585"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="Description" content="<?php echo ($sys["description"]); ?>" />
<meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" />
    
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="Description" content="<?php echo ($sys["description"]); ?>" />
<meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" />
    <script type="text/javascript">var loginFlag='<?php echo ($loginFlag); ?>';</script>
    <!--非cdn加速部分  -->
     <script type="text/javascript" src="/Public/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="/Public/Home/layer/layer.min.js"></script>

    <script type="text/javascript" src="/Public/Home/js/function.js"></script>
	<script type="text/javascript" src="/Public/Home/js/WebSiteJs.js"></script>
    <link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css">
	<link href="/Public/Home/css/css.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
    <!--非cdn加速部分  -->










 <!--CDN css 加速-->
 <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/2.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="/Public/Home/css/all.css">


 <!--&lt;!&ndash;CDN JS 加速&ndash;&gt;-->

    <!--&lt;!&ndash;第一个首选，如果加载失败js就会加载第二个地址&ndash;&gt;-->
    <!--<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>-->
    <!--<script type="text/javascript">-->
        <!--!window.jQuery && document.write('<script src=http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js><\/script>');-->
    <!--</script>-->



    <!--<script src="http://cdn.bootcss.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>-->
    <!--<script type="text/javascript" src="http://libs.baidu.com/jqueryui/1.10.4/jquery-ui.min.js"></script>-->



    <!--<script type="text/javascript" src="/Public/Home/js/jquery.ba-bbq.min.js"></script>-->


<!--<script type="text/javascript" src="/Public/Home/js/config.js"></script>-->

<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-2.3.min.js"></script>-->
<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-zh-CN.js"></script>-->




    <!--<script type="text/javascript" src="/Public/Home/js/layer/layer.min.js"></script>-->


<title><?php echo ($sys["title"]); ?></title>
<style type="text/css">
<!--
.STYLE2 {
	font-size: 12px;
	color: #8A2BE2;
}
-->
</style>
</head>
<body>
<!--最顶上的内容-->
<div class="top-fixed-all">
    <div class="top-fixed">
    
    
        <div class="container" style="background:#f6f6f6; border-bottom:1px solid #dedede">
        <div class="top">
            <div class="top-fixed-info" style="color:#000">
              <marquee behavior="scroll">你好，欢迎来到钻石世界，这里将带你开启财富之门</marquee>
               </div>
            <!--登录状态-->
            <div class="top-fixed-user">
                <?php if($login_user_id > 0 ): ?><div>
                        <div class="ll mt4 mr10">
                        </div>
                        <div class="user-msg-all">
                            <div class="f_ddd" id="user-hover" style="width:auto; color: #8A2BE2; font-weight: bold;"><em><?php echo ($login_user_name); ?></em><i></i></div>
                            <div class="user-msg">
  <p><a class="mr15" href="<?php echo ($path); ?>/User">用户信息</a>
                                    <a class="mr15" href="<?php echo ($path); ?>/User/detail">财务明细</a>
                                    <a href="<?php echo ($path); ?>/User/chongzhi">充值</a></p>
                            </div>
                        </div>
                        <div class="ll" style="margin-left:10px;"><a href="<?php echo ($path); ?>/Login/loginout">退出</a></div>
                        <div class="clear"></div>
                    </div>
                
                    <?php else: ?>
                    <div class="unsign">
                        <div class="ll mt4 mr10">
                        </div>
                        <a href="#" style="color:#666;" >加入收藏</a><a href="#" style="color:#666;">|&nbsp;&nbsp;设为首页</a>
                    </div><?php endif; ?>
            </div>
            <div class="clear"></div>
            </div>
        </div>
        
        
        
    </div>
</div>
<div class="mt30">
    <!--头部-->
    <div class="container">
        <div class=" o_h_z" style="width:1000px;">
            <div class="logo-index"><a href="/"><img src="/<?php echo ($sys["logo"]); ?>"/></a></div>
        </div>
         <!--导航-->
            <div class="nav-bar rr">
                <ul>
                    <li class="cur"><a href="/">首页</a>
                    <li><a href="?s=Home/Factory/index" onClick="return jumpLogin();">我的矿场</a></li>
                     <li><a href="?s=Home/User/invit" onClick="return jumpLogin();">邀请好友</a></li>
                     <li><a href="?s=Home/User" onClick="return jumpLogin();">会员中心</a></li>
                    <li><a href="?s=Home/ChongZhi/index" onClick="return jumpLogin();">资金充值</a></li>
                     <li><a href="?s=Home/User/tixian" onClick="return jumpLogin();">资金提现</a></li>
                    <li><a href="<?php echo ($path); ?>/Art/index/cate/news" onClick="return jumpLogin();">帮助</a></li>

                </ul>
            </div>
        
    </div>
    </div>
<!--未登录前首页-->
<style type="text/css">
<!--
.STYLE1 {
	color: #FFF
}
.STYLE2 {
	color: #FFF
}
.STYLE3 {
	color: #FFF
}
.STYLE4 {
	color: #FFF
}
.STYLE5 {
	color: #FFF
}
.STYLE6 {
	color: #FFF
}

-->
</style>
<div class="not-loginbar">
     <?php if($login_user_id > 0 ): ?><!--已登录栏-->
	 <div class="loginbar-all">
         <div class="loginbar logined" style="top:20px; height:380px; background:rgba(0, 0, 0, 0.498039)">
		     <div class="login-box" style=" border-bottom:1px solid  #A00; height:50px; color:#7CFC00"><span>您已登陆！</span></div>
			 <div class="login-box" style=" height:45px; font-size:16px; color:#7CFC00; font-weight:700">登陆账号:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo ($login_user_name); ?></div>
			 <div class="login-box" style=" height:45px;font-size:16px; color:#7CFC00; font-weight:700">人民币余额：<?php echo ($rmb); ?>元</div>
              <div class="login-box" style=" height:45px;font-size:16px; color:#7CFC00; font-weight:700">矿机数量：<?php echo ($factory); ?>个</div>
			 <button onClick="javascript:location.href='<?php echo ($path); ?>/User'" style="background: #7CFC00;border-radius: 2px;width: 100px;height: 40px;line-height: 40px;color: #000000;font-size: 16px;cursor: pointer;text-shadow: 0 1px 2px #FFFF00;padding:0px;border:0px none;">会员中心</button>
             <button onClick="javascript:location.href='<?php echo ($path); ?>/Login/Loginout'" style="background: #7CFC00;border-radius: 2px;width: 100px;height: 40px;line-height: 40px;color:#000000;font-size: 16px;cursor: pointer;text-shadow: 0 1px 2px #e27316;padding:0px;border:0px none; margin-left:10px">退出</button>
         </div>
	 </div>
	 <?php else: ?>
     <!--未登录栏-->
     <div class="loginbar-all">
			 <div class="loginbar" id="loginbar">
				 <div class="login-box icon_user">
					 <div class="control-group">
						 <label class="control-label required">登录名 <span class="required">*</span></label>
						 <div class="controls">
							 <input placeholder="手机/邮箱/用户名" id="loginname" id="LoginForm_login" type="text">
						 </div>
					 </div>
				 </div>
				 <div class="login-box icon_password">
					 <div class="control-group ">
						 <label class="control-label required">登陆密码 <span class="required">*</span></label>
						 <div class="controls">
							 <input placeholder="登陆密码" id="loginpwd" id="LoginForm_password" type="password">
						 </div>
					 </div>
				 </div>
				
				 <div class="btn_button240" style="margin-top:20px"><button type="submit" name="yt1" onClick="loginDo();">登 录&nbsp;&nbsp;&nbsp;</button></div>
				 <p><a href="<?php echo ($path); ?>/Login/lostpwd" class="f_aaa">忘记密码？</a>&nbsp;&nbsp;<a href="<?php echo ($path); ?>/Login/reg/" class="f-ff9900 f-w">会员注册</a></p>
			 </div>
         <div class="loginbar-bg" id="loginbar-bg"></div>
     </div><?php endif; ?>
     <!--轮播图片-->

     <div class="slideBox">
        <div class="bd">
                <ul>
				    <?php if(is_array($ad)): $k = 0; $__LIST__ = $ad;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><li id="slider<?php echo ($k); ?>"><img src="/<?php echo ($vo["img"]); ?>"/></li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
           </div>
         <div class="hd">
             <ul>
                 <?php if(is_array($ad)): $k = 0; $__LIST__ = $ad;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><li id="slidertag<?php echo ($k); ?>"> <?php if($k == 1): ?>style="background:red;"<?php endif; ?>><?php echo ($k); ?></li><?php endforeach; endif; else: echo "" ;endif; ?>
             </ul>
         </div>
     </div>
</div>
<div style=" width:1000px;height:560px; overflow:hidden; display:inline-block; margin-top:10px;vertical-align:top">
  <span  style="display:block; background:#f5f5f5; border:1px solid #CCC; margin-top:10px; width:100%; height:30px; line-height:30px; font-size:14px; color:#00F;font-weight:700">【简单认知】</span>
  <div class="com_d" style="position:relative; background:#FFF; height:500px;">


<?php echo ($content1); ?>
   

<div class="com_d" style="position:relative; background:#FFF; height:100%;">    
</div>
<style>
	.com_d{ padding:10px}
	.com_d p{ font-size:14px; line-height:30px;}
	.buy-list ul li span{ display:inline-block; vertical-align:top; width:65px; text-align:center; font-size:14px;}
	.bg{background:url(Public/Home/images/sz4.gif) no-repeat; position:absolute; left:40px; top:80px; width:20px; height:350px;}
	.gonggao  span{ line-height:34px;}
</style>
</div></div>
<div class="ggao"></div>
</div>
<!--内容区-->
<div class="container">
    <div class=" o_h_z mt10">
      <!--左边栏-->
      <div class="part-l">
         <div class="answer">
              <div class="it-box">
                    <div class="itimg answer-safe"></div>
                    <div class="ittext">
                          <h1 class="STYLE1">安全可靠</h1>
                          <p>银行级系统SSL安全连接，短信身份验证机制以及分布式离线钱包备份机制<br>
        骨灰级机房设备，实时高效处理数据</p>
                    </div>
              </div>
              <div class="it-box">
                    <div class="itimg answer-service"></div>
                    <div class="ittext">
                          <h1 class="STYLE2">贴心服务</h1>
                          <p>亲爱的朋友，欢迎来到我们网站。我用心，您放心，我细心，您宽心，我专业，您省心。相信我们可以给您提供最优质的服务。</p>
                    </div>
              </div>
              <div class="it-box">
                    <div class="itimg answer-easy"></div>
                    <div class="ittext">
                          <h1 class="STYLE3">方便易用</h1>
                          <p>重视用户体验，界面友好，方便易用专业UI和数据分析，持续更新设计更专业易用的网站</p>
                    </div>
              </div>
              <div class="it-box">
                    <div class="itimg answer-fee"></div>
                    <div class="ittext">
                          <h1 class="STYLE4">投资安全</h1>
                          <p>聚国内顶级人才、建立顶级服务，并通过手机短信、实名认证等方式来保证您的资金账户安全 。</p>
                    </div>
              </div>
             <div class="it-box">
                 <div class="itimg answer-speed"></div>
                 <div class="ittext">
                     <h1 class="STYLE5">高效便捷</h1>
                     <p>人民币充值24小时即时入账，人民币提现实现7*10人工实时支付</p>
</div>
             </div>
             <div class="it-box">
                 <div class="itimg answer-speed1"></div>
                 <div class="ittext">
                     <h1 class="STYLE6">多元化获利</h1>
                     <p>众人拾柴火焰高，我们真诚的期待与您的合作，抢占市场先机，共镶成功盛举。我们将以最诚挚的态度，开诚布公来对待您。我们强调合作伙伴长远互惠互利的关系。;</p>
                 </div>
             </div>
         </div>
      </div>
      <!--右边栏-->
      <!--<div class="part-r">-->
	       <!--<div class="trade-part-hd" style="background:#eee;padding:10px;">-->
				 <!--<div class="trade-hd">-->
					   <!--<h6><i class="icon_entrus"></i>买卖委托盘</h6>-->
				 <!--</div>-->
				 <!--<div class="md">-->
					 <!--<table width="100%">-->
					    <!--<thead>-->
						    <!--<tr>-->
							   <!--<th>类型</th>-->
							   <!--<th>价格<font face="微软雅黑">(￥)</font></th>-->
							   <!--<th>数量(฿)</th>-->
						    <!--</tr>-->
						<!--</thead>-->
						<!--<tbody id="selllist">-->
						<!--<?php if(is_array($sells)): $k = 0; $__LIST__ = $sells;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?>-->
						<!--<tr class="trade-tr<?php echo ($k); ?>">-->
							<!--<td class="sell">卖</td>-->
							<!--<td><span class="sub_price"><?php echo ($vo["price"]); ?></span></td>-->
							<!--<td><span class="sub_amount"><?php echo ($vo["nums"]); ?></span></td>-->
							<!--<td><span style="width:2.667px" class="buySpan"></span></td>-->
						<!--</tr>-->
						<!--<?php endforeach; endif; else: echo "" ;endif; ?>-->
						<!--</tbody>-->


						<!--<tfoot id="buylist">-->
						<!--<?php if(is_array($buys)): $k = 0; $__LIST__ = $buys;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?>-->
						<!--<tr class="trade-tr<?php echo ($k); ?>">-->
							<!--<td class="buy">买</td>-->
							<!--<td><span class="sub_price"><?php echo ($vo["price"]); ?></span></td>-->
							<!--<td><span class="sub_amount"><?php echo ($vo["nums"]); ?></span></td>-->
							<!--<td><span style="width:2.667px" class="sellSpan"></span></td>-->
						<!--</tr>-->
						<!--<?php endforeach; endif; else: echo "" ;endif; ?>-->
						<!--</tfoot>-->


					 <!--</table>-->
				 <!--</div>-->
		 <!--</div>-->

      <!--</div>-->
    </div>
</div>
<!--尾部-->
<div class="footer-all">
      <div class="t_c grid-990 sitecopyright"><?php echo ($sys["copyright"]); echo ($sys["tongji"]); ?>       
	  <img src="img/3.jpg" width="127" height="47" />    <img src="img/4.jpg" width="127" height="47" />      <img src="img/5.jpg" width="127" height="47" />      <a href="http://t.knet.cn/index_new.jsp" target="_blank"><img src="img/7.jpg" width="127" height="47" /></a></div>
</div>
<div id="alert_room1"></div>
<script language="javascript" src="/Public/js/alert.js"></script>
<script type="text/javascript">
    var default_view = 0; <!--1是默认展开，0是默认关闭，新开窗口看效果，别在原页面刷新-->
</script>
<script type="text/javascript" src="/Public/js/qq.js"></script>

</body>
</html>