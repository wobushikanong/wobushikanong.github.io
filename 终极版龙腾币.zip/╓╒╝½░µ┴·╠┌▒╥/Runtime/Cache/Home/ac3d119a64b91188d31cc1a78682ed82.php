<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="Description" content="<?php echo ($sys["description"]); ?>" />
<meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" />
    <script type="text/javascript">var loginFlag='<?php echo ($loginFlag); ?>';</script>
    <!--非cdn加速部分  -->
     <script type="text/javascript" src="/Public/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="/Public/Home/layer/layer.min.js"></script>

    <script type="text/javascript" src="/Public/Home/js/function.js"></script>
	<script type="text/javascript" src="/Public/Home/js/WebSiteJs.js"></script>
    <link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css">
	<link href="/Public/Home/css/css.css" rel="stylesheet" type="text/css">
    <link href="/Public/Home/css/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
    <!--非cdn加速部分  -->










 <!--CDN css 加速-->
 <link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/2.3.1/css/bootstrap.min.css">
 <link rel="stylesheet" type="text/css" href="/Public/Home/css/all.css">


 <!--&lt;!&ndash;CDN JS 加速&ndash;&gt;-->

    <!--&lt;!&ndash;第一个首选，如果加载失败js就会加载第二个地址&ndash;&gt;-->
    <!--<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>-->
    <!--<script type="text/javascript">-->
        <!--!window.jQuery && document.write('<script src=http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js><\/script>');-->
    <!--</script>-->



    <!--<script src="http://cdn.bootcss.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>-->
    <!--<script type="text/javascript" src="http://libs.baidu.com/jqueryui/1.10.4/jquery-ui.min.js"></script>-->



    <!--<script type="text/javascript" src="/Public/Home/js/jquery.ba-bbq.min.js"></script>-->


<!--<script type="text/javascript" src="/Public/Home/js/config.js"></script>-->

<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-2.3.min.js"></script>-->
<!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-zh-CN.js"></script>-->




    <!--<script type="text/javascript" src="/Public/Home/js/layer/layer.min.js"></script>-->


<title><?php echo ($sys["title"]); ?></title>
<style type="text/css">
<!--
.STYLE2 {
	font-size: 12px;
	color: #8A2BE2;
}
-->
</style>
</head>
<body>
<!--最顶上的内容-->
<div class="top-fixed-all">
    <div class="top-fixed">
    
    
        <div class="container" style="background:#f6f6f6; border-bottom:1px solid #dedede">
        <div class="top">
            <div class="top-fixed-info" style="color:#000">
              <marquee behavior="scroll">你好，欢迎来到钻石世界，这里将带你开启财富之门</marquee>
               </div>
            <!--登录状态-->
            <div class="top-fixed-user">
                <?php if($login_user_id > 0 ): ?><div>
                        <div class="ll mt4 mr10">
                        </div>
                        <div class="user-msg-all">
                            <div class="f_ddd" id="user-hover" style="width:auto; color: #8A2BE2; font-weight: bold;"><em><?php echo ($login_user_name); ?></em><i></i></div>
                            <div class="user-msg">
  <p><a class="mr15" href="<?php echo ($path); ?>/User">用户信息</a>
                                    <a class="mr15" href="<?php echo ($path); ?>/User/detail">财务明细</a>
                                    <a href="<?php echo ($path); ?>/User/chongzhi">充值</a></p>
                            </div>
                        </div>
                        <div class="ll" style="margin-left:10px;"><a href="<?php echo ($path); ?>/Login/loginout">退出</a></div>
                        <div class="clear"></div>
                    </div>
                
                    <?php else: ?>
                    <div class="unsign">
                        <div class="ll mt4 mr10">
                        </div>
                        <a href="#" style="color:#666;" >加入收藏</a><a href="#" style="color:#666;">|&nbsp;&nbsp;设为首页</a>
                    </div><?php endif; ?>
            </div>
            <div class="clear"></div>
            </div>
        </div>
        
        
        
    </div>
</div>
<div class="mt30">
    <!--头部-->
    <div class="container">
        <div class=" o_h_z" style="width:1000px;">
            <div class="logo-index"><a href="/"><img src="/<?php echo ($sys["logo"]); ?>"/></a></div>
        </div>
         <!--导航-->
            <div class="nav-bar rr">
                <ul>
                    <li class="cur"><a href="/">首页</a>
                    <li><a href="?s=Home/Factory/index" onClick="return jumpLogin();">我的矿场</a></li>
                     <li><a href="?s=Home/User/invit" onClick="return jumpLogin();">邀请好友</a></li>
                     <li><a href="?s=Home/User" onClick="return jumpLogin();">会员中心</a></li>
                    <li><a href="?s=Home/ChongZhi/index" onClick="return jumpLogin();">资金充值</a></li>
                     <li><a href="?s=Home/User/tixian" onClick="return jumpLogin();">资金提现</a></li>
                    <li><a href="<?php echo ($path); ?>/Art/index/cate/news" onClick="return jumpLogin();">帮助</a></li>

                </ul>
            </div>
        
    </div>
    </div>
<div class="marketArea clear">
    <div class="leftMenu">
  <div class="bor">
    <div id="left_main_trance" class="tradeTitle"> <span class="trade1">交易中心</span> </div>
    <ul>
     
      <li id="left_findex"><a href="<?php echo ($path); ?>/Factory/index" class="items13">矿机专区</a></li>
      <li id="left_fwakuang"><a href="<?php echo ($path); ?>/Factory/wakuang" class="items13">造币工厂</a></li>
      <li id="left_jiaoyi"> <a href="<?php echo ($path); ?>/Gudong/index" class="items12">资金转账</a> </li>
    </ul>
  </div>
  <div class="bor">
    <div class="tradeTitle" id="left_main_user"> <span class="questionAnswer">用户中心</span></div>
    <ul>
      <li id="left_user"> <a href="<?php echo ($path); ?>/User" class="items11">账户信息</a><i></i> </li>
      <li id="left_safe"> <a href="<?php echo ($path); ?>/User/safe" class="items10">认证中心</a><i></i> </li>
      <li id="left_usercard"> <a href="<?php echo ($path); ?>/User/chkAlipay" class="items12">支付宝绑定</a> </li>
    </ul>
  </div>
  <div class="bor">
    <div class="tradeTitle" id="left_main_caiwu"> <span class="basicSetting1">财务管理</span> </div>
    <ul>
      <li id="left_chongzhi"> <a href="<?php echo ($path); ?>/ChongZhi/index" class="items8">人民币充值</a> </li>
      <li id="left_tixian"> <a href="<?php echo ($path); ?>/User/tixian" class="items6">人民币提现</a> </li>
    </ul>
  </div>
    <div class="bor">
    <div class="tradeTitle" id="left_main_tuiguang"> <span class="basicSetting1">推广中心</span> </div>
    <ul>
     <li id="left_invit"> <a href="<?php echo ($path); ?>/User/invit" class="items13">我的邀请</a></li>
       <li id="left_game"><a href="<?php echo ($path); ?>/Factory/ticheng" class="items4">推广提成列表</a></li> 
       </ul>
  </div>
    <div class="bor">
    <div class="tradeTitle" id="left_main_tuiguang"> <span class="basicSetting1">网站留言</span> </div>
    <ul>
     <li id="left_invit"> <a href="<?php echo ($path); ?>/GuestBook/index" class="items13">留言板</a></li>
       </ul>
  </div>
</div>

    <div class="rightArea">
  <script type="text/javascript">
//<![CDATA[
var theForm = document.forms['from1'];
if (!theForm) {
    theForm = document.from1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script> 
  <script>if(""!="")ChangeStatus("");</script>
  <div class="wrap">
    <div class="content"> 
      <script type="text/javascript" src="/Public/Home/js/LeftJs.js"></script> 
      <script>if("我的帐户"!="")ClickLeftCol("我的帐户");</script>
      <div class="right" style="border-right:0px; border-bottom:0px; border-top:0px; ">
        <div class="account_info">
          <ul>
            <li>
              <p class="username">账号：<?php echo ($info['username']); ?>（<a class="a_1e5bb3" href="?s=Home/User/setPwd">修改密码</a>）</p>
            </li>
            <li>
              <p class="username" style=""><?php echo (($chongzhi[0]['nickname'])?($chongzhi[0]['nickname']):'无'); ?>：<b>￥</b> <?php echo (($chongzhi[0]['total'])?($chongzhi[0]['total']):0); ?>元</p>
                <p style=""><a href="?s=Home/ChongZhi/index"><img src="/Public/Home/images/cz.png" style="width:23px;"></a></p>
            <a class="submit fn-left2" href="?s=Home/Factory/index" style="width:150px;margin-right:50px; float:right; background-color:Green;">立即抢购矿机</a> </li>
            <li>
              <p class="username" style=""><?php echo (($chongzhi[1]['nickname'])?($chongzhi[1]['nickname']):'无'); ?>：<b style="font-size:18px;">￥</b><?php echo (($chongzhi[1]['total'])?($chongzhi[1]['total']):0); ?>个</p>
            </li>
            <li>
              <p class="username" style="">好友数量：<b style="font-size:18px;"></b><?php echo ($haoyou); ?>个</p>
            </li>
            <li>
              <p class="username" style="width:100%;">我的钻机：<?php echo (($my_factory)?($my_factory):0); ?>台&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 钻机状态：<?php echo ($fk); ?>（<a class="a_1e5bb3" href="?s=Home/Factory/index">查看详情</a>）</p>
              </li>
            <li class="last">
              <p>邀请好友注册：<?php echo ($info['inviturl']); ?> <a target="_blank" class="a_1e5bb3" href=""></a><a onClick="#" title="邀请好友注册，您可以获得哈稀币哟！" href="javascript:void(0)"></a></p>
              <a class="submit fn-left2" href="?s=Home/User/invit" style="width:150px;margin-right:50px; float:right;">我要推广</a> </li> 
</li>
          </ul>
        
        </div>
        <div class="account_info" style="margin-top:10px;">
          <ul>
            <li>
              <p class="regist_time">注册时间:
                <?php echo ($info['addtime']); ?></p>
            </li>
            <li>
              <p class="regist_time">上次登录时间:
                <?php echo ($info['logintime']); ?></p>
            </li>
            <li>
              <p class="username">注册邮箱：
                <?php if($email == 1 ): echo ($info['email']); ?>
                  <?php else: ?>
                  <b> <img src="/Public/Home/images/set0.png" style="height:16px;" /> 未认证</b> （<a class="a_1e5bb3" href="?s=Home/User/safe">去认证</a>）<?php endif; ?>
              </p>
            </li>
            <li>
              <p class="username" style="width:300px;">安全密码设置：
                <?php if($transpw == 1 ): ?><b> <img src="/Public/Home/images/set0.png" style="height:16px;" /> 已经设置</b>
                  <?php else: ?>
                  <b> <img src="/Public/Home/images/set0.png" style="height:16px;" /> 未设置</b> （<a class="a_1e5bb3" href="?s=Home/User/safe">去设置</a>）<?php endif; ?>
              </p>
            </li>
            <li>
              <p class="username">实名认证：
                <?php if($xm == 1 ): echo ($info['xm']); ?>
                  <?php else: ?>
                  <b> <img src="/Public/Home/images/set0.png" style="height:16px;" /> 未认证</b> （<a class="a_1e5bb3" href="?s=Home/User/safe">去认证</a>）<?php endif; ?>
              </p>
            </li>
          </ul>
        </div>
        <div style="display:none;">
          <input name="TJlCols" type="hidden" id="TJlCols">
          <input name="TBonusCols" type="hidden" id="TBonusCols">
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript" src="js/jquery-1.6.min.js"></script>
  <div class="clear"></div>
  <div>
    <input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="">
  </div>
<script type="text/javascript" src="js/SealAction.aspx" id="script379234182"></script>
</body></div></div>
<!--尾部-->
<div class="footer-all">
      <div class="t_c grid-990 sitecopyright"><?php echo ($sys["copyright"]); echo ($sys["tongji"]); ?>       
	  <img src="img/3.jpg" width="127" height="47" />    <img src="img/4.jpg" width="127" height="47" />      <img src="img/5.jpg" width="127" height="47" />      <a href="http://t.knet.cn/index_new.jsp" target="_blank"><img src="img/7.jpg" width="127" height="47" /></a></div>
</div>
<div id="alert_room1"></div>
<script language="javascript" src="/Public/js/alert.js"></script>
<script type="text/javascript">
    var default_view = 0; <!--1是默认展开，0是默认关闭，新开窗口看效果，别在原页面刷新-->
</script>
<script type="text/javascript" src="/Public/js/qq.js"></script>

<!-- footer -->


<style>
	.username{ width:240px;}
</style>
<div class="modal hide fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>
</html>