<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title>���߳�ֵ</title>
</head>
<body>
<form id="alipaysubmit" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="post">
<input name="title" type="hidden" value="<?php echo ($tradeno); ?>"/>
<input name="optEmail" type="hidden" value="cq1991@21cn.com" />
<input name="payAmount" type="hidden" value="<?php echo ($money); ?>" />
<input type="hidden" value="<?php echo ($tradeno); ?>" name="memo"/>
<input name="ok" type="submit" value=""/>
</form>
<script>document.forms['alipaysubmit'].submit();</script>

</body>
</html>