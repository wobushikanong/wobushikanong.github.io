<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="Description" content="<?php echo ($sys["description"]); ?>" /><meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" /><script type="text/javascript">var loginFlag='<?php echo ($loginFlag); ?>';</script><!--非cdn加速部分  --><script type="text/javascript" src="/Public/js/jquery-1.11.1.min.js"></script><script type="text/javascript" src="/Public/Home/layer/layer.min.js"></script><script type="text/javascript" src="/Public/Home/js/function.js"></script><script type="text/javascript" src="/Public/Home/js/WebSiteJs.js"></script><link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css"><link href="/Public/Home/css/css.css" rel="stylesheet" type="text/css"><link href="/Public/Home/css/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection"><!--非cdn加速部分  --><!--CDN css 加速--><link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/2.3.1/css/bootstrap.min.css"><link rel="stylesheet" type="text/css" href="/Public/Home/css/all.css"><!--&lt;!&ndash;CDN JS 加速&ndash;&gt;--><!--&lt;!&ndash;第一个首选，如果加载失败js就会加载第二个地址&ndash;&gt;--><!--<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>--><!--<script type="text/javascript">--><!--!window.jQuery && document.write('<script src=http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js><\/script>');--><!--</script>--><!--<script src="http://cdn.bootcss.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>--><!--<script type="text/javascript" src="http://libs.baidu.com/jqueryui/1.10.4/jquery-ui.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.ba-bbq.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/config.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-2.3.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-zh-CN.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/layer/layer.min.js"></script>--><title><?php echo ($sys["title"]); ?></title><style type="text/css"><!--
.STYLE2 {
	font-size: 12px;
	color: #8A2BE2;
}
--></style></head><body><!--最顶上的内容--><div class="top-fixed-all"><div class="top-fixed"><div class="container" style="background:#f6f6f6; border-bottom:1px solid #dedede"><div class="top"><div class="top-fixed-info" style="color:#000"><marquee behavior="scroll">你好，欢迎来到钻石世界，这里将带你开启财富之门</marquee></div><!--登录状态--><div class="top-fixed-user"><?php if($login_user_id > 0 ): ?><div><div class="ll mt4 mr10"></div><div class="user-msg-all"><div class="f_ddd" id="user-hover" style="width:auto; color: #8A2BE2; font-weight: bold;"><em><?php echo ($login_user_name); ?></em><i></i></div><div class="user-msg"><p><a class="mr15" href="<?php echo ($path); ?>/User">用户信息</a><a class="mr15" href="<?php echo ($path); ?>/User/detail">财务明细</a><a href="<?php echo ($path); ?>/User/chongzhi">充值</a></p></div></div><div class="ll" style="margin-left:10px;"><a href="<?php echo ($path); ?>/Login/loginout">退出</a></div><div class="clear"></div></div><?php else: ?><div class="unsign"><div class="ll mt4 mr10"></div><a href="#" style="color:#666;" >加入收藏</a><a href="#" style="color:#666;">|&nbsp;&nbsp;设为首页</a></div><?php endif; ?></div><div class="clear"></div></div></div></div></div><div class="mt30"><!--头部--><div class="container"><div class=" o_h_z" style="width:1000px;"><div class="logo-index"><a href="/"><img src="/<?php echo ($sys["logo"]); ?>"/></a></div></div><!--导航--><div class="nav-bar rr"><ul><li class="cur"><a href="/">首页</a><li><a href="?s=Home/Factory/index" onClick="return jumpLogin();">我的矿场</a></li><li><a href="?s=Home/User/invit" onClick="return jumpLogin();">邀请好友</a></li><li><a href="?s=Home/User" onClick="return jumpLogin();">会员中心</a></li><li><a href="?s=Home/ChongZhi/index" onClick="return jumpLogin();">资金充值</a></li><li><a href="?s=Home/User/tixian" onClick="return jumpLogin();">资金提现</a></li><li><a href="<?php echo ($path); ?>/Art/index/cate/news" onClick="return jumpLogin();">帮助</a></li></ul></div></div></div><!--交易页面的子导航区--><div class="marketArea clear"><div class="leftMenu"><div class="bor"><div id="left_main_trance" class="tradeTitle"><span class="trade1">交易中心</span></div><ul><li id="left_findex"><a href="<?php echo ($path); ?>/Factory/index" class="items13">矿机专区</a></li><li id="left_fwakuang"><a href="<?php echo ($path); ?>/Factory/wakuang" class="items13">造币工厂</a></li><li id="left_jiaoyi"><a href="<?php echo ($path); ?>/Gudong/index" class="items12">资金转账</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_user"><span class="questionAnswer">用户中心</span></div><ul><li id="left_user"><a href="<?php echo ($path); ?>/User" class="items11">账户信息</a><i></i></li><li id="left_safe"><a href="<?php echo ($path); ?>/User/safe" class="items10">认证中心</a><i></i></li><li id="left_usercard"><a href="<?php echo ($path); ?>/User/chkAlipay" class="items12">支付宝绑定</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_caiwu"><span class="basicSetting1">财务管理</span></div><ul><li id="left_chongzhi"><a href="<?php echo ($path); ?>/ChongZhi/index" class="items8">人民币充值</a></li><li id="left_tixian"><a href="<?php echo ($path); ?>/User/tixian" class="items6">人民币提现</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_tuiguang"><span class="basicSetting1">推广中心</span></div><ul><li id="left_invit"><a href="<?php echo ($path); ?>/User/invit" class="items13">我的邀请</a></li><li id="left_game"><a href="<?php echo ($path); ?>/Factory/ticheng" class="items4">推广提成列表</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_tuiguang"><span class="basicSetting1">网站留言</span></div><ul><li id="left_invit"><a href="<?php echo ($path); ?>/GuestBook/index" class="items13">留言板</a></li></ul></div></div><div class="rightArea"><!--全站交易记录--><div class="trade-part trade-part-hd mt20"><div class="trade-hd"><h5><i class="icon_condition"></i>交易密码重置</h5></div><div class="md"><div class="my-grid" id="order-grid"><form action="<?php echo ($path); ?>/User/resetTransPw" method="post" id="formid"><table class="items table table-striped table-bordered table-condensed chkreal"><tbody><tr><td colspan=2>为了您的资金安全，请设置交易密码。</td></tr><tr><td>新交易密码：</td><td><input type="password" name="transpw"/></td></tr><tr><td>重复新密码：</td><td><input type="password" name="retranspw"/></td></tr><tr><td>手机验证码</td><td><input type="text" name="code"/><input type="button" class="btn" id="sendbtn" value="发送验证码"/></td></tr><tr><td colspan=2><input type="button" id="subbtn" class="btn" value="确定"/></td></tr></tbody></table></form></div></div></div></div></div><!--尾部--><div class="footer-all"><div class="t_c grid-990 sitecopyright"><?php echo ($sys["copyright"]); echo ($sys["tongji"]); ?><img src="img/3.jpg" width="127" height="47" /><img src="img/4.jpg" width="127" height="47" /><img src="img/5.jpg" width="127" height="47" /><a href="http://t.knet.cn/index_new.jsp" target="_blank"><img src="img/7.jpg" width="127" height="47" /></a></div></div><div id="alert_room1"></div><script language="javascript" src="/Public/js/alert.js"></script><script type="text/javascript">    var default_view = 0; <!--1是默认展开，0是默认关闭，新开窗口看效果，别在原页面刷新--></script><script type="text/javascript" src="/Public/js/qq.js"></script><!-- footer --><div class="modal hide fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div><script type="text/javascript">$(document).ready(function(){
	$('#subbtn').click(function(){
	    if($('input[name=transpw]').val()==""){
		    msgDalog("请输入新交易密码！","",0);
		}else if($('input[name=retranspw]').val()==""){
		    msgDalog("请再次输入新交易密码！","",0);
		}else if($('input[name=moble]').val()==""){
		    msgDalog("请输入手机验证码！","",0);
		}else{
		    $('#formid').submit();
		}
	});
});

$(document).ready(function(){
    $('#sendbtn').click(function(){
		$('#sendbtn').attr('disabled','disabled');
		var moble = "<?php echo ($user_info["moble"]); ?>";
		$.post('/?s=Home/Call/run',{phone:moble},function(flag){
			if(flag==1){
				alert('语音已开启，请注意查收验证码！');
			}else{
				alert('验证失败！请重新验证。');   
			}
		});
	    var i=60;
		var si = setInterval(function(){
		    $('#sendbtn').val('（'+i+'）秒后可再次获取');
			
			if(i<=0) {
				clearInterval(si);
				$('#sendbtn').val('发送验证码');
				$('#sendbtn').attr('disabled',false);
			}
			i--;
		},1000);
	});
});
</script></body></html>