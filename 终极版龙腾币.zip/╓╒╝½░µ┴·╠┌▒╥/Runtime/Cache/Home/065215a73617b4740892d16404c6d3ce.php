<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta name="Description" content="<?php echo ($sys["description"]); ?>" /><meta name="keywords" content="<?php echo ($sys["keyword"]); ?>" /><script type="text/javascript">var loginFlag='<?php echo ($loginFlag); ?>';</script><!--非cdn加速部分  --><script type="text/javascript" src="/Public/js/jquery-1.11.1.min.js"></script><script type="text/javascript" src="/Public/Home/layer/layer.min.js"></script><script type="text/javascript" src="/Public/Home/js/function.js"></script><script type="text/javascript" src="/Public/Home/js/WebSiteJs.js"></script><link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css"><link href="/Public/Home/css/css.css" rel="stylesheet" type="text/css"><link href="/Public/Home/css/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection"><!--非cdn加速部分  --><!--CDN css 加速--><link rel="stylesheet" href="http://cdn.bootcss.com/bootstrap/2.3.1/css/bootstrap.min.css"><link rel="stylesheet" type="text/css" href="/Public/Home/css/all.css"><!--&lt;!&ndash;CDN JS 加速&ndash;&gt;--><!--&lt;!&ndash;第一个首选，如果加载失败js就会加载第二个地址&ndash;&gt;--><!--<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>--><!--<script type="text/javascript">--><!--!window.jQuery && document.write('<script src=http://lib.sinaapp.com/js/jquery/1.8.3/jquery.min.js><\/script>');--><!--</script>--><!--<script src="http://cdn.bootcss.com/twitter-bootstrap/2.3.1/js/bootstrap.min.js"></script>--><!--<script type="text/javascript" src="http://libs.baidu.com/jqueryui/1.10.4/jquery-ui.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.ba-bbq.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/config.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-2.3.min.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/jquery.jBox-zh-CN.js"></script>--><!--<script type="text/javascript" src="/Public/Home/js/layer/layer.min.js"></script>--><title><?php echo ($sys["title"]); ?></title><style type="text/css"><!--
.STYLE2 {
	font-size: 12px;
	color: #8A2BE2;
}
--></style></head><body><!--最顶上的内容--><div class="top-fixed-all"><div class="top-fixed"><div class="container" style="background:#f6f6f6; border-bottom:1px solid #dedede"><div class="top"><div class="top-fixed-info" style="color:#000"><marquee behavior="scroll">你好，欢迎来到钻石世界，这里将带你开启财富之门</marquee></div><!--登录状态--><div class="top-fixed-user"><?php if($login_user_id > 0 ): ?><div><div class="ll mt4 mr10"></div><div class="user-msg-all"><div class="f_ddd" id="user-hover" style="width:auto; color: #8A2BE2; font-weight: bold;"><em><?php echo ($login_user_name); ?></em><i></i></div><div class="user-msg"><p><a class="mr15" href="<?php echo ($path); ?>/User">用户信息</a><a class="mr15" href="<?php echo ($path); ?>/User/detail">财务明细</a><a href="<?php echo ($path); ?>/User/chongzhi">充值</a></p></div></div><div class="ll" style="margin-left:10px;"><a href="<?php echo ($path); ?>/Login/loginout">退出</a></div><div class="clear"></div></div><?php else: ?><div class="unsign"><div class="ll mt4 mr10"></div><a href="#" style="color:#666;" >加入收藏</a><a href="#" style="color:#666;">|&nbsp;&nbsp;设为首页</a></div><?php endif; ?></div><div class="clear"></div></div></div></div></div><div class="mt30"><!--头部--><div class="container"><div class=" o_h_z" style="width:1000px;"><div class="logo-index"><a href="/"><img src="/<?php echo ($sys["logo"]); ?>"/></a></div></div><!--导航--><div class="nav-bar rr"><ul><li class="cur"><a href="/">首页</a><li><a href="?s=Home/Factory/index" onClick="return jumpLogin();">我的矿场</a></li><li><a href="?s=Home/User/invit" onClick="return jumpLogin();">邀请好友</a></li><li><a href="?s=Home/User" onClick="return jumpLogin();">会员中心</a></li><li><a href="?s=Home/ChongZhi/index" onClick="return jumpLogin();">资金充值</a></li><li><a href="?s=Home/User/tixian" onClick="return jumpLogin();">资金提现</a></li><li><a href="<?php echo ($path); ?>/Art/index/cate/news" onClick="return jumpLogin();">帮助</a></li></ul></div></div></div><!--交易页面的子导航区--><div class="marketArea clear"><div class="leftMenu"><div class="bor"><div id="left_main_trance" class="tradeTitle"><span class="trade1">交易中心</span></div><ul><li id="left_findex"><a href="<?php echo ($path); ?>/Factory/index" class="items13">矿机专区</a></li><li id="left_fwakuang"><a href="<?php echo ($path); ?>/Factory/wakuang" class="items13">造币工厂</a></li><li id="left_jiaoyi"><a href="<?php echo ($path); ?>/Gudong/index" class="items12">资金转账</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_user"><span class="questionAnswer">用户中心</span></div><ul><li id="left_user"><a href="<?php echo ($path); ?>/User" class="items11">账户信息</a><i></i></li><li id="left_safe"><a href="<?php echo ($path); ?>/User/safe" class="items10">认证中心</a><i></i></li><li id="left_usercard"><a href="<?php echo ($path); ?>/User/chkAlipay" class="items12">支付宝绑定</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_caiwu"><span class="basicSetting1">财务管理</span></div><ul><li id="left_chongzhi"><a href="<?php echo ($path); ?>/ChongZhi/index" class="items8">人民币充值</a></li><li id="left_tixian"><a href="<?php echo ($path); ?>/User/tixian" class="items6">人民币提现</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_tuiguang"><span class="basicSetting1">推广中心</span></div><ul><li id="left_invit"><a href="<?php echo ($path); ?>/User/invit" class="items13">我的邀请</a></li><li id="left_game"><a href="<?php echo ($path); ?>/Factory/ticheng" class="items4">推广提成列表</a></li></ul></div><div class="bor"><div class="tradeTitle" id="left_main_tuiguang"><span class="basicSetting1">网站留言</span></div><ul><li id="left_invit"><a href="<?php echo ($path); ?>/GuestBook/index" class="items13">留言板</a></li></ul></div></div><div class="rightArea"><!--全站交易记录--><div class="trade-part trade-part-hd mt20"><div class="trade-hd"><h5><i class="icon_condition"></i>账户充值(第一步)</h5></div><div class="md"><div class="my-grid" id="order-grid" style="margin-bottom:20px;"><form action="<?php echo ($path); ?>/User/chongzhi" method="post" id="formid"><input type="hidden" name="yuan" id="yuan" value="0"/><table class="items table table-striped table-bordered table-condensed chkreal"><tbody><tr><td colspan="2"><img src="./Public/Home/cz/cz1.png"></td></tr><tr><td colspan="2"><font style="color: red;font-size: bold;line-height: 40px;font-size: 16px">
                            ◆因为国家对支付行业的相关调整,本网站采取线上申请线下打款的方式,给您带来的不便,敬请谅解!谢谢!!</font></td></tr><tr><td>充值金额：</td><td><input type="text" name="goldnum" placeholder="充值金额限定在<?php echo ($chongzhid); ?>元--<?php echo ($chongzhiu); ?>元之间"/></td><input type="hidden" name="url" value="<?php echo (($url)?($url):'无'); ?>" readonly/></tr><tr><td>验证码：</td><td><input type="text" name="code" placeholder="请输入验证码" style="width:114px;"/><img id="refresh" style="vertical-align:middle;height:30px;margin-left:5px;" onclick="document.getElementById('refresh').src='<?php echo ($path); ?>/Login/checkcode/t/'+Math.random()" src="<?php echo ($path); ?>/Login/checkcode/" title="看不清？点一下"/></td></tr><tr><td colspan=2><input type="button" id="subbtn" class="btn" value="确定"/></td></tr></tbody></table></form></div><div class="my-grid" id="order-grid"><table class="items table table-striped table-bordered table-condensed saferoom"><thead><tr><th>订单号</th><th>金额</th><th>时间</th><th width="40%">状态</th><th width="10%">操作</th></tr></thead><tbody  id="czbody"></tbody></table><div id="page"></div></div></div></div></div></div><!--尾部--><div class="footer-all"><div class="t_c grid-990 sitecopyright"><?php echo ($sys["copyright"]); echo ($sys["tongji"]); ?><img src="img/3.jpg" width="127" height="47" /><img src="img/4.jpg" width="127" height="47" /><img src="img/5.jpg" width="127" height="47" /><a href="http://t.knet.cn/index_new.jsp" target="_blank"><img src="img/7.jpg" width="127" height="47" /></a></div></div><div id="alert_room1"></div><script language="javascript" src="/Public/js/alert.js"></script><script type="text/javascript">    var default_view = 0; <!--1是默认展开，0是默认关闭，新开窗口看效果，别在原页面刷新--></script><script type="text/javascript" src="/Public/js/qq.js"></script><!-- footer --><div class="modal hide fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div><script type="text/javascript">    $(document).ready(function(){
        $('#subbtn').click(function(){
            var goldnum = $('input[name=goldnum]').val();

            if(goldnum=="" || goldnum <= 0){
                msgDalog("请输入充值金额！","",0);
                return false;
            }else if(isNaN(goldnum)){
                msgDalog('充值金额应该是数字！');
                $('input[name=goldnum]').val('');
                return false;
            }if(goldnum>=<?php echo ($chongzhiu); ?>){
                msgDalog('充值金额不能超过<?php echo ($chongzhiu); ?>元！');
                return false;
            }if(goldnum<<?php echo ($chongzhid); ?>){
                msgDalog('充值金额不能少于<?php echo ($chongzhid); ?>元！');
                return false;
            }else if($('input[name=code]').val()==""){
                msgDalog("请输入验证码！","",0);
                return false;
            }else{
                     $('#formid').submit();

            }
        });

        getczdata(1);
    });




    function czapplyback(id){
        var loadi = layer.load('正在取消...…');
        $.ajax({
            type : "get",
            url : "<?php echo ($path); ?>/User/czapplyback/id/"+id,
            async : false,
            success : function(data){
                layer.close(loadi);
               if(data!=false){
                   $('#del'+id).remove();
               }else{
                   layer.alert('取消失败!');
               }
            }
        });
    }


    function czstatus(id){
        var loadi = layer.load('正在提交...…');
        $.ajax({
            type : "get",
            url : "<?php echo ($path); ?>/User/czConfirm/id/"+id,
            async : false,
            success : function(data){
                layer.close(loadi);
                if(data!=false){
                  $('#status'+id).html(' <font color="red">等待网站管理员审核</font>');
                }else{
                    layer.alert('提交失败!');
                }
            }
        });
    }
</script><script type="text/javascript">
    //显示当前类别样式
    $('#left_main_user').removeClass().addClass('tradeTitlecur');//一级
    $('#left_main_trance span').removeClass().addClass('trade1cur');
    $('#left_chongzhi').addClass('cur');//二级
</script></body></html>