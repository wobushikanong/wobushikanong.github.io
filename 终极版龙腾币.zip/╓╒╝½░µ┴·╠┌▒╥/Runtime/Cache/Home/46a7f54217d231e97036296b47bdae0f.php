<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title><?php echo ($sys["title"]); ?></title>
<meta name="description" content="<?php echo ($sys["des"]); ?>">
<meta name="keywords" content="<?php echo ($sys["key"]); ?>">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"> 
<link href="/Public/Home/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/jquery-ui-1.10.4.custom.min.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_index.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/css.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_css.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/jquery-1.8.2.js"></script>
<meta property="qc:admins" content="24723760626256017216375" />
</head>
<body>
	<div class="nav1 clear" id="nav1">
		<div class="nav1-sub clear">
				<ul style="float:center;">
                <style>
                	.nav1-sub ul li{ padding-right:1px !important}
                </style>	
					
						
						<li class="price white" style="font-size: 14px;"><?php echo ($sys["kgname"]); ?> : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-JZB"><?php echo (($kglast)?($kglast):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-JZBimg" src="/Public/Home/blank.png"></span></li>
						
					
						<li class="price white" style="font-size: 14px;">24小时成交: <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($count)?($count):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
						<li class="price white" style="font-size: 14px;">24小时总金额 : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($money)?($money):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                          <li class="price white" style="font-size: 14px;">矿池算力 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($allf)?($allf):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                        <li class="price white" style="font-size: 14px;">挖矿产出 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($fount)?($fount):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
				</ul>
			<div class="nav-quick">
			    <?php if(($auth["id"]) > "0"): ?><div class="rightArea">
					<span class="welcome" id="accountlink">欢迎您,&nbsp;&nbsp;UID:<?php echo ($auth["invit"]); ?>,<font color="orange">
						<?php echo ($auth["xm?$auth"]["xm:$auth"]["username"]); ?>
					</font><a class="triangle"><img src="/Public/Home/triangle.png"></a></span>
					<div class="accountpop" id="accountpop" style="display: none; cursor: pointer; ">
						<div class="mycoinmenu">
							<div class="clear">
								<ul>
									<li class="">
										<dl class="">
											<dt class="fwq trade">交易中心</dt>
											<dd><a href="<?php echo ($path); ?>/Trade/index/coin/kg" class="items1"><?php echo ($sys["kgname"]); ?>交易</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Invit">委托管理</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Kuang">认购中心</a></dd>
											<dd><a href="<?php echo ($path); ?>/Invit" class="items4">推广管理</a></dd>
										</dl>
									</li>
									<li>
										<dl class="">
											<dt class="fwq acountManage">财务管理</dt>
											<dd><a class="" href="<?php echo ($path); ?>/Fill/add">人民币充值</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Draw/add">人民币提现</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/money">个人财务</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt class="fwq basicSetting">基本设置</dt>
											<dd><a class="" href="<?php echo ($path); ?>/User/setpwd">安全中心</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/real">账户信息</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt><span class="fwq"><a href="<?php echo ($path); ?>/Account/loginout" class="lightblue2">退出</a></span> </dt>
										</dl>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<?php else: ?>
				<div class="rightArea">
					<a class="loadMessage" href="javascript:void(0);" style="float:right;" data-btn="login">登录</a>
					<a class="loadMessage" href="javascript:void(0);"style="float:right;"  data-btn="reg">注册</a>
				</div><?php endif; ?>
			</div>
		</div>
	</div>

<div class="nav_bg2" id="nav_bg2">
<div class="head clear">
	<div class="loaded-logo1">
		<a href="/"> <img alt="" src="/img/logo.png" width="200" height="80">
		</a>
	</div>
	
	<div class="accountinfo1">
		<div class="nav2-center">
			
		</div>
		
		<div class="nav-bar rr">
                 <ul>
                 <li class="cur"><a title="首页" href="/">首页</a></li>
				<li class=""><a title="交易大厅" href="<?php echo ($path); ?>/Trade">交易中心</a></li>
                <li class=""><a title="矿机中心" href="<?php echo ($path); ?>/Factory">矿机中心</a></li>
				<li class=""><a title="财务管理" href="<?php echo ($path); ?>/User/money" class="chklogin">财务中心</a></li>
				<li class=""><a href="<?php echo ($path); ?>/User/setpwd" class="items10">安全中心</a></li>
				<li class=""><a title="实时行情" href="<?php echo ($path); ?>/Market">实时行情</a></li>
				<li class=""><a title="最新动态" href="<?php echo ($path); ?>/Art/index/cate/news">最新动态</a></li>
                 </ul>
           </div>
		
	</div>
</div>
</div>
<script language="javascript">
function boxFloat(obj,elem){
	var nmove,mmove,
		d = document,
		o = d.getElementById(obj),
		s = d.getElementById(elem);
	if(!o){ return false;}
	if(!s){ return false;}
	
	s.onmouseover=function(){
		clearTimeout(nmove);
		s.style.display="block";
		s.style.cursor="pointer";
	};
	o.onmouseover=function(){
		clearTimeout(nmove);
		mmove=setTimeout(function(){
			
			s.style.display="block";
			if(obj.indexOf("ordersStatus_") != -1){
				var id = obj.substring(obj.indexOf("_")+1,obj.length);
				 jQuery("#detailOrdersStatus_"+id).load("/orders/status.html?id="+id,function (data){
				});
			}
			if(obj=="orderStatusIndex"){
				var id = document.getElementById("orderStatusId").value;
				indexOrdersStatus(id);
			}
			
		},100);
		
	};
	o.onmouseout=function(){
		clearTimeout(mmove);
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmouseout=function(){
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmousedown=function(e){
		stopBubble(e);
	};
}
boxFloat("accountlink","accountpop");
</script>
<div style="margin:0 auto; height:500px; position:relative; overflow:hidden;">
<div class="mslide">
<?php if(is_array($ad)): foreach($ad as $key=>$v): ?><img  src="<?php echo ($v["img"]); ?>" alt=""><?php endforeach; endif; ?>
</div>        
<div class="mbtn">
  <ul>
  </ul>
</div>
<?php if(($auth["id"]) > "0"): else: ?>
      <div class="loginbar-all">
       <div class="loginbar" id="loginbar">
         <div class="login-box icon_user">
           <div class="control-group">
             <label class="control-label required">登录名 <span class="required">*</span></label>
             <div class="controls">
               <input placeholder="手机/邮箱/用户名" name="username" id="LoginForm_login" type="text">
             </div>
           </div>
         </div>
         <div class="login-box icon_password">
           <div class="control-group ">
             <label class="control-label required">登陆密码 <span class="required">*</span></label>
             <div class="controls">
               <input placeholder="登陆密码" name="password" id="LoginForm_password" type="password">
             </div>
           </div>
         </div>

         <div class="btn_button240" style="margin-top:30px; width:240px;"><button type="submit" name="yt1" onClick="loginDo();">登 录&nbsp;&nbsp;&nbsp;</button></div>
         <p style="padding:15px 20px 10px 0; text-align:right;"><a href="<?php echo ($path); ?>/Account/lostpwd" class="f_aaa">忘记密码？</a>&nbsp;&nbsp;<a href="javascript:void(0);" class="f_aaa" data-btn="reg">会员注册</a></p>
       </div>
         <div class="loginbar-bg" id="loginbar-bg"></div>
     </div><?php endif; ?>
</div>

<div class="connectus">
    <div class="content">
      <ul>
        <li style="width: 200px;">
          <div>
            <a class="" href="#" target="_blank" title="关注本站新浪微博"><span class="public weibo"></span></a>
            <span class="weibosite"><a class="bold lightblack" href="#" target="_blank" title="关注本站新浪微博">新浪官方微博</a> <br><a class="fontsize-12 gray3" href="#" target="_blank" title="新浪官方微博">查看微博</a></span>
          </div>
        </li>
        <li style="width: 200px;">
          <div>
            <span class="public weixin"></span>
            <span class="weixinsite"><span class="bold">微信官方帐号</span> <br> <font style="color:#666666;">shensheng6</font></span>
          </div>
        </li>
        <li style="width: 200px;">
          <div>
            <span class="public companyQQ"></span>
            <span class="comQQbosite">
              <a class="bold lightblack" target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1223344346&amp;menu=yes&amp;site=QQ">客服QQ</a><br>
              <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1223344346&amp;menu=yes&amp;site=QQ" class="fontsize-12 gray3">1223344346</a>
            </span>
          </div>
        </li>
        <li style="width: 200px;">
          <div>
            <span class="public phoneImge"></span>
            <span class="phoneLink">
              <!--span><span class="bold">客服电话</span><span class="gray fontsize-12"> (AM9:00 - PM24:00)</span></span>
              <br-->
              <span class="fontsize-12 gray3"><span class="bold">400-009-2863</span><br>0731-8991-7889</span>
            </span>
          </div>
        </li>
        <li style="width: 200px;">
          <div style="width: 200px;">
            <span class="public QQgroup"></span>
            <span class="homePageQQGroup">
            <strong>官方④群:</strong>&nbsp;1111111111          <br><strong>官方⑤群:</strong>&nbsp;3333333333        <br>            </span>
          </div>
        </li>
      </ul>
    </div>
  </div>

 <div id="voteDiv">			

	
	<div class="container-b">
	
	<div class="selecttab1" style="margin-top: 10px;">
				<ul class="selecttab-box1">
				
					<li <?php if(($coin) == "kg"): ?>class="cur"<?php endif; ?>>
						
						<a href="<?php echo ($path); ?>/Index/index/coin/kg" class="otherBoxTitle"><?php echo ($sys["kgname"]); ?>行情</a>
						
					</li>
			</div>
	
	 <div class="market-data"><iframe src="<?php echo ($path); ?>/Chart/index/coin/<?php echo ($coin); ?>" width="100%" height="400" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></div>
	
	
	<!--公告资讯-->
	<div class="ggao" style="margin:auto; width:1000px; overflow:hidden;">
<div class="gonggao buy-list" style="float:left; visibility:top; width:330px !important;height:410px; position:relative; overflow:hidden;">
	<span  style="display:block; background:#f5f5f5; border:1px solid #CCC; width:100%; height:30px; line-height:30px; font-size:14px; color:#8A2BE2;font-weight:700">矿机购买排行</span>
    <ul style="background:#FFF; padding:10px 20px; width:100%; height:100%; list-style:disc; ">
    	<li style="font-size:14px;"><span>排名</span><span>UID</span><span>算力总额</span><span>购机数量</span></li>
    <?php if(is_array($buy)): foreach($buy as $key=>$v): ?><li style="height:34px;"><span>&nbsp;&nbsp;&nbsp;&nbsp; </span><span><?php echo ($v["id"]); ?></span><span style="color:#8A2BE2; font-weight:600;"><?php echo ($v["allsuanli"]); ?></span><span style="color:#8A2BE2; font-weight:600;">1</span></li><?php endforeach; endif; ?>
    </ul>
</div>
<div class="gonggao buy-list" style="height:410px; float:left; visibility:top; width:330px !important;  position:relative; overflow:hidden;">
	<span  style="display:block; background:#f5f5f5; border:1px solid #CCC; width:100%; height:30px; line-height:30px; font-size:14px; color:#8A2BE2;font-weight:700">推广奖励排行</span>
    <ul style="background:#FFF; padding:10px 20px; width:100%;  list-style:disc; height:100%; ">
    	<li style="font-size:14px;"><span>排名</span><span>UID</span><span>奖励来源</span><span>奖励金额</span></li>
    <?php if(is_array($jiangli)): foreach($jiangli as $key=>$v): ?><li style="height:34px;"><span>&nbsp;&nbsp;&nbsp;&nbsp; </span><span><?php echo ($v["id"]); ?></span><span style="color:#8A2BE2; font-weight:600;">购买矿机</span><span style="color:#8A2BE2; font-weight:600;"><?php echo ($v["jiangli"]); ?></span></li><?php endforeach; endif; ?>
    </ul>
</div>
<div class="gonggao buy-list" style="height:410px; float:left; visibility:top; width:330px !important;  position:relative; overflow:hidden;">
	<span  style="display:block; background:#f5f5f5; border:1px solid #CCC; width:100%; height:30px; line-height:30px; font-size:14px; color:#8A2BE2;font-weight:700">推广人数排行</span>
    <ul style="background:#FFF; padding:10px 20px; width:100%;  list-style:disc; height:100%;">
    	<li style="font-size:14px;"><span>排名</span><span>UID</span><span>推广数量</span><span></span></li>
    <?php if(is_array($tuiguang)): foreach($tuiguang as $key=>$v): ?><li style="height:34px;"><span>&nbsp;&nbsp;&nbsp;&nbsp; </span><span><?php echo ($v["id"]); ?></span><span style="color:#8A2BE2; font-weight:600;"><?php echo ($v["num"]); ?></span><span style="color:#8A2BE2; font-weight:600;"></span></li><?php endforeach; endif; ?>
    </ul>
</div>
</div>

	<div class="why-choose-ruizton">
        <div class="hd">为什么选择我们</div>
        <div class="co clearfix">
          <dl class="answer-safe">
            <dt></dt>
            <dd>银行系统级安全连接，短信身份验证机制以及分布式离线钱包备份机制； </dd>
            <dd>专业化公司运作，第三方银行资金监管，确保资金安全</dd>
          </dl>
          <dl class="answer-quick">
            <dt></dt>
            <!--dd>财付通、支付宝充值实现7*24系统实时到账；</dd-->
            <dd>人民币账户提现实现7*10人工实时支付，准实时到账；</dd>
            <dd>比特币提现7*24系统实时支付</dd>
          </dl>
          <dl class="answer-fee">
            <dt></dt>
            <dd>网银，普通汇款充值免手续费；</dd>
            <dd>免收交易手续费，全面为用户考虑</dd>
          </dl>
          <dl class="answer-capital">
            <dt></dt>
            <dd>近期将提供借款借币的比特币交易平台，无论涨跌，在本站您都能轻松获利</dd>
          </dl>
          <dl class="answer-easy">
            <dt></dt>
            <dd>重视用户体验，针对中国用户习惯定制，界面友好，方便操作</dd>
          </dl>
          <dl class="answer-service">
            <dt></dt>
<!--             <dd>7*24 400电话服务，7*24在线企业客服；</dd> -->
            <dd>VIP客户一对一免费专业咨询师服务</dd>
          </dl>
        </div>
      </div>
	
	
	
	
	<div class="row_11 zixunzhongxin">
        <div class="row_11_hd"><img alt="比特币交易网站" src="/Public/Home/zixunzhongxin.png"></div>
        <div class="row_11_co">
        
        
          <div class="unit_4 unit_4_border">
            <div class="unit_4_hd"> <a href="<?php echo ($path); ?>/Art/index/cate/about" target="_blank" class="pull-right">更多&gt;&gt;</a> <strong>关于我们</strong> </div>
            <div class="unit_4_co">
                <ul class="unstyled">
				<?php if(is_array($about)): $i = 0; $__LIST__ = $about;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="slh"><a href="<?php echo ($path); ?>/Art/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
          </div>
        
          <div class="unit_4 unit_4_border">
            <div class="unit_4_hd"> <a href="<?php echo ($path); ?>/Art/index/cate/news" target="_blank" class="pull-right">更多&gt;&gt;</a> <strong>网站公告</strong> </div>
            <div class="unit_4_co">
                <ul class="unstyled">
             		<?php if(is_array($news)): $i = 0; $__LIST__ = $news;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="slh"><a href="<?php echo ($path); ?>/Art/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
          </div>
        
          <div class="unit_4 unit_4_border">
            <div class="unit_4_hd"> <a href="<?php echo ($path); ?>/Art/index/cate/help" target="_blank" class="pull-right">更多&gt;&gt;</a> <strong>帮助中心</strong> </div>
            <div class="unit_4_co">
                <ul class="unstyled">
				<?php if(is_array($help)): $i = 0; $__LIST__ = $help;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="slh"><a href="<?php echo ($path); ?>/Art/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
                </ul>
            </div>
          </div>
        
         
          <div class="clear"></div>
        </div>
      </div>
	
	
	
	
	<div class="sitlinks">
        <div class="hd">
            <ul class="tabs">
                <li id="friendLink" class="cur"><a style="font-size: 13px;" href="javascript:void(0);">友情链接</a></li>
                <li id="qqLink" class=""><a style="font-size: 13px;" href="javascript:void(0);">交流QQ群</a></li>
            </ul>
        </div>
        <div id="friendDiv" class="bd">
        
              <a target="_blank" href="http://baidu.com/">百度</a>
        
        </div>
        <div id="qqDiv" class="bd" style="display: none;">
              <?php if(is_array($qqqun)): $i = 0; $__LIST__ = $qqqun;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><a><?php echo ($vo["name"]); ?>: <?php echo ($vo["code"]); ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        </div>
	
	
	</div>
	
<script type="text/javascript">
  function loginDo(){
        if(checkform('loginbar')){
        $.post('<?php echo ($path); ?>/Account/go',{username:$('#loginbar input[name="username"]').val(),password:$('#loginbar input[name="password"]').val()}, function(d){
          if(d.status==0){
            location.href="/?s=Home/Trade";
        }else{
          alert(d.info)
            $('[data-warn="username"]').text(d.info);
        }
      },'json');
    }
  }
	jQuery(function(){
		jQuery("#friendLink").click(function(){
			jQuery("#friendLink").addClass("cur") ;
			jQuery("#qqLink").removeClass("cur") ;
			
			jQuery("#qqDiv").hide() ;
			jQuery("#friendDiv").show() ;
		}) ;
		jQuery("#qqLink").click(function(){
			jQuery("#friendLink").removeClass("cur") ;
			jQuery("#qqLink").addClass("cur") ;
			
			jQuery("#friendDiv").hide() ;
			jQuery("#qqDiv").show() ;
		}) ;
	}) ;
  jQuery(document).ready(function() {
    
    <!--轮播-->
        var w = $(".mslide").width();
        var num=1;
        var pln=$(".mslide img").length;

        $(".mslide").find("img").css("width",w);
        $(".mslide").css("width",w*pln);
        carousel();
        initbtn();
        $(".mbtn ul li").on("click",function(){ 
            num=$(this).index();
            clearInterval(tid);
            switchPic(".mslide",num);
            num++;
            carousel();
        });
        function carousel(){
            tid=setInterval(function(){
            if(num>pln-1){
                num=0;
            }
            switchPic(".mslide",num);
            num++;
            },9000);
        }
        function initbtn(){
            for(i=0;i<pln;i++){
                $(".mbtn").children("ul").append("<li></li>");
            }
            $(".mbtn ul li").first().addClass("on");
        }
        function switchPic(ename,num){
            $(ename).animate({"marginLeft":num*-w},2000);
            $(".mbtn ul li").removeClass("on");
            $(".mbtn ul li").eq(num).addClass("on");
        }
    });
	</script>

<link href="/Public/Home/lrtk.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/cs_q.js"></script>
<!-- 代码 开始 -->
<div id="qq_icon"></div>

<div id="allFooter">
<div class="foot clear" id="footer">
		<ul> 
			<li><a href="<?php echo ($path); ?>/Art/index/cate/about">关于我们</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/help">帮助中心</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/news">网站公告</a> - </li>
		</ul>
		<div class="version gray">
			<?php echo ($sys["icp"]); ?>
			<br>
		</div>
	</div>
	<iframe src="" id="ifs" width="0" height="0" style="display:none"></iframe>
	<div class="okcoinPop" id="okcoinPop" style="display: none; ">
	    <iframe scrolling="no" style="border:0;height:100%;_height:255px;width:100%;left:0;top:0;z-index:-1;position:absolute;"></iframe>
		<div class="dialog_content" id="dialog_content">
			<div id="conten">
				<div class="selecttab">
					<ul class="selecttab-box">
						<li id="loginLi" class="cur">
							<a href="javascript:void(0);" data-btn="login" title="登录">登&nbsp;录</a>
						</li>
						<li id="regLi" class="">
							<a href="javascript:void(0);" data-btn="reg" title="注册">注&nbsp;册</a>
						</li>
					</ul>
					<a href="javascript:void(0);" data-btn="close" class="dialog1_closed" title="关闭">
					</a>
				</div>
				<div id="loginDialog" class="dialog_body" style="display: block; ">
					<table>
						<tbody>
							<tr>
								<th width="90">
									<label for="username">用户名:</label>
								</th>
								<td width="200">
									<input id="username" class="txt" type="text" name="username">
								</td>
								<td>
									<span id="usernamewarn" class="warn">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							<tr>
								<th>
									<label for="password">
										密&nbsp;&nbsp;&nbsp;&nbsp;码:
									</label>
								</th>
								<td>
									<input id="password" class="txt" type="password" name="password">
								</td>
								<td>
									<span id="passwordwarn" class="warn">6－16位字符</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="" style="height:25px;">
						<span id="loginTips" class="orange" style="display:none;height:25px;padding-left:90px;">
							用户名或密码错误
						</span>
					</div>
					<div class="submit-link">
						<a class="button-dialog" id="loginbtn" type="submit" value="登录" title="登录">登录</a><span class="gray" style="dispaly:inline-block;"><a id="" title="忘记密码" href="<?php echo ($path); ?>/Account/lostpwd">忘记密码</a></span>				
					</div>
					<div class="submit-link padding-top"> 
						还没有账号?<a href="javascript:void(0);" data-btn="reg" title="立即注册" class="red">&nbsp;立即注册</a>
					</div>		
				</div>
				<!-- 注册 -->
				<div id="regDialog" class="dialog_body" style="display: none; ">
					<span style="color:red;padding-left: 20px;"></span>
					<input type="hidden" id="regType" value="1">
					<div class="center">
						<span id="regTips" class="orange" style="display:none;"></span>
					</div>
					<table>
						<tbody>
						
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>用户名:
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="username" tabindex="1">		
								</td>
								<td>
									<!--<span>用于登录，请认真填写</span>-->
									<span data-warn="username">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>登录密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="password" tabindex="2">		
								</td>
								<td>
									<span data-warn="password">6－16位字符</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repassword" tabindex="3">	
								</td>
								<td>
									<span data-warn="repassword">请重新输入密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>支付密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="paypwd" tabindex="4">		
								</td>
								<td>
									<span data-warn="paypwd">6－16位字符。</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repaypwd" tabindex="5">	
								</td>
								<td>
									<span data-warn="repaypwd">请重新输入支付密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>推荐人ID：
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="invitup" value="<?php echo ($invit); ?>" tabindex="6">	
								</td>
								<td>
									<span data-warn="invitup">推荐你注册的用户ID，没有可以留空</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="register-link">
						<a id="regbtn" class="button-dialog" type="submit" value="确定注册" title="确定注册" tabindex="4">确定注册</a>
						<span>已经注册?<a href="javascript:void(0);" data-btn="login" title="快速登录"> 快速登录</a></span>
					</div>	
					<div class="submit-link">
						<label class="register" for="agree" title="">
							<input id="agree" type="hidden" value="1" checked="" onclick="javascript:termsService();">
						</label>
					</div>
				</div>
			</div>

			<!-- 注册后邮箱提示 -->
			<div class="emailSucess" style="display:none;" id="emailSucess">
				<a href="javascript:closelogin();" class="dialogClosed" title="关闭"></a>
				<div class="emailSucessLeft">
				</div>
				<div class="emailSucessRight">
					<span class="blue fontsize-14 bold">恭喜您注册成功</span>
					<br>
					<span>激活邮件已经发送到您的邮箱：<span id="emailSpan" class="fred fontsize-14 bold"></span></span>
					<br>
					<span class="verifySpan"><span class=""><a class="button-dialog" href="/trade/btc.html">进入交易中心</a></span><span class="gray fontsize-12">或</span><span class="">进入邮箱激活（方便您以后找回密码）</span></span>
				</div>
			</div>
		</div>
	</div>
</div>   
</div><ul class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="display: none; "></ul><div id="dialogBoxShadow" style="position: absolute; top: 0px; left: 0px; z-index: 100; background-color: rgb(0, 0, 0); width: 100%; height: 2051px; background-position: initial initial; background-repeat: initial initial;display:none; filter:alpha(opacity=40);  
      -moz-opacity:0.4;  
      -khtml-opacity: 0.4;  
      opacity: 0.4; "></div></body></html>

<script type="text/javascript" src="/Public/Home/checkform.js"></script>
<script language="javascript">
$(document).ready(function(){
	<?php if(($notlogin) == "1"): ?>$('#okcoinPop').show();
	$('#dialogBoxShadow').show();<?php endif; ?>

    $('[data-btn="login"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").show();
		$("#regDialog").hide();
		$("#regLi").removeClass('cur');
		$("#loginLi").addClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="reg"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").hide();
		$("#regDialog").show();
		$("#regLi").addClass('cur');
		$("#loginLi").removeClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="close"]').click(function(){
		$('#okcoinPop').hide();
	    $('#dialogBoxShadow').hide();
		$('#loginDialog input').val('');
		$('#regDialog input').val('');
	});

    $('#loginbtn').click(function(){
        if(checkform('loginDialog')){
		    $.post('<?php echo ($path); ?>/Account/go',{username:$('#loginDialog input[name="username"]').val(),password:$('#loginDialog input[name="password"]').val()}, function(d){
			    if(d.status==0){
				    location.href="<?php echo (($back_url)?($back_url):'/'); ?>";
				}else{
					alert(d.info)
				    $('[data-warn="username"]').text(d.info);
				}
			},'json');
		}
    });

	$('#regbtn').click(function(){
        if(checkform('regDialog')){
			$.post('<?php echo ($path); ?>/Account/insert',{username:$('#regDialog input[name="username"]').val(),password:$('#regDialog input[name="password"]').val(),repassword:$('#regDialog input[name="repassword"]').val(),paypwd:$('#regDialog input[name="paypwd"]').val(),repaypwd:$('#regDialog input[name="repaypwd"]').val(),code:$('#regDialog input[name="checkcode"]').val(),invitup:$('#regDialog input[name="invitup"]').val()},function(d){
			    if(d.status==0){
					alert(d.info);
				    $('#okcoinPop').show();
					$('#dialogBoxShadow').show();
					$("#loginDialog").show();
					$("#regDialog").hide();
					$("#regLi").removeClass('cur');
					$("#loginLi").addClass('cur');
					$("input[name='username']").focus();
				}else if(d.status==2){
				    alert(d.info);
				}else{
				    alert(d.info);
				}
			},'json');
		}
    });
});
</script>