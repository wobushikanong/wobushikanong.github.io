<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title><?php echo ($sys["title"]); ?></title>
<meta name="description" content="<?php echo ($sys["des"]); ?>">
<meta name="keywords" content="<?php echo ($sys["key"]); ?>">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"> 
<link href="/Public/Home/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/jquery-ui-1.10.4.custom.min.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_index.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/css.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_css.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/jquery-1.8.2.js"></script>
<meta property="qc:admins" content="24723760626256017216375" />
</head>
<body>
	<div class="nav1 clear" id="nav1">
		<div class="nav1-sub clear">
				<ul style="float:center;">
                <style>
                	.nav1-sub ul li{ padding-right:1px !important}
                </style>	
					
						
						<li class="price white" style="font-size: 14px;"><?php echo ($sys["kgname"]); ?> : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-JZB"><?php echo (($kglast)?($kglast):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-JZBimg" src="/Public/Home/blank.png"></span></li>
						
					
						<li class="price white" style="font-size: 14px;">24小时成交: <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($count)?($count):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
						<li class="price white" style="font-size: 14px;">24小时总金额 : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($money)?($money):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                          <li class="price white" style="font-size: 14px;">矿池算力 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($allf)?($allf):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                        <li class="price white" style="font-size: 14px;">挖矿产出 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($fount)?($fount):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
				</ul>
			<div class="nav-quick">
			    <?php if(($auth["id"]) > "0"): ?><div class="rightArea">
					<span class="welcome" id="accountlink">欢迎您,&nbsp;&nbsp;UID:<?php echo ($auth["invit"]); ?>,<font color="orange">
						<?php echo ($auth["xm?$auth"]["xm:$auth"]["username"]); ?>
					</font><a class="triangle"><img src="/Public/Home/triangle.png"></a></span>
					<div class="accountpop" id="accountpop" style="display: none; cursor: pointer; ">
						<div class="mycoinmenu">
							<div class="clear">
								<ul>
									<li class="">
										<dl class="">
											<dt class="fwq trade">交易中心</dt>
											<dd><a href="<?php echo ($path); ?>/Trade/index/coin/kg" class="items1"><?php echo ($sys["kgname"]); ?>交易</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Invit">委托管理</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Kuang">认购中心</a></dd>
											<dd><a href="<?php echo ($path); ?>/Invit" class="items4">推广管理</a></dd>
										</dl>
									</li>
									<li>
										<dl class="">
											<dt class="fwq acountManage">财务管理</dt>
											<dd><a class="" href="<?php echo ($path); ?>/Fill/add">人民币充值</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Draw/add">人民币提现</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/money">个人财务</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt class="fwq basicSetting">基本设置</dt>
											<dd><a class="" href="<?php echo ($path); ?>/User/setpwd">安全中心</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/real">账户信息</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt><span class="fwq"><a href="<?php echo ($path); ?>/Account/loginout" class="lightblue2">退出</a></span> </dt>
										</dl>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<?php else: ?>
				<div class="rightArea">
  <a href="#" onclick='toQzoneLogin()'><img src="__PUBLIC__/Home/qq_login.png"  style=" float:right; margin-left:10px"></a>
					<a class="loadMessage" href="javascript:void(0);" style="float:right;" data-btn="login">登录</a>
					<a class="loadMessage" href="javascript:void(0);"style="float:right;"  data-btn="reg">注册</a>
				</div><?php endif; ?>
			</div>
		</div>
	</div>
   <script type="text/javascript">
            var childWindow;
            function toQzoneLogin()
            {
                window.location.href="index.php/Home/Account/qqlogin";
            } 
            
            function closeChildWindow()
            {
                childWindow.close();
            }
        </script>

<div class="nav_bg2" id="nav_bg2">
<div class="head clear">
	<div class="loaded-logo1">
		<a href="/"> <img alt="" src="/img/logo.png" width="200" height="80">
		</a>
	</div>
	
	<div class="accountinfo1">
		<div class="nav2-center">
			
		</div>
		
		<div class="nav-bar rr">
                 <ul>
                 <li class="cur"><a title="首页" href="/">首页</a></li>
				<li class=""><a title="交易大厅" href="<?php echo ($path); ?>/Trade">交易中心</a></li>
                <li class=""><a title="矿机中心" href="<?php echo ($path); ?>/Factory">矿机中心</a></li>
				<li class=""><a title="财务管理" href="<?php echo ($path); ?>/User/money" class="chklogin">财务中心</a></li>
				<li class=""><a href="<?php echo ($path); ?>/User/setpwd" class="items10">安全中心</a></li>
				<li class=""><a title="实时行情" href="<?php echo ($path); ?>/Market">实时行情</a></li>
				<li class=""><a title="最新动态" href="<?php echo ($path); ?>/Art/index/cate/news">最新动态</a></li>
                 </ul>
           </div>
		
	</div>
</div>
</div>
<script language="javascript">
function boxFloat(obj,elem){
	var nmove,mmove,
		d = document,
		o = d.getElementById(obj),
		s = d.getElementById(elem);
	if(!o){ return false;}
	if(!s){ return false;}
	
	s.onmouseover=function(){
		clearTimeout(nmove);
		s.style.display="block";
		s.style.cursor="pointer";
	};
	o.onmouseover=function(){
		clearTimeout(nmove);
		mmove=setTimeout(function(){
			
			s.style.display="block";
			if(obj.indexOf("ordersStatus_") != -1){
				var id = obj.substring(obj.indexOf("_")+1,obj.length);
				 jQuery("#detailOrdersStatus_"+id).load("/orders/status.html?id="+id,function (data){
				});
			}
			if(obj=="orderStatusIndex"){
				var id = document.getElementById("orderStatusId").value;
				indexOrdersStatus(id);
			}
			
		},100);
		
	};
	o.onmouseout=function(){
		clearTimeout(mmove);
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmouseout=function(){
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmousedown=function(e){
		stopBubble(e);
	};
}
boxFloat("accountlink","accountpop");
</script>
<div class="marketArea clear">
	<div class="leftMenu">
  <div class="bor">
	<div class="tradeTitlecur">
		<span class="trade1cur">交易中心</span>
	</div>
	<ul>
		<li class="cur"><a href="<?php echo ($path); ?>/Trade/index/coin/kg" class="i1"><?php echo ($sys["kgname"]); ?>交易</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Trade/buys" class="items3">委托管理</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Invit" class="items4">推广管理</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Kuang" class="items4">认购中心</a></li>
        <li class=""><a href="<?php echo ($path); ?>/Factory" class="items4">矿机中心</a></li>
		<!--<li class=""><a href="<?php echo ($path); ?>/Kuang/companyfen" class="items4">公司分红</a></li>-->
	</ul>
  </div>
  <div class="bor">
	<div class="tradeTitle">
		<span class="acountManage1">财务管理</span>
	</div>
	<ul>
		<li class=""><a href="<?php echo ($path); ?>/Fill/add" class="items5">人民币充值</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Draw/add" class="items6">人民币提现</a></li>
		<li class=""><a href="<?php echo ($path); ?>/User/money" class="items5">个人财务</a></li>
	</ul>
  </div>
  <div class="bor">
	<div class="tradeTitle">
		<span class="basicSetting1">基本设置</span>
	</div>
	<ul>
	    <li class=""><a href="<?php echo ($path); ?>/User/setpwd" class="items10">安全中心</a></li>
		<li class=""><a href="<?php echo ($path); ?>/User/real" class="items11">账户信息</a></li>
	</ul>
  </div>

</div>
	<div class="rightArea">
		<div class="buysellTitle">
              	<div class="selecttab1">
				<ul class="selecttab-box1">
					<li class="">
						<a href="<?php echo ($path); ?>/Kuang" class="otherBoxTitle">认购工厂</a>
					</li>
					<li class="cur">
						<a href="<?php echo ($path); ?>/Buy/all" class="otherBoxTitle"><?php echo ($sys["kgname"]); ?>列表</a>
					</li>
					<li class="">
						<a href="<?php echo ($path); ?>/Kuang/company" class="otherBoxTitle">组建公司</a>
					</li>
				</ul>
				<input type="hidden" value="0" id="playSymobl">
			</div>					
		</div>
		<div style="margin-top: 3px;" class="entrustTen lasttenorder">
			<div class="coinBoxBody">
				<table width="100%">
					<tbody>
						<tr>
							<th width="100">数量</th>
							<th width="100">每日产量</th>
							<th width="100">创建时间</th>
						</tr>
                        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr><td><?php echo ($vo["num"]); ?></td><td><?php echo ($vo["ksper"]); ?></td><td><?php echo (date("Y-m-d",$vo["ctime"])); ?></td><?php endforeach; endif; else: echo "$empty" ;endif; ?>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="page">
				<ul>
				<li><a href="<?php echo ($path); ?>/Buy/all/page/1">首页</a></li>
				<li><a href="<?php echo ($path); ?>/Buy/all/page/<?php echo ($page-1); ?>">上一页</a></li>
				<li><a href="<?php echo ($path); ?>/Buy/all/page/<?php echo ($page+1); ?>">下一页</a></li>
				<li><a href="<?php echo ($path); ?>/Buy/all/page/<?php echo ($page_num); ?>">尾页</a></li>
				</ul>
			</div>
		</div>
    </div>
</div>

<link href="/Public/Home/lrtk.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/cs_q.js"></script>
<!-- 代码 开始 -->
<div id="qq_icon"></div>
<div id="cs_online">
    <ul class='qq_context'>
        <li>
        <span class='span_t'>在线客服01：</span>
        <span class='qq_num'>770757687</span>
        </li>
        <li>
        <span class='span_t'>在线客服02：</span>
        <span class='qq_num'>5406544</span>
        </li>
        <li>
        <span class='span_t'>在线客服03：</span>
        <span class='qq_num'>2832181715</span>
        </li>
        <li>
        <span class='span_t'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QQ群01：</span>
        <span class='qq_num'><a target="_blank" href="" id="qqgroup1"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="" title=""></a></span>
        </li>
        <li>
        <span class='span_t'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QQ群02：</span>
        <span class='qq_num'><a target="_blank" href="" id="qqgroup2"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="" title=""></a></span>
        </li>
     </ul>
</div>
<script type="text/javascript">
	myEvent(window,'load',function(){
		dealy('qq_icon',1);						//1秒后显示QQ图标，默认为1秒，可自行设置
		settop('qq_icon','cs_online',150);		//设置在线客服的高度，默认150，可自行设置
		var span_q = getbyClass('cs_online','qq_num');
		setqq(span_q,['770757687','5406544','2832181715']);		//填写5个QQ号码 //此处因为修改QQ个数为3 在js文件中有修改 第一个参数已经没有实际意义
		click_fn('qq_icon','cs_online');
	});
	$(document).ready(function(e) {
        setqqgroup("http://jq.qq.com/?_wv=1027&k=cLwuRf","http://jq.qq.com/?_wv=1027&k=bIAjsV","QQ群01","QQ群02");
		//参数可以在http://qun.qq.com/join.html得到  也可以直接替换上面的a标签  url里的数字不是群号 url里的数字不是群号 url里的数字不是群号
    });
	
</script>
<div id="allFooter">
<div class="foot clear" id="footer">
		<ul> 
			<li><a href="<?php echo ($path); ?>/Art/index/cate/about">关于我们</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/help">帮助中心</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/news">网站公告</a> - </li>
		</ul>
		<div class="version gray">
			<?php echo ($sys["icp"]); ?>
			<br>
		</div>
	</div>
	<iframe src="" id="ifs" width="0" height="0" style="display:none"></iframe>
	<div class="okcoinPop" id="okcoinPop" style="display: none; ">
	    <iframe scrolling="no" style="border:0;height:100%;_height:255px;width:100%;left:0;top:0;z-index:-1;position:absolute;"></iframe>
		<div class="dialog_content" id="dialog_content">
			<div id="conten">
				<div class="selecttab">
					<ul class="selecttab-box">
						<li id="loginLi" class="cur">
							<a href="javascript:void(0);" data-btn="login" title="登录">登&nbsp;录</a>
						</li>
						<li id="regLi" class="">
							<a href="javascript:void(0);" data-btn="reg" title="注册">注&nbsp;册</a>
						</li>
					</ul>
					<a href="javascript:void(0);" data-btn="close" class="dialog1_closed" title="关闭">
					</a>
				</div>
				<div id="loginDialog" class="dialog_body" style="display: block; ">
					<table>
						<tbody>
							<tr>
								<th width="90">
									<label for="username">用户名:</label>
								</th>
								<td width="200">
									<input id="username" class="txt" type="text" name="username">
								</td>
								<td>
									<span id="usernamewarn" class="warn">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							<tr>
								<th>
									<label for="password">
										密&nbsp;&nbsp;&nbsp;&nbsp;码:
									</label>
								</th>
								<td>
									<input id="password" class="txt" type="password" name="password">
								</td>
								<td>
									<span id="passwordwarn" class="warn">6－16位字符</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="" style="height:25px;">
						<span id="loginTips" class="orange" style="display:none;height:25px;padding-left:90px;">
							用户名或密码错误
						</span>
					</div>
					<div class="submit-link">
						<a class="button-dialog" id="loginbtn" type="submit" value="登录" title="登录">登录</a><span class="gray" style="dispaly:inline-block;"><a id="" title="忘记密码" href="<?php echo ($path); ?>/Account/lostpwd">忘记密码</a></span>				
					</div>
					<div class="submit-link padding-top"> 
						还没有账号?<a href="javascript:void(0);" data-btn="reg" title="立即注册" class="red">&nbsp;立即注册</a>
					</div>		
				</div>
				<!-- 注册 -->
				<div id="regDialog" class="dialog_body" style="display: none; ">
					<span style="color:red;padding-left: 20px;"></span>
					<input type="hidden" id="regType" value="1">
					<div class="center">
						<span id="regTips" class="orange" style="display:none;"></span>
					</div>
					<table>
						<tbody>
						
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>用户名:
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="username" tabindex="1">		
								</td>
								<td>
									<!--<span>用于登录，请认真填写</span>-->
									<span data-warn="username">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>登录密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="password" tabindex="2">		
								</td>
								<td>
									<span data-warn="password">6－16位字符</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repassword" tabindex="3">	
								</td>
								<td>
									<span data-warn="repassword">请重新输入密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>支付密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="paypwd" tabindex="4">		
								</td>
								<td>
									<span data-warn="paypwd">6－16位字符。</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repaypwd" tabindex="5">	
								</td>
								<td>
									<span data-warn="repaypwd">请重新输入支付密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>推荐人ID：
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="invitup" value="<?php echo ($invit); ?>" tabindex="6">	
								</td>
								<td>
									<span data-warn="invitup">推荐你注册的用户ID，没有可以留空</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="register-link">
						<a id="regbtn" class="button-dialog" type="submit" value="确定注册" title="确定注册" tabindex="4">确定注册</a>
						<span>已经注册?<a href="javascript:void(0);" data-btn="login" title="快速登录"> 快速登录</a></span>
					</div>	
					<div class="submit-link">
						<label class="register" for="agree" title="">
							<input id="agree" type="hidden" value="1" checked="" onclick="javascript:termsService();">
						</label>
					</div>
				</div>
			</div>

			<!-- 注册后邮箱提示 -->
			<div class="emailSucess" style="display:none;" id="emailSucess">
				<a href="javascript:closelogin();" class="dialogClosed" title="关闭"></a>
				<div class="emailSucessLeft">
				</div>
				<div class="emailSucessRight">
					<span class="blue fontsize-14 bold">恭喜您注册成功</span>
					<br>
					<span>激活邮件已经发送到您的邮箱：<span id="emailSpan" class="fred fontsize-14 bold"></span></span>
					<br>
					<span class="verifySpan"><span class=""><a class="button-dialog" href="/trade/btc.html">进入交易中心</a></span><span class="gray fontsize-12">或</span><span class="">进入邮箱激活（方便您以后找回密码）</span></span>
				</div>
			</div>
		</div>
	</div>
</div>   
</div><ul class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="display: none; "></ul><div id="dialogBoxShadow" style="position: absolute; top: 0px; left: 0px; z-index: 100; background-color: rgb(0, 0, 0); width: 100%; height: 2051px; background-position: initial initial; background-repeat: initial initial;display:none; filter:alpha(opacity=40);  
      -moz-opacity:0.4;  
      -khtml-opacity: 0.4;  
      opacity: 0.4; "></div></body></html>

<script type="text/javascript" src="/Public/Home/checkform.js"></script>
<script language="javascript">
$(document).ready(function(){
	<?php if(($notlogin) == "1"): ?>$('#okcoinPop').show();
	$('#dialogBoxShadow').show();<?php endif; ?>

    $('[data-btn="login"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").show();
		$("#regDialog").hide();
		$("#regLi").removeClass('cur');
		$("#loginLi").addClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="reg"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").hide();
		$("#regDialog").show();
		$("#regLi").addClass('cur');
		$("#loginLi").removeClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="close"]').click(function(){
		$('#okcoinPop').hide();
	    $('#dialogBoxShadow').hide();
		$('#loginDialog input').val('');
		$('#regDialog input').val('');
	});

    $('#loginbtn').click(function(){
        if(checkform('loginDialog')){
		    $.post('<?php echo ($path); ?>/Account/go',{username:$('#loginDialog input[name="username"]').val(),password:$('#loginDialog input[name="password"]').val()}, function(d){
			    if(d.status==0){
				    location.href="<?php echo (($back_url)?($back_url):'/'); ?>";
				}else{
					alert(d.info)
				    $('[data-warn="username"]').text(d.info);
				}
			},'json');
		}
    });

	$('#regbtn').click(function(){
        if(checkform('regDialog')){
			$.post('<?php echo ($path); ?>/Account/insert',{username:$('#regDialog input[name="username"]').val(),password:$('#regDialog input[name="password"]').val(),repassword:$('#regDialog input[name="repassword"]').val(),paypwd:$('#regDialog input[name="paypwd"]').val(),repaypwd:$('#regDialog input[name="repaypwd"]').val(),code:$('#regDialog input[name="checkcode"]').val(),invitup:$('#regDialog input[name="invitup"]').val()},function(d){
			    if(d.status==0){
					alert(d.info);
				    $('#okcoinPop').show();
					$('#dialogBoxShadow').show();
					$("#loginDialog").show();
					$("#regDialog").hide();
					$("#regLi").removeClass('cur');
					$("#loginLi").addClass('cur');
					$("input[name='username']").focus();
				}else if(d.status==2){
				    alert(d.info);
				}else{
				    alert(d.info);
				}
			},'json');
		}
    });
});
</script>