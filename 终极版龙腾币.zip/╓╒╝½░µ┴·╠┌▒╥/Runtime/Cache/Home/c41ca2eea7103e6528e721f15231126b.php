<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>支付宝在线支付</title>
</head>
<body>
<form id="alipaysubmit" action="https://shenghuo.alipay.com/send/payment/fill.htm" method="post" accept-charset="gbk">
<input name="title" type="hidden" value="<?php echo ($tradeno); ?>" />
<input name="optEmail" type="hidden" value="szsbpbwlkj@126.com" />
<input name="payAmount" type="hidden" value="<?php echo ($num); ?>" />
<input name="cellphone" type="hidden" value="<?php echo ($cellphone); ?>" />
<input name="memo" type="hidden" value="请不要修改【付款说明】,否则实现不了自动到账！" />
<input name="ok" type="submit" value="正在处理中" />
</form>
<script>document.forms['alipaysubmit'].submit();</script>
</body>
</html>