<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
<title><?php echo ($sys["title"]); ?></title>
<meta name="description" content="<?php echo ($sys["des"]); ?>">
<meta name="keywords" content="<?php echo ($sys["key"]); ?>">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"> 
<link href="/Public/Home/coincommon_v1.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/jquery-ui-1.10.4.custom.min.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_index.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/css.css" rel="stylesheet" type="text/css" media="screen, projection">
<link href="/Public/Home/new_css.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/jquery-1.8.2.js"></script>
<meta property="qc:admins" content="24723760626256017216375" />
</head>
<body>
	<div class="nav1 clear" id="nav1">
		<div class="nav1-sub clear">
				<ul style="float:center;">
                <style>
                	.nav1-sub ul li{ padding-right:1px !important}
                </style>	
					
						
						<li class="price white" style="font-size: 14px;"><?php echo ($sys["kgname"]); ?> : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-JZB"><?php echo (($kglast)?($kglast):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-JZBimg" src="/Public/Home/blank.png"></span></li>
						
					
						<li class="price white" style="font-size: 14px;">24小时成交: <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($count)?($count):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
						<li class="price white" style="font-size: 14px;">24小时总金额 : <b><span style="color: #FF4000;font-size: 14px;">￥</span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($money)?($money):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                          <li class="price white" style="font-size: 14px;">矿池算力 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($allf)?($allf):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
                        <li class="price white" style="font-size: 14px;">挖矿产出 : <b><span style="color: #FF4000;font-size: 14px;"></span><span style="color: #FF4000;font-size: 14px;" id="LastDealPrize-ZJB"><?php echo (($fount)?($fount):0); ?></span></b><span>&nbsp;<img id="LastDealPrize-ZJBimg" src="/Public/Home/blank.png"></span></li>
				</ul>
			<div class="nav-quick">
			    <?php if(($auth["id"]) > "0"): ?><div class="rightArea">
					<span class="welcome" id="accountlink">欢迎您,&nbsp;&nbsp;UID:<?php echo ($auth["invit"]); ?>,<font color="orange">
						<?php echo ($auth["xm?$auth"]["xm:$auth"]["username"]); ?>
					</font><a class="triangle"><img src="/Public/Home/triangle.png"></a></span>
					<div class="accountpop" id="accountpop" style="display: none; cursor: pointer; ">
						<div class="mycoinmenu">
							<div class="clear">
								<ul>
									<li class="">
										<dl class="">
											<dt class="fwq trade">交易中心</dt>
											<dd><a href="<?php echo ($path); ?>/Trade/index/coin/kg" class="items1"><?php echo ($sys["kgname"]); ?>交易</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Invit">委托管理</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Kuang">认购中心</a></dd>
											<dd><a href="<?php echo ($path); ?>/Invit" class="items4">推广管理</a></dd>
										</dl>
									</li>
									<li>
										<dl class="">
											<dt class="fwq acountManage">财务管理</dt>
											<dd><a class="" href="<?php echo ($path); ?>/Fill/add">人民币充值</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/Draw/add">人民币提现</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/money">个人财务</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt class="fwq basicSetting">基本设置</dt>
											<dd><a class="" href="<?php echo ($path); ?>/User/setpwd">安全中心</a></dd>
											<dd><a class="" href="<?php echo ($path); ?>/User/real">账户信息</a></dd>
										</dl>
									</li>
									<li class="">
										<dl class="">
											<dt><span class="fwq"><a href="<?php echo ($path); ?>/Account/loginout" class="lightblue2">退出</a></span> </dt>
										</dl>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<?php else: ?>
				<div class="rightArea">
					<a class="loadMessage" href="javascript:void(0);" style="float:right;" data-btn="login">登录</a>
					<a class="loadMessage" href="javascript:void(0);"style="float:right;"  data-btn="reg">注册</a>
				</div><?php endif; ?>
			</div>
		</div>
	</div>

<div class="nav_bg2" id="nav_bg2">
<div class="head clear">
	<div class="loaded-logo1">
		<a href="/"> <img alt="" src="/img/logo.png" width="200" height="80">
		</a>
	</div>
	
	<div class="accountinfo1">
		<div class="nav2-center">
			
		</div>
		
		<div class="nav-bar rr">
                 <ul>
                 <li class="cur"><a title="首页" href="/">首页</a></li>
				<li class=""><a title="交易大厅" href="<?php echo ($path); ?>/Trade">交易中心</a></li>
                <li class=""><a title="矿机中心" href="<?php echo ($path); ?>/Factory">矿机中心</a></li>
				<li class=""><a title="财务管理" href="<?php echo ($path); ?>/User/money" class="chklogin">财务中心</a></li>
				<li class=""><a href="<?php echo ($path); ?>/User/setpwd" class="items10">安全中心</a></li>
				<li class=""><a title="实时行情" href="<?php echo ($path); ?>/Market">实时行情</a></li>
				<li class=""><a title="最新动态" href="<?php echo ($path); ?>/Art/index/cate/news">最新动态</a></li>
                 </ul>
           </div>
		
	</div>
</div>
</div>
<script language="javascript">
function boxFloat(obj,elem){
	var nmove,mmove,
		d = document,
		o = d.getElementById(obj),
		s = d.getElementById(elem);
	if(!o){ return false;}
	if(!s){ return false;}
	
	s.onmouseover=function(){
		clearTimeout(nmove);
		s.style.display="block";
		s.style.cursor="pointer";
	};
	o.onmouseover=function(){
		clearTimeout(nmove);
		mmove=setTimeout(function(){
			
			s.style.display="block";
			if(obj.indexOf("ordersStatus_") != -1){
				var id = obj.substring(obj.indexOf("_")+1,obj.length);
				 jQuery("#detailOrdersStatus_"+id).load("/orders/status.html?id="+id,function (data){
				});
			}
			if(obj=="orderStatusIndex"){
				var id = document.getElementById("orderStatusId").value;
				indexOrdersStatus(id);
			}
			
		},100);
		
	};
	o.onmouseout=function(){
		clearTimeout(mmove);
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmouseout=function(){
		nmove=setTimeout(function(){s.style.display="none";},500);
	};
	s.onmousedown=function(e){
		stopBubble(e);
	};
}
boxFloat("accountlink","accountpop");
</script>
<link href="/Public/Home/trade.css" rel="stylesheet" type="text/css">
<style type="text/css">
body,td,th {
	color: #000;
}
</style>
<div class="marketArea clear">
	<div class="leftMenu">
  <div class="bor">
	<div class="tradeTitlecur">
		<span class="trade1cur">交易中心</span>
	</div>
	<ul>
		<li class="cur"><a href="<?php echo ($path); ?>/Trade/index/coin/kg" class="i1"><?php echo ($sys["kgname"]); ?>交易</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Trade/buys" class="items3">委托管理</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Invit" class="items4">推广管理</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Kuang" class="items4">认购中心</a></li>
        <li class=""><a href="<?php echo ($path); ?>/Factory" class="items4">矿机中心</a></li>
		<!--<li class=""><a href="<?php echo ($path); ?>/Kuang/companyfen" class="items4">公司分红</a></li>-->
	</ul>
  </div>
  <div class="bor">
	<div class="tradeTitle">
		<span class="acountManage1">财务管理</span>
	</div>
	<ul>
		<li class=""><a href="<?php echo ($path); ?>/Fill/add" class="items5">人民币充值</a></li>
		<li class=""><a href="<?php echo ($path); ?>/Draw/add" class="items6">人民币提现</a></li>
		<li class=""><a href="<?php echo ($path); ?>/User/money" class="items5">个人财务</a></li>
	</ul>
  </div>
  <div class="bor">
	<div class="tradeTitle">
		<span class="basicSetting1">基本设置</span>
	</div>
	<ul>
	    <li class=""><a href="<?php echo ($path); ?>/User/setpwd" class="items10">安全中心</a></li>
		<li class=""><a href="<?php echo ($path); ?>/User/real" class="items11">账户信息</a></li>
	</ul>
  </div>

</div>
	<div class="rightArea">
		<div class="buysellTitle">
            <div class="right-top">
				<div class="r-top-l"></div>
				<div class="r-top-r">
                	<div class="left-b">
                        <div class="r-t">
                            <ul>
                                <li class="c1">可用人民币：<span>￥<?php echo (($auth["rmb"])?($auth["rmb"]):0); ?></span></li>
								<li class="c1">可用<?php echo ($unit); ?>：<span>฿<?php echo (($auth["xnb"])?($auth["xnb"]):0); ?></span></li>
								<li class="c1">冻结人民币：<span>￥<?php echo (($auth["rmb_frozen"])?($auth["rmb_frozen"]):0); ?></span></li>
								<li class="c1">冻结<?php echo ($unit); ?>：<span>฿<?php echo (($auth["xnb_frozen"])?($auth["xnb_frozen"]):0); ?></span></li>
                                <div style="clear:both"></div> 
                            </ul>
                        </div>
                    </div>
                    <div style="clear:both;"></div>
				</div>
				<div style="clear:both"></div>  
			</div>
				
			<div class="selecttab1">
				<ul class="selecttab-box1">
					<li class="tab cur" id="buytab">
					<a href="javascript:void(0);" class="buyBtcLtc">买入<?php echo ($unit); ?></a>
					</li>
					<li class="tab" id="selltab">
					<a href="javascript:void(0);" class="sellBtcLtc tab">卖出<?php echo ($unit); ?></a>
					</li>
					<li class="refresh">
						<div class="div1">
							<span>刷新时间 : &nbsp;</span> <select id="updateSecond">
								<option value="1">1s</option>
								<option value="2">2s</option>
								<option value="3">3s</option>
								<option value="5">5s</option>
								<option value="10">10s</option>
								<option value="30">30s</option>
								<option value="60">60s</option>
							</select>
						</div>
						<div class="div2">
							<span style="">倒计时 :&nbsp;</span> <span id="secondNumber">3</span><span>&nbsp;S</span>
						</div>
					</li>
				</ul>
		    </div>
		</div>
		<div>
			<div class="coinBox buybtc">
				<div class="coinBoxBody buybtcbody">
					<span id="modifyResultTips" class="fred"></span>
					<div class="freetitle">
					</div>
					<div id="buydiv" style="display: block;">
						<div class="moneynumtext1"><span>人民币余额 : </span><span class="moneynum lightgreen5"> <?php echo (($auth["rmb"])?($auth["rmb"]):0); ?>&nbsp;&nbsp;&nbsp;<a href="<?php echo ($path); ?>/Fill"><span class="finbutton">&nbsp;</span></a></span></div>
						<div class="moneynumtext2"><span>可买<?php echo ($unit); ?>: </span><span class="moneynum lightgreen5"><?php echo (($best["buynum"])?($best["buynum"]):0); ?></span></div>
					</div>
					<div id="selldiv" style="display: none;">
						<div class="moneynumtext1"><span><?php echo ($unit); ?>余额 : </span><span class="moneynum fred"> <?php echo (($balance)?($balance):0); ?></span></div>
						<div class="moneynumtext3"><span>可卖人民币: </span><span class="moneynum fred"><?php echo (($best["sellrmb"])?($best["sellrmb"]):0); ?></span></div>
					</div>
						<div class="moneynumtext2"><span>最高交易价: </span><span class="moneynum lightgreen5">￥<?php echo (($max_p)?($max_p):0); ?></span>&nbsp;&nbsp;&nbsp;<span>最低交易价: </span><span class="moneynum lightgreen5">￥<?php echo (($min_p)?($min_p):0); ?></span></div>
					<div class="buytext">
						<span class="buyprice">出价￥/<?php echo ($unit); ?>: </span>
						<span class="buynum"><span class="lightgreen5 fontsize-16" id="numname">买入数量</span></span>
						<span class="summoney">总金额</span>
					</div>
					<div class="buyinput">
						<span class="buyinputprice">
						    <input class="buysellinput" id="price" value="<?php echo (($best["buy"])?($best["buy"]):0); ?>"/>
						</span>
						<span class="buyinputnum"><input class="buysellinput" id="num"/></span>
						<span class="inputsummoney"><input class="buysellinput" id="total" type="text" disabled="disabled"/></span>
						<span class="chen"></span>
						<span class="equal"></span>
					</div>
					<div id="btcFeeTips" class="fred btcFeeTips"></div>
					<div class="tranpass">交易费用：<font color="#FF0000">卖出收取1%手续费</font></div>
					<div class="tranpass" style="padding-top:5px;">交易密码 : <input class="buysellinput" id="paypwd" type="password"/> <a href="<?php echo ($path); ?>/User/lostpwd">忘记密码？</a></div>
					<div id="tradeBtcTips" class="fred center tradeBtcTips"></div>
					<div class="submitorder"><a class="buttonGreen" id="subbtn">立即买入</a></div>
				</div>
			</div>
			<script language="javascript">
			$('document').ready(function(){
				var url = '<?php echo ($path); ?>/Orders/buy';
				var type = '<?php echo ($type); ?>';
				if(type=='0'){
					$('.tab').removeClass('cur');
					$('#selltab').addClass('cur');
					$('#buydiv').hide();
					$('#selldiv').show();
					$('#subbtn').text('立即卖出');
					$('#numname').text('买出数量');
					url = '<?php echo ($path); ?>/Orders/sell';
				}else{
					$('.tab').removeClass('cur');
					$('#buytab').addClass('cur');
				    $('#buydiv').show();
					$('#selldiv').hide();
					$('#numname').text('买入数量');
					$('#subbtn').text('立即买入');
					url = '<?php echo ($path); ?>/Orders/buy';
				}
                
				$('.tab').click(function(){
                    $('.tab').removeClass('cur');
					$(this).addClass('cur');
				    if($(this).attr('id')=='buytab'){
					    $('#buydiv').show();
						$('#selldiv').hide();
						$('#numname').text('买入数量');
						$('#subbtn').text('立即买入');
						url = '<?php echo ($path); ?>/Orders/buy';
					}else if($(this).attr('id')=='selltab'){
					    $('#buydiv').hide();
						$('#selldiv').show();
						$('#subbtn').text('立即卖出');
						$('#numname').text('卖出数量');
						url = '<?php echo ($path); ?>/Orders/sell';
					}
				});

			    $('#price,#num').bind('focusout',function(){
				    var price = parseFloat($('#price').val());
					var num = parseFloat($('#num').val()>0?$('#num').val():0);
					var total = price * num;
					var tradefee = '<?php echo (($sys["tradefee"])?($sys["tradefee"]):0); ?>';

					if(url=='<?php echo ($path); ?>/Orders/sell'){
					    var fee = total * parseFloat(tradefee) / 100;
					}else{
					    var fee = total * parseFloat(tradefee) / 100;
					}

                   /* if(price!= null && price.toString().split(".")!=null && price.toString().split(".")[1] != null && price.toString().split('.')[1].length>2){
					    
					}else{*/
					if(isNaN(price)){
						price=0;	
					}
						price=(price.toFixed(3));
					    $('#price').val(price);
					//}

                    if(num!= null && num.toString().split(".")!=null && num.toString().split(".")[1] != null && num.toString().split('.')[1].length>4){
					    $('#num').val(num.toFixed(4));
					}else{
					    $('#num').val(num);
					}

					if(total!= null && total.toString().split(".")!=null && total.toString().split(".")[1] != null && total.toString().split('.')[1].length>2){
					    $('#total').val(total.toFixed(2));
					}else{
					    $('#total').val(total);
					}

					if(fee!= null && fee.toString().split(".")!=null && fee.toString().split(".")[1] != null && fee.toString().split('.')[1].length>2){
					    $('#fee').val(fee.toFixed(2));
					}else{
					    $('#fee').val(fee);
					}
				});
                                
				$('#subbtn').click(function(){

					var begin = '<?php echo (($sys["ks"])?($sys["ks"]):0); ?>';
					if(begin=='0'){
					    alert('你好，现在还不能交易！');
						return false;
					}

					var coin = '<?php echo ($coin); ?>';

					if($('#price').val()==''||$('#price').val()<=0){
					    $('#tradeBtcTips').text('请输入价格');
						$('#price').focus();
						return;
					}else if($('#num').val()==''||$('#num').val()<=0){
					    $('#tradeBtcTips').text('请输入数量');
						$('#num').focus();
						return;
					}else if($('#paypwd').val()==''){
					    $('#tradeBtcTips').text('请输入交易密码');
						$('#paypwd').focus();
						return;
					}
					$.post(url,{price:$('#price').val(),num:$('#num').val(),coin:coin,paypwd:$('#paypwd').val()},function(d){
						if(d.status==0){
						    alert(d.info);
							location.href='<?php echo ($path); ?>/Trade/index/coin/<?php echo ($coin); ?>/type/'+d.data;
						}else{
						    alert(d.info);
						}
					},'json');
				});
			});
			</script>
			<div class="boxmargin"></div>
			<div id="coinBoxbuybtc">
			<div class="coinBox buyonesellone">
				<div class="coinBoxBody buybtcbody2">
					<ul class="orderlist">
						<li style="height:31px;">
							<span style="float:left;padding-left:15px;">
								 <span class="black bold fontsize">最新成交价:</span>
								 <span class="lightorange1 fontsize">￥<?php echo (($last)?($last):0); ?></span>
							</span>
							<span style="float:right;padding-right:35px;"><a href="<?php echo ($path); ?>/Market">更多&gt;&gt;</a></span>
						</li>
						<li class="borderbtm black"><span class="height-40 c1 fontsize">买卖</span><span class="height-40 c2 fontsize">价格</span><span class="height-40 c3 fontsize">委单量</span></li>
					</ul>
					<ul class="orderlist" id="lis">
					    <?php if(is_array($orders["sell"])): $k = 0; $__LIST__ = $orders["sell"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><li class="red"><span class="c1 height-35">卖 (<?php echo ($k-$k+6-$k); ?>)</span><span class="c2 height-35"><?php echo ($vo["price"]); ?></span><span class="c3 height-35">฿<?php echo ($vo["num"]); ?></span></li><?php endforeach; endif; else: echo "" ;endif; ?>
						<?php if(is_array($orders["buy"])): $k = 0; $__LIST__ = $orders["buy"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($k % 2 );++$k;?><li class="lightgreen5"><span class="c1 height-35">买 (<?php echo ($k); ?>)</span><span class="c2 height-35"><?php echo ($vo["price"]); ?></span><span class="c3 height-35">฿<?php echo ($vo["num"]); ?></span></li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
				</div>
			</div>
			</div>
		</div>
		<script language="javascript">
		$(document).ready(function(){
			
			var coin = '<?php echo ($coin); ?>';
			var go = null;

            var wait = second =  $('#secondNumber').text();
			go = setInterval(function(){
				$('#secondNumber').text(wait);
				wait--;
				if(wait<0){
					$.post('<?php echo ($path); ?>/Trade/entrust',{coin:coin},function(d){
						$('#lis').html(d.data);
					},'json');
					wait=second;
				}
			},1000);

            $('#updateSecond').change(function(){
				clearInterval(go);
			    wait = second =  $(this).val();
				go = setInterval(function(){
					$('#secondNumber').text(wait);
					wait--;
					if(wait<0){
						$.post('<?php echo ($path); ?>/Trade/entrust',{coin:coin},function(d){
							$('#lis').html(d.data);
						},'json');
						wait=second;
					}
				},1000);
			});
		});
		</script>
		<div id="entrustInfo">
			<div class="entrustTen lasttenorder clear">
				<div class="Tentitle">
					<div class="buysellTitle" style="margin-bottom:0px;">
						<ul class="selecttab-box1">
							<li class="cur logs" name="wt">
								<a class="buyBtcLtc" href="javascript:void(0);">最近10笔委托</a>
							</li>
							<li class="logs" name="jl">
								<a class="sellBtcLtc" href="javascript:void(0);">最近10笔成交记录</a>
							</li>
							<li style="float:right;">
								<a href="<?php echo ($path); ?>/Trade/buys" title="更多" class="fontsize-12" style="color:#1478c8;">更多&gt;&gt;</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="Tenbody" id="wt">
							<table>
								<tbody>
									<tr>
										<th width="130">委托时间</th>
										<th width="70">委托类别</th>
										<th width="80">委托数量</th>
										<th width="80">委托金额</th>
										<th width="80">委托价格</th>
										<th width="80">成交数量</th>
										<th width="80">成交金额</th>
										<th width="75">操作</th>
									</tr>
									
									<?php if(is_array($orders["entrust"])): $i = 0; $__LIST__ = $orders["entrust"];if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr><td><?php echo (date("Y-m-d H:i:s",$vo["ctime"])); ?></td><td><?php if(($vo["type"]) == "1"): ?>买<?php else: ?>卖<?php endif; ?></td><td><?php echo ($vo["num"]); ?></td><td><?php echo ($vo["total"]); ?></td><td><?php echo ($vo["price"]); ?></td><td><?php echo ($vo["deal"]); ?></td><td><?php echo ($vo["dealtotal"]); ?></td><td><?php if(($vo["status"]) == "0"): ?><a class="cancel" id="<?php echo ($vo["id"]); ?>">撤销委托</a><?php else: ?>已完成<?php endif; ?></td></tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
								</tbody>
							</table>
			  </div>
				<div class="Tenbody" id="jl" style="display:none">
							<table>
								<tbody>
									<tr>
										<th width="130">交易时间</th>
										<th width="100">交易类别</th>
										<th width="130">交易数量</th>
										<th width="130">交易金额</th>
										<th width="130">交易价格</th>
									</tr>
									
									<?php if(is_array($orders["trade"])): $i = 0; $__LIST__ = $orders["trade"];if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr><td><?php echo (date("Y-m-d H:i:s",$vo["ctime"])); ?></td><td><?php if(($vo["type"]) == "1"): ?>买<?php else: ?>卖<?php endif; ?></td><td><?php echo ($vo["num"]); ?></td><td><?php echo ($vo["total"]); ?></td><td><?php echo ($vo["price"]); ?></td></tr><?php endforeach; endif; else: echo "$empty" ;endif; ?>
								</tbody>
							</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="/Public/Home/trade.js"></script>

<link href="/Public/Home/lrtk.css" rel="stylesheet" type="text/css" media="screen, projection">
<script type="text/javascript" src="/Public/Home/cs_q.js"></script>
<!-- 代码 开始 -->
<div id="qq_icon"></div>

<div id="allFooter">
<div class="foot clear" id="footer">
		<ul> 
			<li><a href="<?php echo ($path); ?>/Art/index/cate/about">关于我们</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/help">帮助中心</a> - </li>
			<li><a href="<?php echo ($path); ?>/Art/index/cate/news">网站公告</a> - </li>
		</ul>
		<div class="version gray">
			<?php echo ($sys["icp"]); ?>
			<br>
		</div>
	</div>
	<iframe src="" id="ifs" width="0" height="0" style="display:none"></iframe>
	<div class="okcoinPop" id="okcoinPop" style="display: none; ">
	    <iframe scrolling="no" style="border:0;height:100%;_height:255px;width:100%;left:0;top:0;z-index:-1;position:absolute;"></iframe>
		<div class="dialog_content" id="dialog_content">
			<div id="conten">
				<div class="selecttab">
					<ul class="selecttab-box">
						<li id="loginLi" class="cur">
							<a href="javascript:void(0);" data-btn="login" title="登录">登&nbsp;录</a>
						</li>
						<li id="regLi" class="">
							<a href="javascript:void(0);" data-btn="reg" title="注册">注&nbsp;册</a>
						</li>
					</ul>
					<a href="javascript:void(0);" data-btn="close" class="dialog1_closed" title="关闭">
					</a>
				</div>
				<div id="loginDialog" class="dialog_body" style="display: block; ">
					<table>
						<tbody>
							<tr>
								<th width="90">
									<label for="username">用户名:</label>
								</th>
								<td width="200">
									<input id="username" class="txt" type="text" name="username">
								</td>
								<td>
									<span id="usernamewarn" class="warn">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							<tr>
								<th>
									<label for="password">
										密&nbsp;&nbsp;&nbsp;&nbsp;码:
									</label>
								</th>
								<td>
									<input id="password" class="txt" type="password" name="password">
								</td>
								<td>
									<span id="passwordwarn" class="warn">6－16位字符</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="" style="height:25px;">
						<span id="loginTips" class="orange" style="display:none;height:25px;padding-left:90px;">
							用户名或密码错误
						</span>
					</div>
					<div class="submit-link">
						<a class="button-dialog" id="loginbtn" type="submit" value="登录" title="登录">登录</a><span class="gray" style="dispaly:inline-block;"><a id="" title="忘记密码" href="<?php echo ($path); ?>/Account/lostpwd">忘记密码</a></span>				
					</div>
					<div class="submit-link padding-top"> 
						还没有账号?<a href="javascript:void(0);" data-btn="reg" title="立即注册" class="red">&nbsp;立即注册</a>
					</div>		
				</div>
				<!-- 注册 -->
				<div id="regDialog" class="dialog_body" style="display: none; ">
					<span style="color:red;padding-left: 20px;"></span>
					<input type="hidden" id="regType" value="1">
					<div class="center">
						<span id="regTips" class="orange" style="display:none;"></span>
					</div>
					<table>
						<tbody>
						
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>用户名:
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="username" tabindex="1">		
								</td>
								<td>
									<!--<span>用于登录，请认真填写</span>-->
									<span data-warn="username">2－16位字母、数字、下划线字符</span>
								</td>
							</tr>
							
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>登录密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="password" tabindex="2">		
								</td>
								<td>
									<span data-warn="password">6－16位字符</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repassword" tabindex="3">	
								</td>
								<td>
									<span data-warn="repassword">请重新输入密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>支付密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="paypwd" tabindex="4">		
								</td>
								<td>
									<span data-warn="paypwd">6－16位字符。</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>确认密码：
									</label>
								</th>
								<td>
									<input class="txt" type="password" name="repaypwd" tabindex="5">	
								</td>
								<td>
									<span data-warn="repaypwd">请重新输入支付密码，确认无误</span>
								</td>
							</tr>
							<tr>
								<th width="80" class="left">
									<label>
										<span class="orange">*</span>推荐人ID：
									</label>
								</th>
								<td>
									<input class="txt" type="text" name="invitup" value="<?php echo ($invit); ?>" tabindex="6">	
								</td>
								<td>
									<span data-warn="invitup">推荐你注册的用户ID，没有可以留空</span>
								</td>
							</tr>
						</tbody>
					</table>
					<div class="register-link">
						<a id="regbtn" class="button-dialog" type="submit" value="确定注册" title="确定注册" tabindex="4">确定注册</a>
						<span>已经注册?<a href="javascript:void(0);" data-btn="login" title="快速登录"> 快速登录</a></span>
					</div>	
					<div class="submit-link">
						<label class="register" for="agree" title="">
							<input id="agree" type="hidden" value="1" checked="" onclick="javascript:termsService();">
						</label>
					</div>
				</div>
			</div>

			<!-- 注册后邮箱提示 -->
			<div class="emailSucess" style="display:none;" id="emailSucess">
				<a href="javascript:closelogin();" class="dialogClosed" title="关闭"></a>
				<div class="emailSucessLeft">
				</div>
				<div class="emailSucessRight">
					<span class="blue fontsize-14 bold">恭喜您注册成功</span>
					<br>
					<span>激活邮件已经发送到您的邮箱：<span id="emailSpan" class="fred fontsize-14 bold"></span></span>
					<br>
					<span class="verifySpan"><span class=""><a class="button-dialog" href="/trade/btc.html">进入交易中心</a></span><span class="gray fontsize-12">或</span><span class="">进入邮箱激活（方便您以后找回密码）</span></span>
				</div>
			</div>
		</div>
	</div>
</div>   
</div><ul class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="display: none; "></ul><div id="dialogBoxShadow" style="position: absolute; top: 0px; left: 0px; z-index: 100; background-color: rgb(0, 0, 0); width: 100%; height: 2051px; background-position: initial initial; background-repeat: initial initial;display:none; filter:alpha(opacity=40);  
      -moz-opacity:0.4;  
      -khtml-opacity: 0.4;  
      opacity: 0.4; "></div></body></html>

<script type="text/javascript" src="/Public/Home/checkform.js"></script>
<script language="javascript">
$(document).ready(function(){
	<?php if(($notlogin) == "1"): ?>$('#okcoinPop').show();
	$('#dialogBoxShadow').show();<?php endif; ?>

    $('[data-btn="login"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").show();
		$("#regDialog").hide();
		$("#regLi").removeClass('cur');
		$("#loginLi").addClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="reg"]').click(function(){
		$('#okcoinPop').show();
	    $('#dialogBoxShadow').show();
	    $("#loginDialog").hide();
		$("#regDialog").show();
		$("#regLi").addClass('cur');
		$("#loginLi").removeClass('cur');
		$("input[name='username']").focus();
	});
	$('[data-btn="close"]').click(function(){
		$('#okcoinPop').hide();
	    $('#dialogBoxShadow').hide();
		$('#loginDialog input').val('');
		$('#regDialog input').val('');
	});

    $('#loginbtn').click(function(){
        if(checkform('loginDialog')){
		    $.post('<?php echo ($path); ?>/Account/go',{username:$('#loginDialog input[name="username"]').val(),password:$('#loginDialog input[name="password"]').val()}, function(d){
			    if(d.status==0){
				    location.href="<?php echo (($back_url)?($back_url):'/'); ?>";
				}else{
					alert(d.info)
				    $('[data-warn="username"]').text(d.info);
				}
			},'json');
		}
    });

	$('#regbtn').click(function(){
        if(checkform('regDialog')){
			$.post('<?php echo ($path); ?>/Account/insert',{username:$('#regDialog input[name="username"]').val(),password:$('#regDialog input[name="password"]').val(),repassword:$('#regDialog input[name="repassword"]').val(),paypwd:$('#regDialog input[name="paypwd"]').val(),repaypwd:$('#regDialog input[name="repaypwd"]').val(),code:$('#regDialog input[name="checkcode"]').val(),invitup:$('#regDialog input[name="invitup"]').val()},function(d){
			    if(d.status==0){
					alert(d.info);
				    $('#okcoinPop').show();
					$('#dialogBoxShadow').show();
					$("#loginDialog").show();
					$("#regDialog").hide();
					$("#regLi").removeClass('cur');
					$("#loginLi").addClass('cur');
					$("input[name='username']").focus();
				}else if(d.status==2){
				    alert(d.info);
				}else{
				    alert(d.info);
				}
			},'json');
		}
    });
});
</script>
<script language="javascript">
$(document).ready(function(){
	$('.logs').click(function(){
	    $('.logs').removeClass('cur');
		$(this).addClass('cur');
		$('.Tenbody').hide();
		$('#'+$(this).attr('name')).show();
	});
    $('.cancel').click(function(){
	    var id = $(this).attr('id');
		var coin = '<?php echo ($coin); ?>';
		$.post('<?php echo ($path); ?>/Orders/cancel',{id:id,coin:coin},function(d){
			alert(d.info);
			if(d.status==0){
			    location.reload();
			}
		});
	});
});
</script>