<?php
function coin1($coin){
    $arr = explode('.',$coin);
	if(count($arr) == 2) $coin = $arr[0].'.'.substr($arr[1],0,8);
	return floatval($coin);
}

function coin($number,$n=6){
  return floatval(number_format(abs($number),$n,'.',''));
}

function userid($name){
	$user=M('user')->where('username="'.$name.'"')->find();
	return $user['id'];
}


function chkNum($n){
	$n = trim($n);
	if(empty($n)) return false;
    if(!is_numeric($n)) return false;
	if(floatval($n) <= 0) return false;
	return true;
}

function chkStr($str){
	$str = trim($str);
    if(empty($str)) return false;
	return true;
}

function chkArr($arr){
    if(empty($arr)) return false;
	if(!is_array($arr)) return false;
	if(count($arr)<=0) return false;
	foreach($arr as $k=> $v){
	    if($v===false){
		    return false;
		}
	}
	return true;
}

function phone($phone,$content){
    $smsapi = "api.smsbao.com"; //�������� 
	$charset = "utf8"; //�ļ����� 
	$user = "lyc5207"; //����ƽ̨�ʺ� 
	$pass = md5("520x1314"); //����ƽ̨���� 
	 
	 
	include_once("snoopy.php"); 
	$snoopy = new snoopy();
	$sendurl = "http://{$smsapi}/sms?u={$user}&p={$pass}&m={$phone}&c=".urlencode($content);
	$snoopy->fetch($sendurl);
	$result = $snoopy->results;
	return $result;
}
?>