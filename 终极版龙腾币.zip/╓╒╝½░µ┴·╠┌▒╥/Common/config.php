<?php
//配置文件
header('Content-Type: text/html; charset=UTF-8');

$qq_k='101236746'; //QQ应用APP ID
$qq_s='b4b8d064fb8da1d555a46f839e5941b2'; //QQ应用APP 
$callback_url='http://www.benpaobi.com/index.php/Home/Account/callback'; //授权回调网址
$scope='get_user_info,add_share'; //权限列表，具体权限请查看官方的api文档

'TMPL_CACHE_ON' => false,//禁止模板编译缓存
'HTML_CACHE_ON' => false,//禁止静态缓存
