<?php
echo '<script language="javascript">location="/?s=Admin/Login/";</script>';
?>