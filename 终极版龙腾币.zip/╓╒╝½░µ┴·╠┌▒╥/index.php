<?php
ini_set('session.save_path', dirname(__FILE__).'/session/');
define('APP_DEBUG',true);
require('ThinkPHP/ThinkPHP.php');
?>
